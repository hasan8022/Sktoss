package com.example.safety

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.util.Log

/**
 * Replicates tr.halil.et5.safety.HomeGate
 * Acts as the automotive safety HOME gatekeeper activity.
 * When HOME intent is pressed or vehicle starts, safely focuses
 * MainActivity and suppresses unwanted stock system windows.
 */
class HomeGate : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val intent = Intent().apply {
                component = ComponentName(packageName, "com.example.MainActivity")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
            }
            startActivity(intent)
        } catch (e: Exception) {
            Log.e("HomeGate", "MainActivity başlatılamadı: ${e.message}")
        } finally {
            finish()
        }
    }
}
