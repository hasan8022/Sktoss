package com.example.media

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Spotify HUD integration boundary.
 * No sample account, playlists, tracks or playback state are fabricated here.
 * The official Spotify Web Player remains available in the dedicated WebView pane.
 * A true native account/player integration requires registered Spotify app credentials,
 * supported SDK/API access and a real account authorization flow.
 */
data class SpotifyTrack(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumCoverUrl: String,
    val durationText: String = ""
)

data class SpotifyPlaylist(
    val id: String,
    val name: String,
    val trackCount: Int,
    val coverUrl: String
)

class SpotifyWebEngine(private val coordinator: CarMediaCoordinator? = null) {
    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _currentTrack = MutableStateFlow<SpotifyTrack?>(null)
    val currentTrack: StateFlow<SpotifyTrack?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playlists = MutableStateFlow<List<SpotifyPlaylist>>(emptyList())
    val playlists: StateFlow<List<SpotifyPlaylist>> = _playlists.asStateFlow()

    private val _currentTracks = MutableStateFlow<List<SpotifyTrack>>(emptyList())
    val currentTracks: StateFlow<List<SpotifyTrack>> = _currentTracks.asStateFlow()

    val integrationStatus: String = "Native Spotify OAuth / App Remote yapılandırılmadı. Resmi Spotify Web Player kullanılabilir."

    // Deliberately do not mark an account connected without a real OAuth callback.
    fun loginWithSpotify() = Unit

    fun logout() {
        _isConnected.value = false
        _isPlaying.value = false
        _currentTrack.value = null
        coordinator?.setPlaybackState(false)
    }

    // These controls are inactive until a real Spotify playback session is attached.
    fun selectTrack(track: SpotifyTrack) = Unit
    fun togglePlayPause() = Unit
    fun nextTrack() = Unit
    fun previousTrack() = Unit
}
