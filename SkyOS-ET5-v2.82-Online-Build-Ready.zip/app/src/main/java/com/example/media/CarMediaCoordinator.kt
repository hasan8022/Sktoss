package com.example.media

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.view.KeyEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * All 10 media sources from SkyOS 2.82 LB00; enum in classes.dex,
 * plus YOUTUBE (with driving safety lock) and IDLE.
 */
enum class MediaSource(
    val displayName: String,
    val badgeShort: String,
    val badgeColorHex: Long,
    val packageNames: List<String>,
    val serviceComponent: ComponentName? = null
) {
    RADIO(
        displayName = "İnternet Radyosu",
        badgeShort = "Radyo",
        badgeColorHex = 0xFFD32F2F,
        packageNames = listOf("com.aistudio.skyos.et5auto", "tr.halil.et5")
    ),
    FM_RADIO(
        displayName = "FM Radyo",
        badgeShort = "FM",
        badgeColorHex = 0xFFE65100,
        packageNames = listOf("com.skyworth.car.carradio"),
        serviceComponent = ComponentName("com.skyworth.car.carradio", "com.coocaa.radio.service.impl.RadioAppService")
    ),
    BLUETOOTH(
        displayName = "Bluetooth",
        badgeShort = "BT",
        badgeColorHex = 0xFF1976D2,
        packageNames = listOf("com.android.bluetooth", "com.skyworth.car.carbtmusic"),
        serviceComponent = ComponentName("com.android.bluetooth", "com.android.bluetooth.avrcpcontroller.BluetoothMediaBrowserService")
    ),
    USB(
        displayName = "USB",
        badgeShort = "USB",
        badgeColorHex = 0xFF3E6AE1,
        packageNames = listOf("com.skyworth.car.localmedia"),
        serviceComponent = ComponentName("com.skyworth.car.localmedia", "com.coocaa.local.media.impl.MusicService")
    ),
    SPOTIFY(
        displayName = "Spotify",
        badgeShort = "Spotify",
        badgeColorHex = 0xFF1DB954,
        packageNames = listOf("com.spotify.music")
    ),
    YOUTUBE_MUSIC(
        displayName = "YouTube Music",
        badgeShort = "YTM",
        badgeColorHex = 0xFFFF0000,
        packageNames = listOf(
            "app.rvx.android.apps.youtube.music",
            "com.google.android.apps.youtube.music",
            "app.revanced.android.apps.youtube.music"
        )
    ),
    APPLE_MUSIC(
        displayName = "Apple Music",
        badgeShort = "Apple",
        badgeColorHex = 0xFFFA243C,
        packageNames = listOf("com.apple.android.music"),
        serviceComponent = ComponentName("com.apple.android.music", "com.apple.android.music.player.MediaPlaybackService")
    ),
    DEEZER(
        displayName = "Deezer",
        badgeShort = "Deezer",
        badgeColorHex = 0xFFA238FF,
        packageNames = listOf("deezer.android.app"),
        serviceComponent = ComponentName("deezer.android.app", "com.deezer.feature.mediabrowser.DeezerMediaBrowserService")
    ),
    SOUNDCLOUD(
        displayName = "SoundCloud",
        badgeShort = "SC",
        badgeColorHex = 0xFFFF5500,
        packageNames = listOf("com.soundcloud.android"),
        serviceComponent = ComponentName("com.soundcloud.android", "com.soundcloud.android.playback.players.MediaService")
    ),
    METROLIST(
        displayName = "Metrolist",
        badgeShort = "Metro",
        badgeColorHex = 0xFF00ACC1,
        packageNames = listOf("com.metrolist.music"),
        serviceComponent = ComponentName("com.metrolist.music", "com.metrolist.music.playback.MusicService")
    ),
    YOUTUBE(
        displayName = "YouTube Video",
        badgeShort = "YT",
        badgeColorHex = 0xFFFF0000,
        packageNames = listOf("com.google.android.youtube", "org.schabi.newpipe")
    ),
    IDLE(
        displayName = "Medya",
        badgeShort = "SKYOS",
        badgeColorHex = 0xFF3A8BFF,
        packageNames = emptyList()
    )
}

data class NowPlayingMetadata(
    val title: String = "Medya hazır",
    val subtitle: String = "Kaynak seçin",
    val badgeLogoText: String = "Radyo7",
    val badgeColorHex: Long = 0xFFD32F2F,
    val source: MediaSource = MediaSource.RADIO,
    val isPlaying: Boolean = false,
    val albumArtUrl: String? = null,
    val progressFraction: Float = 0f
)

class CarMediaCoordinator(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val _activeSource = MutableStateFlow(MediaSource.RADIO)
    val activeSource: StateFlow<MediaSource> = _activeSource.asStateFlow()

    private val _nowPlaying = MutableStateFlow(
        NowPlayingMetadata(
            title = "KRAL TÜRK FM",
            subtitle = "TR - İnternet Radyosu",
            badgeLogoText = "Radyo7",
            badgeColorHex = 0xFFD32F2F,
            source = MediaSource.RADIO,
            isPlaying = false
        )
    )
    val nowPlaying: StateFlow<NowPlayingMetadata> = _nowPlaying.asStateFlow()

    private val _volumeLevel = MutableStateFlow(15) // 0 - 30 scale
    val volumeLevel: StateFlow<Int> = _volumeLevel.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    fun selectMediaSource(source: MediaSource) {
        _activeSource.value = source
        if (source != MediaSource.RADIO && source != MediaSource.USB && source != MediaSource.YOUTUBE) {
            _nowPlaying.value = NowPlayingMetadata(
                title = source.displayName,
                subtitle = if (isSourceInstalled(source)) {
                    "${source.displayName} hazır"
                } else {
                    "${source.displayName} (Uygulama kurulu değil / Web veya BT bekleniyor)"
                },
                badgeLogoText = source.badgeShort,
                badgeColorHex = source.badgeColorHex,
                source = source,
                isPlaying = false
            )
        }
    }

    fun isSourceInstalled(source: MediaSource): Boolean {
        if (source == MediaSource.RADIO || source == MediaSource.USB || source == MediaSource.BLUETOOTH) return true
        val pm = context.packageManager
        return source.packageNames.any { pkg ->
            try {
                pm.getPackageInfo(pkg, 0)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    fun launchSourceApp(source: MediaSource): Boolean {
        val pm = context.packageManager
        for (pkg in source.packageNames) {
            val intent = pm.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return try {
                    context.startActivity(intent)
                    true
                } catch (_: Exception) {
                    false
                }
            }
        }
        return false
    }

    fun dispatchSystemMediaKey(keyCode: Int) {
        val am = audioManager ?: return
        val now = SystemClock.uptimeMillis()
        val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0)
        val up = KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0)
        am.dispatchMediaKeyEvent(down)
        am.dispatchMediaKeyEvent(up)
    }

    fun updateNowPlaying(
        title: String,
        subtitle: String,
        badgeText: String,
        source: MediaSource,
        isPlaying: Boolean,
        badgeColorHex: Long = source.badgeColorHex,
        albumArtUrl: String? = null,
        progressFraction: Float = 0f
    ) {
        _activeSource.value = source
        _nowPlaying.value = NowPlayingMetadata(
            title = title,
            subtitle = subtitle,
            badgeLogoText = badgeText,
            badgeColorHex = badgeColorHex,
            source = source,
            isPlaying = isPlaying,
            albumArtUrl = albumArtUrl,
            progressFraction = progressFraction
        )
    }

    fun setPlaybackState(isPlaying: Boolean) {
        _nowPlaying.value = _nowPlaying.value.copy(isPlaying = isPlaying)
    }

    fun adjustVolume(delta: Int) {
        val newLevel = (_volumeLevel.value + delta).coerceIn(0, 30)
        _volumeLevel.value = newLevel
        _isMuted.value = newLevel == 0
        val maxSystem = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
        val systemTarget = ((newLevel / 30f) * maxSystem).toInt()
        audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, systemTarget, 0)
    }

    fun toggleMute() {
        val muted = !_isMuted.value
        _isMuted.value = muted
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioManager?.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (muted) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE,
                0
            )
        }
    }

    fun requestAudioFocus(): Boolean {
        val am = audioManager ?: return true
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                .build()
            am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN) ==
                AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
    }
}
