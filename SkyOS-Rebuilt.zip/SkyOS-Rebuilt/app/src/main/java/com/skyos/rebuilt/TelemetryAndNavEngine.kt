package com.skyos.rebuilt

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class TelemetryAndNavEngine(
    private val context: Context,
    private val state: VehicleState,
    private val carBridge: CarJsBridge,
    private val mapBridge: MapJsBridge,
    private val onTickUi: () -> Unit
) {
    private val handler = Handler(Looper.getMainLooper())
    private var simTickCount = 0
    private var btSocket: BluetoothSocket? = null
    private var btRunning = false

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private val loopRunnable = object : Runnable {
        override fun run() {
            simTickCount++
            if (state.mediaPlaying) {
                val track = state.tracks[state.mediaTrackIndex]
                if (simTickCount % 2 == 0) {
                    state.mediaProgressSec = (state.mediaProgressSec + 1) % track.durationSec
                }
            }

            if (state.isSimulationActive) {
                stepDrivingSimulation()
            }

            onTickUi()
            handler.postDelayed(this, 500L)
        }
    }

    fun startLoop() {
        handler.removeCallbacks(loopRunnable)
        handler.post(loopRunnable)
    }

    fun stopLoop() {
        handler.removeCallbacks(loopRunnable)
        disconnectObd()
    }

    private fun stepDrivingSimulation() {
        val route = state.routes[state.activeRouteIndex]
        val pts = route.points
        if (pts.size < 2) return

        // Vites D veya S değilse otomatik D'ye geçir
        if (state.gear == "P" || state.gear == "N") {
            state.gear = "D"
        }

        // Hız ve güç simülasyonu
        val targetSpeed = when (state.driveMode) {
            "SPORT" -> 92
            "ECO" -> 58
            "TEK PEDAL" -> 64
            else -> 74
        }
        val wave = (sin(simTickCount * 0.18) * 12).toInt()
        state.speedKmh = (targetSpeed + wave).coerceIn(18, 135)
        state.motorRpm = state.speedKmh * 78
        state.powerKw = ((state.speedKmh * 0.24) + sin(simTickCount * 0.25) * 6.5)
        state.voltageV = 394.0 + cos(simTickCount * 0.1) * 3.2
        state.odometerKm += (state.speedKmh / 3600.0) * 0.5

        if (simTickCount % 45 == 0 && state.batterySoc > 15) {
            state.batterySoc -= 1
            state.rangeKm = (state.batterySoc * 5.2).toInt()
        }

        // Rota üzerinde ilerleme
        state.routeProgressFrac += 0.012
        if (state.routeProgressFrac >= 1.0) {
            state.routeProgressFrac = 0.0
        }

        val totalSegments = pts.size - 1
        val exactIdx = state.routeProgressFrac * totalSegments
        val segIdx = exactIdx.toInt().coerceIn(0, totalSegments - 1)
        val localFrac = exactIdx - segIdx

        val p1 = pts[segIdx]
        val p2 = pts[segIdx + 1]
        val lat = p1.first + (p2.first - p1.first) * localFrac
        val lng = p1.second + (p2.second - p1.second) * localFrac
        val bearing = computeBearing(p1.first, p1.second, p2.first, p2.second)

        mapBridge.updateFix(lat, lng, bearing, state.routeProgressFrac)

        // Park sensörü aktifse dinamik mesafe dalgalanması
        if (state.parkSensorsActive) {
            for (i in 0..3) {
                state.frontSensors[i] = (0.45f + 0.55f * abs(sin((simTickCount + i) * 0.15)).toFloat())
                state.rearSensors[i] = (0.30f + 0.65f * abs(cos((simTickCount + i) * 0.12)).toFloat())
            }
            carBridge.syncParkSensors()
        }
    }

    private fun computeBearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val rad = Math.PI / 180.0
        val dLon = (lon2 - lon1) * rad
        val y = sin(dLon) * cos(lat2 * rad)
        val x = cos(lat1 * rad) * sin(lat2 * rad) - sin(lat1 * rad) * cos(lat2 * rad) * cos(dLon)
        return (atan2(y, x) / rad + 360.0) % 360.0
    }

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    @SuppressLint("MissingPermission")
    fun getPairedObdDevices(): List<Pair<String, String>> {
        if (!hasBluetoothPermission()) return emptyList()
        val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter: BluetoothAdapter? = bm?.adapter
        if (adapter == null || !adapter.isEnabled) return emptyList()
        return adapter.bondedDevices?.map { (it.name ?: "Bilinmeyen Cihaz") to it.address } ?: emptyList()
    }

    @SuppressLint("MissingPermission")
    fun connectToObdDevice(address: String, name: String) {
        if (!hasBluetoothPermission()) {
            state.obdStatusLog = "Bluetooth izni gerekli (Android 12+ Yakındaki Cihazlar izni)."
            onTickUi()
            return
        }
        val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = bm?.adapter ?: return
        val device: BluetoothDevice = try {
            adapter.getRemoteDevice(address)
        } catch (e: Exception) {
            state.obdStatusLog = "Geçersiz Bluetooth adresi: $address"
            onTickUi()
            return
        }

        disconnectObd()
        state.obdStatusLog = "$name ($address) cihazına RFCOMM/SPP üzerinden bağlanılıyor..."
        onTickUi()

        thread(start = true, name = "SkyOS-OBD-Thread") {
            try {
                val socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket.connect()
                btSocket = socket
                btRunning = true
                val out: OutputStream = socket.outputStream
                val inp: InputStream = socket.inputStream

                sendObdCmd(out, inp, "ATZ")
                sendObdCmd(out, inp, "ATE0")
                sendObdCmd(out, inp, "ATSP6") // ISO 15765-4 CAN (11 bit ID, 500 kbaud)

                handler.post {
                    state.obdConnected = true
                    state.obdDeviceName = "$name ($address)"
                    state.obdStatusLog = "ELM327 / CAN-Bus bağlantısı kuruldu. Canlı PID verisi okunuyor."
                    onTickUi()
                }

                while (btRunning && socket.isConnected) {
                    val speedResp = sendObdCmd(out, inp, "010D")
                    val rpmResp = sendObdCmd(out, inp, "010C")
                    val socResp = sendObdCmd(out, inp, "015B")

                    handler.post {
                        parseObdSpeed(speedResp)?.let { state.speedKmh = it }
                        parseObdRpm(rpmResp)?.let { state.motorRpm = it }
                        parseObdSoc(socResp)?.let {
                            state.batterySoc = it
                            state.rangeKm = (it * 5.2).toInt()
                        }
                        onTickUi()
                    }
                    Thread.sleep(600L)
                }
            } catch (e: Exception) {
                handler.post {
                    state.obdConnected = false
                    state.obdDeviceName = "Bağlantı Kesildi"
                    state.obdStatusLog = "OBD soket yanıt vermedi (${e.localizedMessage ?: "Zaman aşımı"}). Canlı Simülasyon modunu kullanabilirsiniz."
                    onTickUi()
                }
            }
        }
    }

    private fun sendObdCmd(out: OutputStream, inp: InputStream, cmd: String): String {
        out.write("$cmd\r".toByteArray())
        out.flush()
        Thread.sleep(120L)
        val buf = ByteArray(256)
        val avail = inp.available()
        if (avail > 0) {
            val len = inp.read(buf, 0, minOf(avail, buf.size))
            if (len > 0) return String(buf, 0, len)
        }
        return ""
    }

    private fun parseObdSpeed(raw: String): Int? {
        val clean = raw.replace(" ", "").uppercase()
        val idx = clean.indexOf("410D")
        if (idx >= 0 && clean.length >= idx + 6) {
            return clean.substring(idx + 4, idx + 6).toIntOrNull(16)
        }
        return null
    }

    private fun parseObdRpm(raw: String): Int? {
        val clean = raw.replace(" ", "").uppercase()
        val idx = clean.indexOf("410C")
        if (idx >= 0 && clean.length >= idx + 8) {
            val a = clean.substring(idx + 4, idx + 6).toIntOrNull(16) ?: return null
            val b = clean.substring(idx + 6, idx + 8).toIntOrNull(16) ?: return null
            return ((a * 256) + b) / 4
        }
        return null
    }

    private fun parseObdSoc(raw: String): Int? {
        val clean = raw.replace(" ", "").uppercase()
        val idx = clean.indexOf("415B")
        if (idx >= 0 && clean.length >= idx + 6) {
            val a = clean.substring(idx + 4, idx + 6).toIntOrNull(16) ?: return null
            return (a * 100) / 255
        }
        return null
    }

    fun disconnectObd() {
        btRunning = false
        try {
            btSocket?.close()
        } catch (_: Exception) {
        }
        btSocket = null
        state.obdConnected = false
    }
}
