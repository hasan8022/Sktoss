package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.voice.VoiceState
import com.example.ui.RightPaneMode
import com.example.ui.SkyOsViewModel
import com.example.ui.components.AutomotiveBottomHvacDock
import com.example.ui.components.GoogleMapsPane
import com.example.ui.components.LeftDrivingPane
import com.example.ui.components.MediaHubRightPane
import com.example.ui.components.PhoneDialerPane
import com.example.ui.components.SkywellGAppsHubDialog
import com.example.ui.components.SkywellVoiceAssistantDialog
import com.example.ui.screens.DriverProfilesScreen
import com.example.ui.screens.ObdDiagnosticsScreen
import com.example.ui.screens.SetupWizardScreen
import com.example.ui.screens.SystemDiagnosticsScreen
import com.example.ui.screens.VehicleControlScreen
import com.example.ui.theme.LocalEt5Colors
import com.example.ui.theme.SkyOsTheme

class MainActivity : ComponentActivity() {

    private val viewModel: SkyOsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()
            val isSetupCompleted by viewModel.isSetupCompleted.collectAsState()

            SkyOsTheme(darkTheme = isDarkTheme) {
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) {
                    viewModel.gpsProvider.startListening()
                    viewModel.refreshHardwareAudit()
                }

                LaunchedEffect(Unit) {
                    val permissions = mutableListOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.RECORD_AUDIO
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
                        permissions.add(Manifest.permission.BLUETOOTH_SCAN)
                    }
                    permissionLauncher.launch(permissions.toTypedArray())
                }

                AnimatedContent(
                    targetState = isSetupCompleted,
                    label = "CockpitSetupSwitch"
                ) { completed ->
                    if (!completed) {
                        SetupWizardScreen(
                            viewModel = viewModel,
                            onCompleteSetup = { config ->
                                viewModel.completeSetup(config)
                            }
                        )
                    } else {
                        SkyOsCockpitApp(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun SkyOsCockpitApp(viewModel: SkyOsViewModel) {
    val colors = LocalEt5Colors.current
    val rightPaneMode by viewModel.rightPaneMode.collectAsState()
    val activeDockTab by viewModel.activeDockTab.collectAsState()
    val effectiveSpeed by viewModel.effectiveSpeedKmh.collectAsState()
    val selectedGear by viewModel.selectedGear.collectAsState()
    val outsideTempC by viewModel.outsideTempC.collectAsState()
    val insideTempC by viewModel.insideTempC.collectAsState()
    val batteryRangeKm by viewModel.batteryRangeKm.collectAsState()
    val batterySocPercent by viewModel.batterySocPercent.collectAsState()
    val radarDistanceCm by viewModel.radarDistanceCm.collectAsState()
    val isObdConnected by viewModel.isObdConnected.collectAsState()
    val setupConfig by viewModel.setupConfig.collectAsState()
    val vehicleState by viewModel.vehicleState.collectAsState()
    val activeProfile by viewModel.activeProfile.collectAsState()
    val tripDurationText by viewModel.tripDurationText.collectAsState()
    val use3DCarView by viewModel.use3DCarView.collectAsState()
    val carColorHex by viewModel.carColorHex.collectAsState()

    val nowPlaying by viewModel.mediaCoordinator.nowPlaying.collectAsState()
    val volumeLevel by viewModel.mediaCoordinator.volumeLevel.collectAsState()
    val isMuted by viewModel.mediaCoordinator.isMuted.collectAsState()

    val driverTempC by viewModel.driverTempC.collectAsState()
    val fanLevel by viewModel.fanLevel.collectAsState()
    val driverSeatHeating by viewModel.driverSeatHeatingLevel.collectAsState()
    val passengerSeatHeating by viewModel.passengerSeatHeatingLevel.collectAsState()
    val frontDefrostOn by viewModel.frontDefrostOn.collectAsState()
    val rearDefrostOn by viewModel.rearDefrostOn.collectAsState()

    val gpsTelemetry by viewModel.gpsTelemetry.collectAsState()
    val hardwareInfo by viewModel.hardwareInfo.collectAsState()
    val voiceState by viewModel.voiceAssistantState.collectAsState()
    val voicePrompt by viewModel.voiceMessage.collectAsState()
    val showGAppsHub by viewModel.showGAppsHub.collectAsState()
    val showRearCameraOverlay by viewModel.showRearCameraOverlay.collectAsState()
    val actionToastMessage by viewModel.actionToastMessage.collectAsState()

    if (rightPaneMode != RightPaneMode.MAPS) {
        BackHandler {
            viewModel.openMap()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("skyos_cockpit_root")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Main Cockpit Split Area
            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                val isLandscape = maxWidth > maxHeight || maxWidth >= 600.dp
                val profileName = activeProfile?.name?.ifBlank { null }
                    ?: setupConfig.driverName.ifBlank { "Sürücü" }

                if (isLandscape) {
                    // Landscape Automotive Mode: Left ~38% Driving, Right ~62% Map/Media/Settings
                    Row(modifier = Modifier.fillMaxSize()) {
                        LeftDrivingPane(
                            effectiveSpeed = effectiveSpeed,
                            selectedGear = selectedGear,
                            outsideTempC = outsideTempC,
                            insideTempC = insideTempC,
                            batteryRangeKm = batteryRangeKm,
                            batterySocPercent = batterySocPercent,
                            isObdConnected = isObdConnected,
                            deviceBatteryPct = hardwareInfo.internalBatteryLevel,
                            isBluetoothConnected = hardwareInfo.isBluetoothAvailable,
                            isWifiConnected = hardwareInfo.isInternetConnected,
                            radarDistanceCm = radarDistanceCm,
                            nowPlaying = nowPlaying,
                            onGearSelect = { viewModel.setGear(it) },
                            onTogglePlayMedia = { viewModel.toggleActiveMediaPlayPause() },
                            onPrevMedia = { viewModel.previousActiveMedia() },
                            onNextMedia = { viewModel.nextActiveMedia() },
                            onClickMediaCard = { viewModel.openMediaHub() },
                            onSelectMediaSource = { src ->
                                viewModel.mediaCoordinator.selectMediaSource(src)
                                viewModel.openMediaHub()
                            },
                            use3DCarView = use3DCarView,
                            onToggle3DCarView = { viewModel.toggle3DCarView() },
                            carColorHex = carColorHex,
                            doorsOpen = vehicleState.doorsOpen,
                            isHoodOpen = vehicleState.hoodOpen,
                            isTrunkOpen = vehicleState.trunkOpen,
                            isChargePortOpen = vehicleState.chargePortOpen,
                            isHeadlightOn = vehicleState.lowBeamOn || vehicleState.highBeamOn,
                            isLeftSignalOn = vehicleState.leftSignalOn,
                            isRightSignalOn = vehicleState.rightSignalOn,
                            isHazardOn = vehicleState.hazardLightsOn,
                            isBrakeOn = vehicleState.brakeLightOn,
                            isCharging = vehicleState.isCharging,
                            chargeMinutesRemaining = vehicleState.chargeMinutesRemaining,
                            onStopCharging = { viewModel.stopCharging() },
                            onToggleTrunk = { viewModel.toggleTrunk() },
                            activeProfileName = profileName,
                            tripDurationText = tripDurationText,
                            odometerKm = vehicleState.odometerKm,
                            avgConsumptionKwh = vehicleState.avgConsumptionKwh100Km,
                            tirePressuresBar = vehicleState.tirePressuresBar,
                            onOpenProfiles = { viewModel.openDriverProfiles() },
                            onOpenSettings = { viewModel.openVehicleControls() },
                            onToggleTheme = { viewModel.toggleDarkTheme() },
                            modifier = Modifier
                                .weight(0.38f)
                                .fillMaxHeight()
                        )

                        // Right Dynamic Pane (~62%)
                        Box(
                            modifier = Modifier
                                .weight(0.62f)
                                .fillMaxHeight()
                        ) {
                            when (rightPaneMode) {
                                RightPaneMode.MAPS -> GoogleMapsPane(
                                    latitude = gpsTelemetry.latitude,
                                    longitude = gpsTelemetry.longitude,
                                    isInternetConnected = hardwareInfo.isInternetConnected,
                                    homeAddress = setupConfig.homeAddress,
                                    workAddress = setupConfig.workAddress,
                                    bearing = gpsTelemetry.bearingDegrees,
                                    speedKmh = effectiveSpeed,
                                    showRearCameraOverlay = showRearCameraOverlay,
                                    onCloseRearCamera = { viewModel.closeRearCameraOverlay() },
                                    onLaunchOem360Camera = { viewModel.launchOem360Camera() },
                                    onVoiceSearch = { viewModel.openVoiceAssistant() },
                                    onOpenGAppsHub = { viewModel.openGAppsHub() }
                                )
                                RightPaneMode.MEDIA_HUB -> MediaHubRightPane(
                                    viewModel = viewModel,
                                    onCloseToMap = { viewModel.openMap() },
                                    onOpenGAppsHub = { viewModel.openGAppsHub() }
                                )
                                RightPaneMode.VEHICLE_CONTROLS -> VehicleControlScreen(viewModel = viewModel)
                                RightPaneMode.BATTERY_ENERGY,
                                RightPaneMode.OBD_DIAGNOSTICS -> ObdDiagnosticsScreen(viewModel = viewModel)
                                RightPaneMode.PHONE_DIALER -> PhoneDialerPane(onClose = { viewModel.openMap() })
                                RightPaneMode.DRIVER_PROFILES -> DriverProfilesScreen(viewModel = viewModel)
                                RightPaneMode.SYSTEM_DIAGNOSTICS -> SystemDiagnosticsScreen(viewModel = viewModel)
                            }
                        }
                    }
                } else {
                    // Portrait Handheld Adaptive Mode
                    Column(modifier = Modifier.fillMaxSize()) {
                        LeftDrivingPane(
                            effectiveSpeed = effectiveSpeed,
                            selectedGear = selectedGear,
                            outsideTempC = outsideTempC,
                            insideTempC = insideTempC,
                            batteryRangeKm = batteryRangeKm,
                            batterySocPercent = batterySocPercent,
                            isObdConnected = isObdConnected,
                            deviceBatteryPct = hardwareInfo.internalBatteryLevel,
                            isBluetoothConnected = hardwareInfo.isBluetoothAvailable,
                            isWifiConnected = hardwareInfo.isInternetConnected,
                            radarDistanceCm = radarDistanceCm,
                            nowPlaying = nowPlaying,
                            onGearSelect = { viewModel.setGear(it) },
                            onTogglePlayMedia = { viewModel.toggleActiveMediaPlayPause() },
                            onPrevMedia = { viewModel.previousActiveMedia() },
                            onNextMedia = { viewModel.nextActiveMedia() },
                            onClickMediaCard = { viewModel.openMediaHub() },
                            onSelectMediaSource = { src ->
                                viewModel.mediaCoordinator.selectMediaSource(src)
                                viewModel.openMediaHub()
                            },
                            use3DCarView = use3DCarView,
                            onToggle3DCarView = { viewModel.toggle3DCarView() },
                            carColorHex = carColorHex,
                            doorsOpen = vehicleState.doorsOpen,
                            isHoodOpen = vehicleState.hoodOpen,
                            isTrunkOpen = vehicleState.trunkOpen,
                            isChargePortOpen = vehicleState.chargePortOpen,
                            isHeadlightOn = vehicleState.lowBeamOn || vehicleState.highBeamOn,
                            isLeftSignalOn = vehicleState.leftSignalOn,
                            isRightSignalOn = vehicleState.rightSignalOn,
                            isHazardOn = vehicleState.hazardLightsOn,
                            isBrakeOn = vehicleState.brakeLightOn,
                            isCharging = vehicleState.isCharging,
                            chargeMinutesRemaining = vehicleState.chargeMinutesRemaining,
                            onStopCharging = { viewModel.stopCharging() },
                            onToggleTrunk = { viewModel.toggleTrunk() },
                            activeProfileName = profileName,
                            tripDurationText = tripDurationText,
                            odometerKm = vehicleState.odometerKm,
                            avgConsumptionKwh = vehicleState.avgConsumptionKwh100Km,
                            tirePressuresBar = vehicleState.tirePressuresBar,
                            onOpenProfiles = { viewModel.openDriverProfiles() },
                            onOpenSettings = { viewModel.openVehicleControls() },
                            onToggleTheme = { viewModel.toggleDarkTheme() },
                            modifier = Modifier
                                .weight(0.45f)
                                .fillMaxWidth()
                        )

                        Box(
                            modifier = Modifier
                                .weight(0.55f)
                                .fillMaxWidth()
                        ) {
                            when (rightPaneMode) {
                                RightPaneMode.MAPS -> GoogleMapsPane(
                                    latitude = gpsTelemetry.latitude,
                                    longitude = gpsTelemetry.longitude,
                                    isInternetConnected = hardwareInfo.isInternetConnected,
                                    homeAddress = setupConfig.homeAddress,
                                    workAddress = setupConfig.workAddress,
                                    bearing = gpsTelemetry.bearingDegrees,
                                    speedKmh = effectiveSpeed,
                                    showRearCameraOverlay = showRearCameraOverlay,
                                    onCloseRearCamera = { viewModel.closeRearCameraOverlay() },
                                    onLaunchOem360Camera = { viewModel.launchOem360Camera() },
                                    onVoiceSearch = { viewModel.openVoiceAssistant() },
                                    onOpenGAppsHub = { viewModel.openGAppsHub() }
                                )
                                RightPaneMode.MEDIA_HUB -> MediaHubRightPane(
                                    viewModel = viewModel,
                                    onCloseToMap = { viewModel.openMap() },
                                    onOpenGAppsHub = { viewModel.openGAppsHub() }
                                )
                                RightPaneMode.VEHICLE_CONTROLS -> VehicleControlScreen(viewModel = viewModel)
                                RightPaneMode.BATTERY_ENERGY,
                                RightPaneMode.OBD_DIAGNOSTICS -> ObdDiagnosticsScreen(viewModel = viewModel)
                                RightPaneMode.PHONE_DIALER -> PhoneDialerPane(onClose = { viewModel.openMap() })
                                RightPaneMode.DRIVER_PROFILES -> DriverProfilesScreen(viewModel = viewModel)
                                RightPaneMode.SYSTEM_DIAGNOSTICS -> SystemDiagnosticsScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }

            // Bottom Full-Width HVAC & Touch Dock
            AutomotiveBottomHvacDock(
                driverTempC = driverTempC,
                fanLevel = fanLevel,
                driverSeatHeatingLevel = driverSeatHeating,
                passengerSeatHeatingLevel = passengerSeatHeating,
                volumeLevel = volumeLevel,
                activeTab = activeDockTab,
                onDriverTempChange = { viewModel.adjustDriverTemp(it) },
                onFanLevelChange = { viewModel.cycleFanLevel() },
                onDriverSeatHeatingChange = { viewModel.cycleDriverSeatHeating() },
                onPassengerSeatHeatingChange = { viewModel.cyclePassengerSeatHeating() },
                onVolumeChange = { viewModel.mediaCoordinator.adjustVolume(it) },
                onSelectDockTab = { viewModel.selectDockTab(it) },
                onCarSettingsClick = { viewModel.openVehicleControls() },
                onVoiceAssistantClick = { viewModel.openVoiceAssistant() },
                frontDefrostOn = frontDefrostOn,
                rearDefrostOn = rearDefrostOn,
                escEnabled = vehicleState.escEnabled,
                isMuted = isMuted,
                onToggleFrontDefrost = { viewModel.toggleFrontDefrost() },
                onToggleRearDefrost = { viewModel.toggleRearDefrost() },
                onToggleEsc = { viewModel.toggleEsc() },
                onToggleMute = { viewModel.mediaCoordinator.toggleMute() },
                onRecoveryClick = { viewModel.returnToStockLauncher() }
            )
        }

        // Action Toast Feedback Overlay (e.g. "Güvenlik: sadece P vitesinde" or VCU status)
        AnimatedVisibility(
            visible = actionToastMessage != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 14.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(colors.surface)
                    .border(1.dp, colors.stroke, RoundedCornerShape(16.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = colors.amber, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = actionToastMessage ?: "",
                        color = colors.text,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Voice Assistant Active Toast / Prompt Overlay
        AnimatedVisibility(
            visible = voiceState != VoiceState.IDLE,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 56.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(colors.surface)
                    .border(1.dp, colors.blue, RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (voiceState == VoiceState.LISTENING) {
                        CircularProgressIndicator(color = colors.blue, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                    } else {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = colors.blue, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = voicePrompt,
                        color = colors.text,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Skywell AI Voice Assistant Full Automotive Modal
        val showVoiceModal by viewModel.showVoiceAssistantModal.collectAsState()
        if (showVoiceModal) {
            SkywellVoiceAssistantDialog(
                voiceAssistant = viewModel.voiceAssistant,
                onDismiss = { viewModel.closeVoiceAssistant() }
            )
        }

        // Skywell GApps & Standalone APK Manager Dialog
        if (showGAppsHub) {
            SkywellGAppsHubDialog(
                gappsManager = viewModel.gappsManager,
                onDismiss = { viewModel.closeGAppsHub() }
            )
        }
    }
}
