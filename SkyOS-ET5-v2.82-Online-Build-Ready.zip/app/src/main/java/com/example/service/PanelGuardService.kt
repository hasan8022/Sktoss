package com.example.service

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * Replicates tr.halil.et5.PanelGuardService
 * Accessibility service that intercepts stock Skywell system UI popups
 * and ensures SkyOS ET5 remains full-screen and uninterrupted on the car display.
 */
class PanelGuardService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: ""
        if (pkg == "com.android.systemui" || pkg.contains("coolwell") || pkg.contains("skyworth")) {
            // Log and guard automotive full-screen display state
            Log.d("PanelGuard", "SystemUI window event intercepted from: $pkg")
        }
    }

    override fun onInterrupt() {
        Log.w("PanelGuard", "PanelGuard interrupted")
    }
}
