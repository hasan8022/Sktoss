# SkyOS ET5 — Gerçeklik ve entegrasyon durumu

Bu dosya kaynak kodundaki doğrulanmış sınırları açıklar. Bir ekranın bulunması, ilgili donanım veya servis entegrasyonunun çalıştığı anlamına gelmez.

## Bu çalışma turunda yapılan güvenilirlik düzeltmeleri

- Spotify HUD katmanındaki sabit örnek kullanıcı, çalma listesi ve şarkılar kaldırıldı.
- Spotify oturumu OAuth doğrulaması olmadan bağlı gösterilmiyor. Gerçek Web Player ayrı resmi web görünümü olarak bırakıldı.
- YouTube sabit/uydurma video kataloğu ve arama sorgusunu sahte video sonucuna dönüştüren kod kaldırıldı.
- YouTube gömülü oynatıcı yalnızca geçerli, kullanıcı tarafından seçilmiş 11 karakterlik video kimliği kabul ediyor.
- ET5'e ait olduğu kanıtlanmamış özel CAN kimlikleri, batarya hücre haritası ve fiziksel OBD pinout iddiaları kaldırıldı.
- SAE PID 0105 artık BMS/kabin sıcaklığı olarak etiketlenmiyor; bu PID genel tanımda motor soğutma sıvısı sıcaklığıdır.
- Genel PID 010C'nin EV motor devrini desteklediği varsayılmıyor.
- Doğrulanmamış SOC'den sabit 5.2 km/% çarpanıyla menzil türetimi kaldırıldı.
- Doğrulanmamış kabin/dış sıcaklık değerleri gerçek sensör verisi gibi sunulmuyor.
- OEM arayüzü bulunmadığı için klima, vites, far, kapı, bagaj ve koltuk ısıtma komutları gerçek araç komutu gibi çalıştırılmıyor. Araç kontrol ekranında kilit uyarısı gösteriliyor.

## Şu anda gerçek / kullanılabilir olabilecek parçalar

- Android GPS konum/hız sağlayıcısı: cihaz izinleri ve donanımına bağlıdır; gerçek cihaz testi gerekir.
- Bluetooth RFCOMM / Wi-Fi TCP üzerinden ELM327 bağlantı katmanı: adaptör ve araç ECU desteği gerekir. ELM327 adaptörüne soket açılması tek başına ET5 BMS verisi elde edildiği anlamına gelmez.
- Genel SAE OBD-II PID okuma: yalnızca ECU'nun gerçekten desteklediği PID'lerde geçerlidir.
- İnternet radyosu: MediaPlayer üzerinden yayın URL'leriyle oynatım denenebilir; her URL'nin güncel/çalışır olduğu doğrulanmadı.
- Resmi Spotify Web Player web görünümü ve resmi YouTube web/iframe oynatıcı yaklaşımı: hesap, ağ, WebView/cihaz ve sağlayıcı kısıtlarına bağlıdır.
- 3D ET5 model varlıkları: uygulama varlıklarında bulunur; gerçek araç telemetrisi değildir.

## Henüz tamamlanmamış / harici gereksinimli

- Spotify OAuth, kullanıcı kitaplığı ve gerçek App Remote / desteklenen oynatma kontrolü: Spotify Developer uygulama kimliği, yönlendirme URI'si, gerçek OAuth akışı ve gerçek cihaz/hesap testi gerekir.
- YouTube API araması: YouTube Data API anahtarı ve uygun kota/uygulama yapılandırması gerekir. Bu yapılandırma yokken uygulama sahte arama sonucu üretmez.
- Skywell ET5 BMS SOC/SoH, hücre voltajları, paket sıcaklığı, gerçek menzil ve şarj verisi: VIN/versiyonla eşleşen üretici protokol dokümanı ve gerçek donanım testi gerekir.
- Klima, kapı, bagaj, far, vites, koltuk ısıtma ve diğer aktüatörler: doğrulanmış OEM AIDL/HAL/MCU API'si veya üretici tarafından belgelenmiş güvenli protokol gerekir. Rastgele CAN komutu gönderilmeyecek.
- Google Maps: gerçek cihazda WebView/GMS/uygulama mevcutluğu ve ağ koşullarıyla test edilmelidir.
- Arka planda radyo, Android sürümleri ve otomotiv head-unit uyumluluğu: gerçek cihaz testi gerekir.

## Derleme / test notu

Bu kaynak paketi bu çalışma ortamında Android SDK + Gradle Wrapper JAR bulunmadığı için APK olarak derlenip çalıştırılamadı. `assembleDebug`, `testDebugUnitTest`, gerçek telefon testi ve Skywell ET5 araç testi başarılı olarak raporlanamaz. Android Studio'da açıp Gradle Sync ve test sonuçları alınmadan derlenmiş/çalışan APK iddiası yapılmamalıdır.

## Kritik güvenlik notu

Özel CAN kimliği, baud rate, pinout, BMS haritası veya OEM kontrol komutu tahmin edilerek gönderilmez. Önce pasif/okuma odaklı keşif, üretici dokümanı ve tezgâh/araç doğrulaması gerekir. Sürüş sırasında kritik araç kontrolleri uygulama tarafından etkinleştirilmez.

## APK-first reconstruction updates (2026-11-01)

- `VehicleBinaryManager` now reports only the `ET5H` four-byte container signature, file size and SHA-256. It no longer claims vehicle/license verification or invents a CAN matrix count.
- Setup wizard license card now states that the original files were extracted but license/VIN/VCU verification is not established.
- Setup defaults for model year 2023 remain; fabricated plate, driver, license and address defaults have been removed from save/load paths.
- Home/work address defaults in the map pane are blank.
- OBD technical screen no longer displays unverified pack capacity, cell series, pack voltage, motor output or physical pinout as verified facts.

See `APK_RECONSTRUCTION_NOTES.md` for DEX evidence and the next reverse-engineering steps.

## APK-first recovery status (2026-11-01)

- The complete APK ZIP payload has been extracted into `recovery_reference/full_apk_dump/`.
- `resources.arsc`, binary `AndroidManifest.xml`, and `classes.dex` are preserved in `recovery_reference/compiled_android/` as well as in the complete dump.
- Every original APK asset is copied without transformation into `app/src/main/assets/recovered_original/` for source-faithful reference and selective reuse.
- SHA-256 hashes and byte sizes are recorded in `APK_FULL_INVENTORY.json` and `APK_FULL_RECOVERY_REPORT.md`.
- This is a complete container/resource recovery, not a Kotlin decompilation. No original private signing key is recovered.
- Build was not run in this environment: the project has no `gradlew` launcher or `gradle-wrapper.jar`, and no system Gradle/Android SDK toolchain was found during inspection. Therefore no APK build success is claimed.
