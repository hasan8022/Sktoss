package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DriverProfileDao {
    @Query("SELECT * FROM driver_profiles ORDER BY id ASC")
    fun getAllProfiles(): Flow<List<DriverProfile>>

    @Query("SELECT * FROM driver_profiles WHERE isDefault = 1 LIMIT 1")
    fun getDefaultProfile(): Flow<DriverProfile?>

    @Query("SELECT * FROM driver_profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: Long): DriverProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: DriverProfile): Long

    @Update
    suspend fun updateProfile(profile: DriverProfile)

    @Delete
    suspend fun deleteProfile(profile: DriverProfile)

    @Query("UPDATE driver_profiles SET isDefault = 0")
    suspend fun clearDefaultFlags()

    @Query("UPDATE driver_profiles SET isDefault = 1 WHERE id = :id")
    suspend fun setDefaultProfile(id: Long)
}
