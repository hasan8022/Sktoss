package com.example.service.gapps

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class GAppPackageInfo(
    val id: String,
    val name: String,
    val packageName: String,
    val category: String,
    val description: String,
    val officialDownloadUrl: String,
    val isCoreGApps: Boolean = false,
    val isInstalled: Boolean = false,
    val installedVersion: String = "",
    val fallbackWebUrl: String = ""
)

/**
 * Manages Google Play Services (GMS), MicroG GmsCore, and official AOSP applications
 * for the Skywell ET5 multimedia head unit.
 *
 * Skywell ET5 vehicles typically run an AOSP (Android Open Source Project) firmware
 * without Google Mobile Services pre-installed. This manager enables:
 * 1. Detection of GMS / MicroG and standalone APK status.
 * 2. One-click launching of installed native apps.
 * 3. Guided APK downloading / sideloading for MicroG, Google Maps, Spotify, and YouTube.
 * 4. Fallback execution via embedded hardware-accelerated Web clients with cookie & session persistence.
 */
class SkywellGAppsManager(private val context: Context) {

    companion object {
        const val PKG_GMS = "com.google.android.gms"
        const val PKG_GSF = "com.google.android.gsf"
        const val PKG_PLAY_STORE = "com.android.vending"
        const val PKG_GOOGLE_MAPS = "com.google.android.apps.maps"
        const val PKG_SPOTIFY = "com.spotify.music"
        const val PKG_YOUTUBE = "com.google.android.youtube"
        const val PKG_NEWPIPE = "org.schabi.newpipe"

        val DEFAULT_PACKAGES = listOf(
            GAppPackageInfo(
                id = "microg_core",
                name = "MicroG GmsCore (GApps Çekirdeği)",
                packageName = PKG_GMS,
                category = "GApps Altyapısı",
                description = "Skywell ET5 multimedyasında Google Play Hizmetlerini simüle eden açık kaynaklı çekirdek. Google Harita ve YouTube için gereklidir.",
                officialDownloadUrl = "https://microg.org/download.html",
                isCoreGApps = true,
                fallbackWebUrl = "https://microg.org"
            ),
            GAppPackageInfo(
                id = "microg_gsf",
                name = "Google Services Framework Proxy",
                packageName = PKG_GSF,
                category = "GApps Altyapısı",
                description = "Google bulut bildirimleri ve servis kimlik doğrulama köprüsü.",
                officialDownloadUrl = "https://microg.org/download.html",
                isCoreGApps = true
            ),
            GAppPackageInfo(
                id = "play_store",
                name = "Google Play Store / FakeStore",
                packageName = PKG_PLAY_STORE,
                category = "Uygulama Mağazası",
                description = "Uygulamaların mağaza lisans doğrulamasını ve güncellemelerini sağlar.",
                officialDownloadUrl = "https://microg.org/download.html",
                isCoreGApps = true
            ),
            GAppPackageInfo(
                id = "google_maps",
                name = "Google Haritalar (Google Maps)",
                packageName = PKG_GOOGLE_MAPS,
                category = "Navigasyon",
                description = "Canlı trafik, uydu görüntüsü, sesli navigasyon ve arama destekli resmi Google Harita uygulaması.",
                officialDownloadUrl = "https://www.apkmirror.com/apk/google-inc/maps/",
                isCoreGApps = false,
                fallbackWebUrl = "https://www.google.com/maps"
            ),
            GAppPackageInfo(
                id = "spotify",
                name = "Spotify Müzik",
                packageName = PKG_SPOTIFY,
                category = "Medya & Akış",
                description = "Resmi Spotify müzik akışı, çalma listeleri, podcast ve arka plan oynatma desteği.",
                officialDownloadUrl = "https://www.spotify.com/download/android/",
                isCoreGApps = false,
                fallbackWebUrl = "https://open.spotify.com"
            ),
            GAppPackageInfo(
                id = "youtube",
                name = "YouTube Video",
                packageName = PKG_YOUTUBE,
                category = "Video & Eğlence",
                description = "Resmi YouTube video ve canlı yayın uygulaması. (Sürüş sırasında video güvenliği kilitlenir).",
                officialDownloadUrl = "https://www.apkmirror.com/apk/google-inc/youtube/",
                isCoreGApps = false,
                fallbackWebUrl = "https://m.youtube.com"
            ),
            GAppPackageInfo(
                id = "newpipe",
                name = "NewPipe (AOSP YouTube Alternatifi)",
                packageName = PKG_NEWPIPE,
                category = "AOSP Video",
                description = "Google Play Hizmetleri gerektirmeyen, hafif, reklamsız ve araç sistemleri için optimize edilmiş AOSP video oynatıcı.",
                officialDownloadUrl = "https://newpipe.net/#download",
                isCoreGApps = false,
                fallbackWebUrl = "https://m.youtube.com"
            )
        )
    }

    private val _packages = MutableStateFlow<List<GAppPackageInfo>>(emptyList())
    val packages: StateFlow<List<GAppPackageInfo>> = _packages.asStateFlow()

    private val _isGmsAvailable = MutableStateFlow(false)
    val isGmsAvailable: StateFlow<Boolean> = _isGmsAvailable.asStateFlow()

    init {
        refreshPackageStatus()
    }

    fun refreshPackageStatus() {
        val pm = context.packageManager
        var gmsDetected = false

        val updatedList = DEFAULT_PACKAGES.map { pkg ->
            try {
                val pInfo = pm.getPackageInfo(pkg.packageName, 0)
                if (pkg.packageName == PKG_GMS) {
                    gmsDetected = true
                }
                pkg.copy(
                    isInstalled = true,
                    installedVersion = pInfo.versionName ?: "v${pInfo.versionCode}"
                )
            } catch (_: PackageManager.NameNotFoundException) {
                pkg.copy(isInstalled = false, installedVersion = "")
            }
        }

        _packages.value = updatedList
        _isGmsAvailable.value = gmsDetected
    }

    fun isAppInstalled(packageName: String): Boolean {
        val pm = context.packageManager
        return try {
            pm.getPackageInfo(packageName, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun launchApp(packageName: String): Boolean {
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(packageName)
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
                true
            } catch (_: Exception) {
                false
            }
        } else {
            false
        }
    }

    fun openPackageDownload(pkg: GAppPackageInfo) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(pkg.officialDownloadUrl)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            // Fallback to web URL
            if (pkg.fallbackWebUrl.isNotBlank()) {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(pkg.fallbackWebUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(fallbackIntent)
                } catch (_: Exception) {}
            }
        }
    }

    fun getSkywellGAppsGuide(): List<String> {
        return listOf(
            "1. Skywell ET5 multimedya ekranı fabrika çıkışlı AOSP (Android 9/11) tabanlıdır ve varsayılan olarak Google Play Hizmetleri içermez.",
            "2. SkyOS, harici GApps paketine ihtiyaç duymadan Google Haritalar, Spotify ve YouTube'u yüksek performanslı dahili yerleşik motoruyla %100 çalıştırır.",
            "3. Yerel Android APK olarak kullanmak isterseniz, MicroG GmsCore paketini kurarak Google Play altyapısını aktif edebilirsiniz.",
            "4. Güvenlik Notu: Araç hareket halindeyken (hız > 5 km/s) YouTube video görüntüsü trafik kuralları gereği kilitlenir, arka planda güvenli ses akışı devam eder."
        )
    }
}
