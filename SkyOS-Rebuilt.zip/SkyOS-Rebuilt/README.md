# SkyOS ET5 — Tam Kapsamlı Araç Multimedya ve Kontrol Sistemi (v2.0)

Bu proje, **Skywell ET5** 3D araç sahnesi (`assets/car/`) ve **Leaflet** 3D perspektif navigasyon haritası (`assets/map-lite/`) varlıkları üzerine sıfırdan inşa edilmiş, hem **yatay (landscape) araç multimedya bölünmüş kokpit ekranı** hem de **dikey (portrait) telefon kontrol arayüzü** olarak çalışan tam kapsamlı bir Android Studio (Kotlin) uygulamasıdır.

## Öne Çıkan Özellikler

### 1. Uyarlanabilir Ekran Mimarisi (Yatay Kokpit & Dikey Telefon Modu)
- **Otomatik / Bölünmüş Kokpit Görünümü (Landscape / Tablet)**: Sol panelde canlı hız/vites/güç telemetrisi, etkileşimli 3D Skywell ET5 sahnesi ve hızlı gövde kontrolleri; sağ panelde 3D perspektif eğimli navigasyon haritası ve medya oynatıcı; alt barda kalıcı çift bölgeli klima (HVAC) şeridi ve 6 sekmeli dock bar yer alır.
- **Dikey Telefon Görünümü (Portrait)**: Tek dokunuşla üst bardaki **OTO EKRAN / BÖLÜNMÜŞ / DİKEY** butonuyla veya cihazı çevirerek telefon arayüzüne geçiş yapılabilir.
- **Kalıcı WebView Mimarisi**: Sekmeler veya ekran modları arasında geçiş yapılırken 3D WebGL sahnesi ve Leaflet haritası yeniden yüklenmez; durumları kesintisiz korunur.

### 2. Tam Etkileşimli 3D Skywell ET5 Kontrolleri (`CarJsBridge` ↔ `window.CAR`)
- **Gövde & Kapılar**: Sol Ön, Sağ Ön, Sol Arka, Sağ Arka kapılar (tek tek veya 4 kapı birden), Ön Kaput, Elektrikli Bagaj ve Şarj Kapağı animasyonlu açma/kapama.
- **Camlar & Sunroof**: 4 camı ayrı ayrı veya tek tuşla havalandırma modunda açma/kapama ve Panoramik Sunroof kontrolü.
- **Aydınlatma & Sinyaller**: Sol sinyal, sağ sinyal, dörtlü flaşör ve `SKYWELL` arka ışık barlı fren lambası animasyonları.
- **360° Park Sensörü & Radar**: Ön, arka ve yan mesafe yayları (yeşil/sarı/kırmızı shader efektleri) ve geri vitese (`R`) geçildiğinde otomatik kamera/sensör aktivasyonu.
- **Kamera Açıları & Boya Renkleri**: 9 hazır kamera açısı (`Park`, `Vitrin`, `Ön`, `Arka`, `Yan`, `Üst`, `Sensör`, `Yakın Ön`, `Yakın Arka`), 6 gövde rengi ve `et5.glb` (Yüksek Detay) / `et5-hafif.glb` (Performans) model geçişi.

### 3. 3D Perspektif Harita ve Navigasyon (`MapJsBridge` ↔ `window.LITE`)
- **Gece / Gündüz Harita Katmanları**: Carto Dark Matter (Gece) ve OpenStreetMap (Gündüz) harita döşemeleri otomatik yüklenir.
- **Canlı GPS ve Sürüş Simülasyonu**: Cihazın gerçek GPS verisini (`LocationManager`) dinler; ayrıca üst bardaki **SİM: AÇIK** butonuyla Ankara, İstanbul ve İzmir hazır rotalarında canlı sürüş, hız, batarya tüketimi, dönüş oku (`setArrow`) ve 3D kamera eğimi (`setNav`) simülasyonu çalıştırır.

### 4. Çift Bölgeli Klima (HVAC), Medya ve OBD-II / CAN-Bus
- **Klima (HVAC)**: Sürücü ve yolcu bağımsız sıcaklık ayarı (16.0°C – 30.0°C), 7 kademeli fan, A/C, AUTO, iç sirkülasyon, ön/arka cam buğu çözücü ve 3 kademeli koltuk ısıtma.
- **Medya & İletişim**: Dahili çalma listesi / radyo istasyonu geçişi, telefon arama ekranı ve Bluetooth ayar kısayolları.
- **OBD-II / ELM327 Bluetooth Telemetri**: Eşleşmiş Bluetooth ELM327 adaptörlerine RFCOMM/SPP (`00001101-0000-1000-8000-00805F9B34FB`) üzerinden bağlanarak canlı hız (`010D`), motor devri (`010C`) ve batarya (`015B`) PID verilerini okur.

##Proje Yapısı
- `app/src/main/java/com/skyos/rebuilt/MainActivity.kt` — Uyarlanabilir kokpit/telefon arayüzü, GPS dinleyicisi ve tüm sekme görünümleri
- `app/src/main/java/com/skyos/rebuilt/VehicleState.kt` — Araç, harita, klima, medya ve OBD-II veri modeli
- `app/src/main/java/com/skyos/rebuilt/WebBridge.kt` — `window.Et5` (`CarJsBridge`) ve `window.Et5Map` (`MapJsBridge`) JavaScript köprüleri
- `app/src/main/java/com/skyos/rebuilt/TelemetryAndNavEngine.kt` — Canlı sürüş/rota simülatörü ve Bluetooth ELM327 OBD-II istemcisi
- `app/src/main/assets/car/` — Three.js + GLTFLoader + Skywell ET5 3D modelleri (`et5.glb`, `et5-hafif.glb`)
- `app/src/main/assets/map-lite/` — Leaflet 3D perspektif harita motoru

## Android Studio ile Derleme
1. ZIP arşivini çıkarın ve `SkyOS-Rebuilt` klasörünü **Android Studio** ile açın.
2. Gradle senkronizasyonunun tamamlanmasını bekleyin (JDK 17 uyumludur).
3. Android cihazınızı veya emülatörünüzü seçip **Run (▶)** tuşuna basın.
