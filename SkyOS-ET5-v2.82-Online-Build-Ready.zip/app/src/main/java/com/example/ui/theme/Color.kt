package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Exact SkyOS 2.82 color system recovered from classes.dex (LCx; and LMw0;<clinit>).
 * Supports both Dark Theme (LMw0.a) and Light Theme (LMw0.b) as seen in
 * reference_dashboard_dark.jpg and reference_dashboard_light.jpg.
 */
@Immutable
data class Et5Colors(
    val isDark: Boolean,
    val bg: Color,
    val surface: Color,
    val surface2: Color,
    val surface3: Color,
    val stroke: Color,
    val text: Color,
    val text2: Color,
    val text3: Color,
    val glass: Color,
    val mapBg: Color,
    val mapBlock: Color,
    val mapRoad: Color,
    val blue: Color = Color(0xFF3E6AE1),
    val heat: Color = Color(0xFFE8523F),
    val cool: Color = Color(0xFF3A8BFF),
    val green: Color = Color(0xFF34C759),
    val amber: Color = Color(0xFFFFB020),
    val red: Color = Color(0xFFFF3B30)
)

val DarkEt5Colors = Et5Colors(
    isDark = true,
    bg = Color(0xFF000000),
    surface = Color(0xFF111214),
    surface2 = Color(0xFF1A1B1E),
    surface3 = Color(0xFF232428),
    stroke = Color(0x12FFFFFF),
    text = Color(0xFFF4F5F7),
    text2 = Color(0xFF9B9EA4),
    text3 = Color(0xFF5C5F66),
    glass = Color(0xC716171A),
    mapBg = Color(0xFF15181C),
    mapBlock = Color(0xFF1B1F24),
    mapRoad = Color(0xFF2A3038)
)

val LightEt5Colors = Et5Colors(
    isDark = false,
    bg = Color(0xFFF3F4F6),
    surface = Color(0xFFFFFFFF),
    surface2 = Color(0xFFF1F2F4),
    surface3 = Color(0xFFE6E8EB),
    stroke = Color(0x0F000000),
    text = Color(0xFF15181C),
    text2 = Color(0xFF6B6F76),
    text3 = Color(0xFFA5A9B0),
    glass = Color(0xD1FFFFFF),
    mapBg = Color(0xFFE9EBEE),
    mapBlock = Color(0xFFF3F4F6),
    mapRoad = Color(0xFFFFFFFF)
)

val LocalEt5Colors = staticCompositionLocalOf { DarkEt5Colors }

// Backward-compatible semantic aliases used across screens
val SkyNavy = Color(0xFF070B14)
val SkyDeepCockpit = Color(0xFF0A0F1D)
val SkySurface = Color(0xFF111214)
val SkySurfaceVariant = Color(0xFF1A1B1E)
val SkyCard = Color(0xFF16181D)
val SkyCardHover = Color(0xFF232428)
val SkyGlassCard = Color(0xD916171A)

val SkyCyan = Color(0xFF3A8BFF)
val SkyCyanDark = Color(0xFF2968C8)
val SkyCyanGlow = Color(0x223A8BFF)

val SkyElectricBlue = Color(0xFF3E6AE1)
val SkyAmber = Color(0xFFFFB020)
val SkyOrange = Color(0xFFE8523F)
val SkyGreen = Color(0xFF34C759)
val SkyRed = Color(0xFFFF3B30)

val SkyRadarWarning = Color(0xFFFF9100)
val SkyRoadGrey = Color(0xFF1E2838)
val SkyLaneMarker = Color(0x99FFFFFF)

val SkyTextPrimary = Color(0xFFF4F5F7)
val SkyTextSecondary = Color(0xFF9B9EA4)
val SkyTextMuted = Color(0xFF5C5F66)

val SkyBorder = Color(0xFF232428)
val SkyDivider = Color(0xFF1A1B1E)
