package com.skyos.rebuilt

data class RoutePreset(
    val id: String,
    val title: String,
    val subtitle: String,
    val distanceKm: Double,
    val durationMin: Int,
    val points: List<Pair<Double, Double>>,
    val nextTurnText: String,
    val nextTurnDistM: Int
)

data class MediaTrack(
    val title: String,
    val artist: String,
    val source: String,
    val durationSec: Int
)

class VehicleState {
    // Sürüş & Telemetri
    var speedKmh: Int = 0
    var gear: String = "P" // P, R, N, D, S
    var driveMode: String = "COMFORT" // ECO, COMFORT, SPORT, TEK PEDAL
    var batterySoc: Int = 84
    var rangeKm: Int = 436
    var powerKw: Double = 0.0
    var voltageV: Double = 396.4
    var motorRpm: Int = 0
    var odometerKm: Double = 14820.6
    var exteriorTempC: Double = 19.5
    var tirePressuresBar: FloatArray = floatArrayOf(2.4f, 2.4f, 2.5f, 2.5f)
    var isLocked: Boolean = false
    var isSimulationActive: Boolean = false

    // 3D Araç Gövde & Parça Durumları
    val doors: BooleanArray = booleanArrayOf(false, false, false, false) // dFL, dFR, dRL, dRR
    val windows: BooleanArray = booleanArrayOf(false, false, false, false) // Sol Ön, Sağ Ön, Sol Arka, Sağ Arka
    var hoodOpen: Boolean = false
    var trunkOpen: Boolean = false
    var chargePortOpen: Boolean = false
    var sunroofOpen: Boolean = false

    // Işıklar & Sinyaller
    var leftSignal: Boolean = false
    var rightSignal: Boolean = false
    var hazardLights: Boolean = false
    var brakeLights: Boolean = false
    var headlightsOn: Boolean = true

    // 3D Kamera, Renk ve Model Seçimi
    var cameraView: String = "parked" // parked, hero, front, rear, side, top, park, yakinOn, yakinArka
    var paintColorHex: String = "#E9EBF0"
    var paintColorName: String = "İnci Beyazı"
    var useLiteModel: Boolean = false // false = et5.glb, true = et5-hafif.glb
    var stopThresholdM: Double = 0.35

    // Park Sensörü Mesafeleri (Metre: 0.15m - 1.8m)
    var parkSensorsActive: Boolean = false
    val frontSensors: FloatArray = floatArrayOf(1.45f, 1.20f, 1.20f, 1.45f)
    val rearSensors: FloatArray = floatArrayOf(1.30f, 0.85f, 0.85f, 1.30f)
    val sideSensors: FloatArray = floatArrayOf(1.10f, 1.10f, 1.10f, 1.10f)
    var frontMinLabelDist: Float = -1f
    var rearMinLabelDist: Float = -1f

    // Harita & Navigasyon Durumu
    var mapDarkTheme: Boolean = true
    var mapFollow: Boolean = true
    var mapNavActive: Boolean = false
    var mapHeadUp3D: Boolean = true
    var currentLat: Double = 39.9208 // Ankara Kızılay / Söğütözü varsayılan
    var currentLng: Double = 32.8541
    var currentBearing: Double = 45.0
    var activeRouteIndex: Int = 0
    var routeProgressFrac: Double = 0.0
    var gpsStatusText: String = "Hazır (Simülasyon / GPS)"

    // Klima (HVAC) & Konfor
    var hvacPower: Boolean = true
    var tempLeftC: Double = 21.5
    var tempRightC: Double = 22.0
    var fanLevel: Int = 3 // 1..7
    var acEnabled: Boolean = true
    var autoClimate: Boolean = true
    var recirculate: Boolean = false
    var frontDefrost: Boolean = false
    var rearDefrost: Boolean = false
    var seatHeatLeft: Int = 0 // 0..3
    var seatHeatRight: Int = 0 // 0..3

    // Medya Oynatıcı
    var mediaPlaying: Boolean = true
    var mediaTrackIndex: Int = 0
    var mediaProgressSec: Int = 48
    var mediaVolume: Int = 65

    // OBD-II / Bluetooth Durumu
    var obdConnected: Boolean = false
    var obdDeviceName: String = "Bağlı Değil"
    var obdProtocol: String = "ISO 15765-4 CAN (11 bit ID, 500 kbaud)"
    var obdStatusLog: String = "ELM327 / CAN-Bus adaptörü bekleniyor veya simülasyon başlatılabilir."

    // Ekran Yerleşim Modu
    // AUTO: yatayda bölünmüş kokpit, dikeyde sekme görünümü; SPLIT: her zaman bölünmüş; TAB: sekme modu
    var layoutMode: String = "AUTO"

    val paintPalette = listOf(
        "İnci Beyazı" to "#E9EBF0",
        "Gece Mavisi" to "#152238",
        "Obsidyen Siyah" to "#141619",
        "Kuvars Gri" to "#6E7582",
        "Sky Turkuaz" to "#1F7A73",
        "Ateş Kırmızısı" to "#9E1B24"
    )

    val cameraPresets = listOf(
        "Park" to "parked",
        "Vitrin" to "hero",
        "Ön" to "front",
        "Arka" to "rear",
        "Yan" to "side",
        "Üst" to "top",
        "Sensör" to "park",
        "Yakın Ön" to "yakinOn",
        "Yakın Arka" to "yakinArka"
    )

    val tracks = listOf(
        MediaTrack("Gece Sürüşü (Synthwave Mix)", "SkyOS Ses Sistemi", "Bluetooth Ses", 214),
        MediaTrack("Boğaziçi Rüzgarı (Akustik)", "Anadolu Caz Ensemble", "SkyOS Kayıpsız", 188),
        MediaTrack("TRT FM 93.3 — Canlı Yayın", "RDS: SKYWELL ET5", "FM / DAB+ Radyo", 3600),
        MediaTrack("Otoyol Ritmi (Lo-Fi Beats)", "Elektrikli Rota", "USB Medya", 195)
    )

    val routes = listOf(
        RoutePreset(
            id = "ankara_armada_ankamall",
            title = "Söğütözü → Kızılay → Tunalı Hilmi",
            subtitle = "Ankara Şehir İçi Hızlı Şarj Rotası",
            distanceKm = 6.8,
            durationMin = 12,
            points = listOf(
                39.9125 to 32.8115,
                39.9148 to 32.8210,
                39.9175 to 32.8325,
                39.9195 to 32.8430,
                39.9208 to 32.8541,
                39.9155 to 32.8582,
                39.9082 to 32.8615,
                39.9035 to 32.8632
            ),
            nextTurnText = "400 m sonra Atatürk Bulvarı yönüne sağa dönün",
            nextTurnDistM = 400
        ),
        RoutePreset(
            id = "istanbul_avrupa_asya",
            title = "Beşiktaş → 15 Temmuz Şehitler Köprüsü → Kadıköy",
            subtitle = "İstanbul Boğaz Geçişi Rotası",
            distanceKm = 14.2,
            durationMin = 24,
            points = listOf(
                41.0422 to 29.0067,
                41.0480 to 29.0155,
                41.0455 to 29.0340,
                41.0410 to 29.0445,
                41.0255 to 29.0420,
                41.0085 to 29.0320,
                40.9910 to 29.0230
            ),
            nextTurnText = "650 m sonra Köprü katılım şeridinde kalın",
            nextTurnDistM = 650
        ),
        RoutePreset(
            id = "izmir_kordon",
            title = "Konak Meydanı → Alsancak Kordon → Bayraklı",
            subtitle = "İzmir Körfez Sahil Rotası",
            distanceKm = 9.4,
            durationMin = 16,
            points = listOf(
                38.4189 to 27.1287,
                38.4255 to 27.1325,
                38.4330 to 27.1380,
                38.4410 to 27.1435,
                38.4520 to 27.1580,
                38.4622 to 27.1665
            ),
            nextTurnText = "300 m sonra Cumhuriyet Bulvarı boyunca devam edin",
            nextTurnDistM = 300
        )
    )
}
