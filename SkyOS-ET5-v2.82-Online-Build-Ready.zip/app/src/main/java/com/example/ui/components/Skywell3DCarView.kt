package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCard
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyNavy
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary

class Et5JavascriptBridge(
    private val onPartClicked: (String) -> Unit,
    private val onModelReady: () -> Unit
) {
    @JavascriptInterface
    fun onPart(part: String) {
        onPartClicked(part)
    }

    @JavascriptInterface
    fun onLabel(name: String, x: Double, y: Double, dist: Double) {
        // Optional distance label telemetry
    }

    @JavascriptInterface
    fun ready() {
        onModelReady()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun Skywell3DCarView(
    doors: List<Boolean> = listOf(false, false, false, false), // 0: FL, 1: FR, 2: RL, 3: RR
    isHoodOpen: Boolean = false,
    isTrunkOpen: Boolean = false,
    isChargePortOpen: Boolean = false,
    isHeadlightOn: Boolean = false,
    isLeftSignalOn: Boolean = false,
    isRightSignalOn: Boolean = false,
    isHazardOn: Boolean = false,
    isBrakeOn: Boolean = false,
    radarDistanceCm: Int? = null,
    carColorHex: Int = 15330028, // Default Moon Silver
    activeView: String = "parked", // 'hero', 'parked', 'side', 'top', 'park', 'rear', 'front', 'yakinOn'
    onPartTap: (String) -> Unit = {},
    showControls: Boolean = true,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isReady by remember { mutableStateOf(false) }
    var currentView by remember { mutableStateOf(activeView) }
    var currentColor by remember { mutableStateOf(carColorHex) }

    // Color choices for Skywell ET5
    val colorPresets = remember {
        listOf(
            "Ay Gümüşü" to 15330028,    // #E9EAF0
            "Okyanus Mavisi" to 1858450, // #1C5B92
            "Lav Kırmızısı" to 10815758, // #A5090E
            "Gece Siyahı" to 1184274     // #121212
        )
    }

    // Camera view angles
    val viewPresets = remember {
        listOf(
            "Park" to "parked",
            "360°" to "hero",
            "Ön" to "front",
            "Yan" to "side",
            "Arka" to "rear",
            "Üst" to "top"
        )
    }

    // Asset Loader for local Three.js & GLB files
    val assetLoader = remember {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
    }

    // Sync State to 3D Three.js Model whenever inputs change
    LaunchedEffect(
        isReady,
        doors,
        isHoodOpen,
        isTrunkOpen,
        isChargePortOpen,
        isHeadlightOn,
        isLeftSignalOn,
        isRightSignalOn,
        isHazardOn,
        isBrakeOn
    ) {
        if (!isReady || webViewRef == null) return@LaunchedEffect
        val d0 = if (doors.getOrElse(0) { false }) 1 else 0
        val d1 = if (doors.getOrElse(1) { false }) 1 else 0
        val d2 = if (doors.getOrElse(2) { false }) 1 else 0
        val d3 = if (doors.getOrElse(3) { false }) 1 else 0

        val jsCode = """
            if (window.CAR && window.CAR.state) {
                window.CAR.state({
                    doors: [$d0, $d1, $d2, $d3],
                    hood: $isHoodOpen,
                    trunk: $isTrunkOpen,
                    charge: $isChargePortOpen,
                    left: $isLeftSignalOn,
                    right: $isRightSignalOn,
                    hazard: $isHazardOn,
                    brake: $isBrakeOn
                });
            }
        """.trimIndent()
        webViewRef?.evaluateJavascript(jsCode, null)
    }

    // Sync Parking Radar to 3D Radar waves
    LaunchedEffect(isReady, radarDistanceCm) {
        if (!isReady || webViewRef == null) return@LaunchedEffect
        val distMeters = if (radarDistanceCm != null) {
            (radarDistanceCm / 100f).coerceIn(0.2f, 2.5f)
        } else {
            0f
        }
        val frontList = if (distMeters > 0) "[$distMeters, $distMeters, $distMeters, $distMeters]" else "null"
        val rearList = if (distMeters > 0) "[$distMeters, $distMeters, $distMeters, $distMeters]" else "null"
        val jsCode = """
            if (window.CAR && window.CAR.park) {
                window.CAR.park($frontList, $rearList, null);
            }
        """.trimIndent()
        webViewRef?.evaluateJavascript(jsCode, null)
    }

    // Sync Camera Angle
    LaunchedEffect(isReady, currentView) {
        if (!isReady || webViewRef == null) return@LaunchedEffect
        webViewRef?.evaluateJavascript(
            "if (window.CAR && window.CAR.view) { window.CAR.view('$currentView', 800); }",
            null
        )
    }

    // Sync Car Paint Color
    LaunchedEffect(isReady, currentColor) {
        if (!isReady || webViewRef == null) return@LaunchedEffect
        webViewRef?.evaluateJavascript(
            "if (window.CAR && window.CAR.setColor) { window.CAR.setColor($currentColor); }",
            null
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("skywell_3d_car_view")
    ) {
        // Real 3D WebGL Canvas via WebView
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(Color.TRANSPARENT)
                    setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)

                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        allowFileAccess = true
                        allowContentAccess = true
                        loadWithOverviewMode = true
                        useWideViewPort = true
                        cacheMode = WebSettings.LOAD_DEFAULT
                        mediaPlaybackRequiresUserGesture = false
                    }

                    addJavascriptInterface(
                        Et5JavascriptBridge(
                            onPartClicked = { part ->
                                onPartTap(part)
                            },
                            onModelReady = {
                                isReady = true
                            }
                        ),
                        "Et5"
                    )

                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView,
                            request: WebResourceRequest
                        ): WebResourceResponse? {
                            return assetLoader.shouldInterceptRequest(request.url)
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            isReady = true
                        }
                    }

                    loadUrl("https://appassets.androidplatform.net/assets/car/index.html")
                    webViewRef = this
                }
            },
            update = {
                webViewRef = it
            }
        )

        // Loading indicator while 3D GLB model loads into memory
        AnimatedVisibility(
            visible = !isReady,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .background(SkyNavy.copy(alpha = 0.85f), RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                CircularProgressIndicator(color = SkyCyan, strokeWidth = 3.dp)
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Skywell ET5 3D Model Yükleniyor…",
                    color = SkyTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // On-Screen Interactive Controls Bar (Camera Presets & Color Selector)
        if (showControls) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Top control: Quick View Angle Selector Pills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = SkyCard.copy(alpha = 0.88f),
                        shape = RoundedCornerShape(20.dp),
                        tonalElevation = 4.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            viewPresets.forEach { (label, key) ->
                                val isSelected = currentView == key
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(if (isSelected) SkyCyan.copy(alpha = 0.25f) else androidx.compose.ui.graphics.Color.Transparent)
                                        .clickable {
                                            currentView = key
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) SkyCyan else SkyTextSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            // Color cycle dots
                            colorPresets.forEach { (_, hex) ->
                                val isSelected = currentColor == hex
                                val composeColor = androidx.compose.ui.graphics.Color(
                                    (hex shr 16) and 0xFF,
                                    (hex shr 8) and 0xFF,
                                    hex and 0xFF
                                )
                                Box(
                                    modifier = Modifier
                                        .size(if (isSelected) 18.dp else 14.dp)
                                        .background(composeColor, CircleShape)
                                        .clip(CircleShape)
                                        .clickable {
                                            currentColor = hex
                                        }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
