package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCard
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyNavy
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SkywellVehicleVisualizer(
    rotationAngle: Float,
    isHeadlightOn: Boolean,
    isDoorOpen: Boolean,
    isTrunkOpen: Boolean,
    onRotate: (Float) -> Unit,
    onResetRotation: () -> Unit,
    onToggleHeadlights: () -> Unit,
    onToggleDoor: () -> Unit,
    onToggleTrunk: () -> Unit,
    modifier: Modifier = Modifier
) {
    var is3dMode by remember { mutableStateOf(true) }

    Box(
        modifier = modifier
            .background(SkyCard, RoundedCornerShape(16.dp))
            .padding(12.dp)
            .testTag("skywell_vehicle_visualizer")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Visualizer Header & Specs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SKYWELL ET5",
                        color = SkyTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (is3dMode) "3D Gerçek WebGL Model (Three.js)" else "360° Şematik Görünüm",
                        color = SkyCyan,
                        fontSize = 11.sp
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .background(if (is3dMode) SkyCyan.copy(alpha = 0.25f) else Color.Transparent, RoundedCornerShape(8.dp))
                            .clickable { is3dMode = !is3dMode }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (is3dMode) "3D Aktif" else "2D Aktif",
                            color = if (is3dMode) SkyCyan else SkyTextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(
                        onClick = onResetRotation,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Açıyı Sıfırla",
                            tint = SkyTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Interactive 360 Visualizer (3D WebGL or 2D Canvas)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                if (is3dMode) {
                    Skywell3DCarView(
                        doors = listOf(isDoorOpen, false, false, false),
                        isTrunkOpen = isTrunkOpen,
                        isHeadlightOn = isHeadlightOn,
                        onPartTap = { part ->
                            when (part) {
                                "dFL", "dFR", "dRL", "dRR" -> onToggleDoor()
                                "trunk" -> onToggleTrunk()
                                "hood" -> onToggleDoor()
                            }
                        },
                        showControls = true,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    onRotate(dragAmount.x * 0.7f)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawVehicleChassis(
                                angle = rotationAngle,
                                headlightActive = isHeadlightOn,
                                doorActive = isDoorOpen,
                                trunkActive = isTrunkOpen
                            )
                        }

                        Text(
                            text = "Açıyı değiştirmek için kaydırın (${rotationAngle.toInt()}°)",
                            color = SkyTextMuted,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 4.dp)
                        )
                    }
                }
            }

            // Hardware Action Controls (Headlight, Door, Trunk)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SkyNavy, RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onToggleHeadlights,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (isHeadlightOn) SkyCyan else SkyTextSecondary
                    ),
                    modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Highlight,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isHeadlightOn) "Farlar: Açık" else "Farlar",
                        fontSize = 11.sp
                    )
                }

                OutlinedButton(
                    onClick = onToggleDoor,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (isDoorOpen) SkyAmber else SkyTextSecondary
                    ),
                    modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                ) {
                    Icon(
                        imageVector = if (isDoorOpen) Icons.Default.LockOpen else Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isDoorOpen) "Kapı: Açık" else "Kapı",
                        fontSize = 11.sp
                    )
                }

                OutlinedButton(
                    onClick = onToggleTrunk,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (isTrunkOpen) SkyGreen else SkyTextSecondary
                    ),
                    modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                ) {
                    Text(
                        text = if (isTrunkOpen) "Bagaj: Açık" else "Bagaj",
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawVehicleChassis(
    angle: Float,
    headlightActive: Boolean,
    doorActive: Boolean,
    trunkActive: Boolean
) {
    val centerX = size.width / 2f
    val centerY = size.height / 2f
    val carWidth = size.width * 0.38f
    val carLength = size.height * 0.65f

    // Grid Floor
    val gridColor = Color(0x1500E5FF)
    for (i in -4..4) {
        drawLine(
            color = gridColor,
            start = Offset(centerX + i * 36f, centerY - 120f),
            end = Offset(centerX + i * 36f, centerY + 120f),
            strokeWidth = 1f
        )
        drawLine(
            color = gridColor,
            start = Offset(centerX - 144f, centerY + i * 30f),
            end = Offset(centerX + 144f, centerY + i * 30f),
            strokeWidth = 1f
        )
    }

    // Car Body Shadow & Rotating Model
    rotate(degrees = angle, pivot = Offset(centerX, centerY)) {
        // Drop Shadow
        drawOval(
            color = Color(0x55000000),
            topLeft = Offset(centerX - carWidth / 2f - 10f, centerY - carLength / 2f - 6f),
            size = Size(carWidth + 20f, carLength + 12f)
        )

        // Headlight Beams (Front is top of car)
        if (headlightActive) {
            val beamBrush = Brush.verticalGradient(
                colors = listOf(Color(0x9900E5FF), Color(0x0000E5FF)),
                startY = centerY - carLength / 2f - 90f,
                endY = centerY - carLength / 2f
            )
            val leftBeam = Path().apply {
                moveTo(centerX - carWidth * 0.4f, centerY - carLength / 2f)
                lineTo(centerX - carWidth * 0.9f, centerY - carLength / 2f - 90f)
                lineTo(centerX - carWidth * 0.1f, centerY - carLength / 2f - 90f)
                close()
            }
            val rightBeam = Path().apply {
                moveTo(centerX + carWidth * 0.4f, centerY - carLength / 2f)
                lineTo(centerX + carWidth * 0.1f, centerY - carLength / 2f - 90f)
                lineTo(centerX + carWidth * 0.9f, centerY - carLength / 2f - 90f)
                close()
            }
            drawPath(leftBeam, beamBrush)
            drawPath(rightBeam, beamBrush)
        }

        // Main Vehicle Body (Skywell ET5 SUV Aerodynamic Outline)
        val bodyColor = Color(0xFF0F233A)
        val bodyStroke = Color(0xFF00E5FF)

        val carPath = Path().apply {
            val l = centerX - carWidth / 2f
            val r = centerX + carWidth / 2f
            val t = centerY - carLength / 2f
            val b = centerY + carLength / 2f

            moveTo(l + 16f, t + 10f)
            // Front Bumper curve
            quadraticBezierTo(centerX, t - 4f, r - 16f, t + 10f)
            // Right Front Fender
            lineTo(r, t + carLength * 0.22f)
            // Right Body Side
            lineTo(r, b - carLength * 0.22f)
            // Right Rear Fender
            lineTo(r - 10f, b)
            // Rear Bumper
            quadraticBezierTo(centerX, b + 6f, l + 10f, b)
            // Left Rear Fender
            lineTo(l, b - carLength * 0.22f)
            // Left Body Side
            lineTo(l, t + carLength * 0.22f)
            // Left Front Fender
            close()
        }

        drawPath(carPath, color = bodyColor)
        drawPath(carPath, color = bodyStroke, style = Stroke(width = 2.5f))

        // Panoramic Sunroof & Windshield
        val glassColor = Color(0xFF070E1A)
        val glassStroke = Color(0x6600E5FF)

        // Front Windshield
        drawRoundRect(
            color = glassColor,
            topLeft = Offset(centerX - carWidth * 0.35f, centerY - carLength * 0.32f),
            size = Size(carWidth * 0.7f, carLength * 0.18f),
            cornerRadius = CornerRadius(8f, 8f)
        )
        drawRoundRect(
            color = glassStroke,
            topLeft = Offset(centerX - carWidth * 0.35f, centerY - carLength * 0.32f),
            size = Size(carWidth * 0.7f, carLength * 0.18f),
            cornerRadius = CornerRadius(8f, 8f),
            style = Stroke(width = 1.2f)
        )

        // Panoramic Glass Roof
        drawRoundRect(
            color = glassColor,
            topLeft = Offset(centerX - carWidth * 0.32f, centerY - carLength * 0.12f),
            size = Size(carWidth * 0.64f, carLength * 0.32f),
            cornerRadius = CornerRadius(6f, 6f)
        )
        drawRoundRect(
            color = glassStroke,
            topLeft = Offset(centerX - carWidth * 0.32f, centerY - carLength * 0.12f),
            size = Size(carWidth * 0.64f, carLength * 0.32f),
            cornerRadius = CornerRadius(6f, 6f),
            style = Stroke(width = 1.2f)
        )

        // LED Headlights (White/Cyan)
        val headlightColor = if (headlightActive) Color(0xFFFFFFFF) else Color(0x6600E5FF)
        drawCircle(
            color = headlightColor,
            radius = 6f,
            center = Offset(centerX - carWidth * 0.38f, centerY - carLength * 0.44f)
        )
        drawCircle(
            color = headlightColor,
            radius = 6f,
            center = Offset(centerX + carWidth * 0.38f, centerY - carLength * 0.44f)
        )

        // Rear LED Light Bar (Continuous Red Bar)
        drawLine(
            color = Color(0xFFFF1744),
            start = Offset(centerX - carWidth * 0.42f, centerY + carLength * 0.48f),
            end = Offset(centerX + carWidth * 0.42f, centerY + carLength * 0.48f),
            strokeWidth = 4f
        )

        // Driver Door Indicator (Open left)
        if (doorActive) {
            drawLine(
                color = SkyAmber,
                start = Offset(centerX - carWidth / 2f, centerY - carLength * 0.15f),
                end = Offset(centerX - carWidth / 2f - 24f, centerY - carLength * 0.05f),
                strokeWidth = 3f
            )
        }

        // Trunk Indicator (Open back)
        if (trunkActive) {
            drawLine(
                color = SkyGreen,
                start = Offset(centerX - carWidth * 0.25f, centerY + carLength / 2f + 14f),
                end = Offset(centerX + carWidth * 0.25f, centerY + carLength / 2f + 14f),
                strokeWidth = 3f
            )
        }

        // Skywell ET5 Chrome Emblem
        drawCircle(
            color = SkyCyan,
            radius = 4f,
            center = Offset(centerX, centerY - carLength * 0.47f)
        )
    }
}
