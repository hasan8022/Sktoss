package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.media.MediaSource
import com.example.media.NowPlayingMetadata
import com.example.ui.theme.LocalEt5Colors

@Composable
fun LeftDrivingPane(
    effectiveSpeed: Float,
    selectedGear: String,
    outsideTempC: Int?,
    insideTempC: Int?,
    batteryRangeKm: Int?,
    batterySocPercent: Int? = null,
    isObdConnected: Boolean,
    deviceBatteryPct: Int,
    isBluetoothConnected: Boolean,
    isWifiConnected: Boolean,
    radarDistanceCm: Int?,
    nowPlaying: NowPlayingMetadata,
    onGearSelect: (String) -> Unit,
    onTogglePlayMedia: () -> Unit,
    onPrevMedia: () -> Unit,
    onNextMedia: () -> Unit,
    onClickMediaCard: () -> Unit,
    onSelectMediaSource: ((MediaSource) -> Unit)? = null,
    use3DCarView: Boolean = true,
    onToggle3DCarView: (() -> Unit)? = null,
    carColorHex: Int = 15330028,
    doorsOpen: List<Boolean> = listOf(false, false, false, false),
    isHoodOpen: Boolean = false,
    isTrunkOpen: Boolean = false,
    isChargePortOpen: Boolean = false,
    isHeadlightOn: Boolean = false,
    isLeftSignalOn: Boolean = false,
    isRightSignalOn: Boolean = false,
    isHazardOn: Boolean = false,
    isBrakeOn: Boolean = false,
    isCharging: Boolean = false,
    chargeMinutesRemaining: Int? = null,
    onStopCharging: (() -> Unit)? = null,
    onToggleTrunk: (() -> Unit)? = null,
    activeProfileName: String = "Sürücü",
    tripDurationText: String = "00:00",
    odometerKm: Float? = null,
    avgConsumptionKwh: Float? = null,
    tirePressuresBar: List<Float>? = null,
    onOpenProfiles: (() -> Unit)? = null,
    onOpenSettings: (() -> Unit)? = null,
    onToggleTheme: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val colors = LocalEt5Colors.current
    val anyDoorOrLidOpen = doorsOpen.any { it } || isHoodOpen || isTrunkOpen || isHazardOn

    Box(
        modifier = modifier
            .fillMaxHeight()
            .background(colors.bg)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("left_driving_pane")
    ) {
        // Perspective Road Markings Canvas (when in 2D mode)
        if (!use3DCarView) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val leftLaneX = w * 0.28f
                val rightLaneX = w * 0.72f
                val lanePaint = colors.text3.copy(alpha = 0.35f)
                val strokeW = 3.dp.toPx()

                drawLine(
                    color = lanePaint,
                    start = Offset(leftLaneX, h * 0.18f),
                    end = Offset(leftLaneX, h * 0.72f),
                    strokeWidth = strokeW
                )
                drawLine(
                    color = lanePaint,
                    start = Offset(rightLaneX, h * 0.18f),
                    end = Offset(rightLaneX, h * 0.72f),
                    strokeWidth = strokeW
                )
            }
        }

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Top Cluster Telemetry Header Bar (Matching SkyOS 2.82 dark & light reference screenshots)
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    // Left Column: PRND strip + Warning + WiFi + BT + Battery on Row 1, Dış/İç Temp on Row 2
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            listOf("P", "R", "N", "D").forEach { gear ->
                                val isSelected = gear == selectedGear
                                Text(
                                    text = gear,
                                    color = if (isSelected) colors.text else colors.text3,
                                    fontSize = if (isSelected) 18.sp else 15.sp,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                    modifier = Modifier.clickable { onGearSelect(gear) }
                                )
                            }

                            Spacer(modifier = Modifier.width(2.dp))

                            // Warning icon (highlighted red if door/hood/trunk open or hazard active)
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Uyarı",
                                tint = if (anyDoorOrLidOpen) colors.red else colors.text3,
                                modifier = Modifier.size(15.dp)
                            )

                            // WiFi Status
                            Icon(
                                imageVector = Icons.Default.Wifi,
                                contentDescription = "WiFi",
                                tint = if (isWifiConnected) colors.blue else colors.text3,
                                modifier = Modifier.size(15.dp)
                            )

                            // Bluetooth Status
                            Icon(
                                imageVector = Icons.Default.Bluetooth,
                                contentDescription = "Bluetooth",
                                tint = if (isBluetoothConnected) colors.blue else colors.text3,
                                modifier = Modifier.size(15.dp)
                            )

                            // Battery & Range Indicator (Strict honesty: no fake 321 km)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                                    contentDescription = "Batarya",
                                    tint = if (isCharging || batterySocPercent != null) colors.green else colors.text2,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                val battText = when {
                                    batterySocPercent != null && batteryRangeKm != null ->
                                        "%$batterySocPercent · $batteryRangeKm km"
                                    batteryRangeKm != null -> "$batteryRangeKm km"
                                    batterySocPercent != null -> "%$batterySocPercent"
                                    else -> "-- km"
                                }
                                Text(
                                    text = battText,
                                    color = colors.text,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Row 2: Outside & Inside Temperature (Strict honesty: "--°" when sensor not connected)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val outStr = outsideTempC?.let { "$it°" } ?: "--°"
                            val inStr = insideTempC?.let { "$it°" } ?: "--°"
                            Text(
                                text = "Dış $outStr   İç $inStr",
                                color = colors.text2,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            if (outsideTempC != null && outsideTempC <= 3) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "❄ Buzlanma olabilir",
                                    color = colors.amber,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Right Column: Big Digital Speedometer (0 KM/SA)
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "%.0f".format(effectiveSpeed),
                            color = colors.text,
                            fontSize = 46.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (-1).sp
                        )
                        Text(
                            text = "KM/SA",
                            color = colors.text2,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Subtle Power / Regen Bar (LfH;->L in classes.dex)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(colors.surface3)
                ) {
                    val fraction = (effectiveSpeed / 160f).coerceIn(0.02f, 1f)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fraction)
                            .fillMaxHeight()
                            .background(colors.blue)
                    )
                }
            }

            // 2. Center Vehicle Visualizer Area (3D ET5 GLB Model OR 2D Top-Down Radar View)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                if (use3DCarView) {
                    Skywell3DCarView(
                        doors = doorsOpen,
                        isHoodOpen = isHoodOpen,
                        isTrunkOpen = isTrunkOpen,
                        isChargePortOpen = isChargePortOpen || isCharging,
                        isHeadlightOn = isHeadlightOn,
                        isLeftSignalOn = isLeftSignalOn,
                        isRightSignalOn = isRightSignalOn,
                        isHazardOn = isHazardOn,
                        isBrakeOn = isBrakeOn || selectedGear == "P",
                        radarDistanceCm = radarDistanceCm,
                        carColorHex = carColorHex,
                        activeView = if (selectedGear == "P") "parked" else "top",
                        onPartTap = { part ->
                            if (part == "trunk") onToggleTrunk?.invoke()
                        },
                        showControls = false,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    // 2D Top-Down Skywell ET5 Graphic with Radar Arcs (only when radarDistanceCm != null)
                    if (radarDistanceCm != null) {
                        Canvas(modifier = Modifier.size(120.dp, 190.dp)) {
                            val cx = size.width / 2f
                            val radarColor = when {
                                radarDistanceCm <= 35 -> colors.red
                                radarDistanceCm <= 75 -> colors.amber
                                else -> colors.green
                            }
                            drawArc(
                                color = radarColor,
                                startAngle = 200f,
                                sweepAngle = 140f,
                                useCenter = false,
                                topLeft = Offset(cx - 36.dp.toPx(), 4.dp.toPx()),
                                size = androidx.compose.ui.geometry.Size(72.dp.toPx(), 28.dp.toPx()),
                                style = Stroke(width = 3.dp.toPx())
                            )
                            drawArc(
                                color = radarColor.copy(alpha = 0.7f),
                                startAngle = 20f,
                                sweepAngle = 140f,
                                useCenter = false,
                                topLeft = Offset(cx - 36.dp.toPx(), size.height - 32.dp.toPx()),
                                size = androidx.compose.ui.geometry.Size(72.dp.toPx(), 28.dp.toPx()),
                                style = Stroke(width = 2.5.dp.toPx())
                            )
                        }
                    }

                    val carImageRes = when {
                        isHazardOn -> R.drawable.arac_ust_dortlu
                        isLeftSignalOn -> R.drawable.arac_ust_sol
                        isRightSignalOn -> R.drawable.arac_ust_sag
                        isBrakeOn || selectedGear == "R" -> R.drawable.arac_ust_stop
                        else -> R.drawable.arac_ust
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(
                            painter = painterResource(id = carImageRes),
                            contentDescription = "Skywell ET5 Üst Görünüm",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .width(82.dp)
                                .height(152.dp)
                        )
                    }
                }

                // Radar Distance Badge & "P Cep yer Park et" Card (shown ONLY when real radar data exists)
                if (radarDistanceCm != null) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val badgeColor = when {
                            radarDistanceCm <= 35 -> colors.red
                            radarDistanceCm <= 75 -> colors.amber
                            else -> colors.green
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(badgeColor)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "$radarDistanceCm cm",
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        // "P Cep yer Park et" blue card from runtime_120s.jpg
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(colors.blue)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "P  Cep yer · Park et",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // 3D / 2D Mode Toggle Pill (Top-Right of Visualizer)
                if (onToggle3DCarView != null) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(colors.surface2)
                            .border(1.dp, colors.stroke, RoundedCornerShape(10.dp))
                            .clickable { onToggle3DCarView() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ViewInAr,
                                contentDescription = "3D/2D Görünüm",
                                tint = colors.blue,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (use3DCarView) "3D Model" else "2D Üst",
                                color = colors.text,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // 3. Charging Status Banner (LfH;->d in classes.dex: "Şarj oluyor - %... - Şarjı bitir")
            if (isCharging) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(colors.green.copy(alpha = 0.15f))
                        .border(1.dp, colors.green.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val socPart = batterySocPercent?.let { "%$it" } ?: ""
                    val minPart = chargeMinutesRemaining?.let { " · $it dk kaldı" } ?: ""
                    Text(
                        text = "⚡ Şarj oluyor $socPart$minPart",
                        color = colors.green,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (onStopCharging != null) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(colors.surface2)
                                .clickable { onStopCharging() }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "Şarjı bitir",
                                color = colors.text,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // 4. Quick Action Pills Row (matching reference_dashboard_dark.jpg & reference_dashboard_light.jpg:
            // [Bagaj]  [H Halil]  [01:15]  [🌙/☀]  [⚙])
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // [Bagaj] Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isTrunkOpen) colors.amber.copy(alpha = 0.2f) else colors.surface2)
                        .border(1.dp, colors.stroke, RoundedCornerShape(12.dp))
                        .clickable { onToggleTrunk?.invoke() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (isTrunkOpen) "Bagaj Açık" else "Bagaj",
                        color = if (isTrunkOpen) colors.amber else colors.text,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // [H Sürücü] Profile Chip
                val displayProfile = activeProfileName.ifBlank { "Sürücü" }
                val initial = displayProfile.firstOrNull()?.uppercaseChar()?.toString() ?: "S"
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(colors.surface2)
                        .border(1.dp, colors.stroke, RoundedCornerShape(12.dp))
                        .clickable { onOpenProfiles?.invoke() }
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(colors.blue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initial,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = displayProfile,
                        color = colors.text,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }

                // [01:15] Session Timer Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(colors.surface2)
                        .border(1.dp, colors.stroke, RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = tripDurationText,
                        color = colors.text2,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Quick Dark/Light Theme Toggle Button
                if (onToggleTheme != null) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(colors.surface2)
                            .border(1.dp, colors.stroke, CircleShape)
                            .clickable { onToggleTheme() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (colors.isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Tema Değiştir",
                            tint = colors.text2,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }

                // Settings Gear Icon Button
                if (onOpenSettings != null) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(colors.surface2)
                            .border(1.dp, colors.stroke, CircleShape)
                            .clickable { onOpenSettings() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Ayarlar",
                            tint = colors.text2,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }

            // 5. Bottom Media / Trip / TPMS Card
            FloatingMediaCard(
                nowPlaying = nowPlaying,
                onTogglePlay = onTogglePlayMedia,
                onPrevious = onPrevMedia,
                onNext = onNextMedia,
                onClickCard = onClickMediaCard,
                onSelectSource = onSelectMediaSource,
                tripDurationText = tripDurationText,
                odometerKm = odometerKm,
                avgConsumptionKwh = avgConsumptionKwh,
                tirePressuresBar = tirePressuresBar,
                modifier = Modifier.padding(bottom = 2.dp)
            )
        }
    }
}
