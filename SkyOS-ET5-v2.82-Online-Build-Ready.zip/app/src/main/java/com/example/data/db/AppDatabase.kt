package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [DriverProfile::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun driverProfileDao(): DriverProfileDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "skyos_automotive.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed initial default profile
                        CoroutineScope(Dispatchers.IO).launch {
                            val dao = getInstance(context).driverProfileDao()
                            dao.insertProfile(
                                DriverProfile(
                                    name = "Ana Sürücü",
                                    avatarIndex = 0,
                                    cabinTempCelsius = 22.0f,
                                    seatPreset = 1,
                                    favoriteRadioName = "TRT FM",
                                    favoriteRadioUrl = "https://kral-radyo.medyainternet.com/kral/kralfm/playlist.m3u8",
                                    favoriteDestination = "Ev",
                                    isDefault = true
                                )
                            )
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
