package com.example.model

/**
 * Real-time vehicle telemetry data derived strictly from real hardware sources
 * (Android GPS LocationManager, OBD-II socket, or hardware sensors).
 */
data class VehicleTelemetry(
    val gpsSpeedKmh: Float = 0f,
    val gpsLatitude: Double = 0.0,
    val gpsLongitude: Double = 0.0,
    val gpsAltitude: Double = 0.0,
    val gpsBearing: Float = 0f,
    val gpsAccuracyMeters: Float = 0f,
    val isGpsActive: Boolean = false,

    // OBD-II Real Telemetry (only valid when obdStatus == CONNECTED)
    val obdStatus: OBDConnectionStatus = OBDConnectionStatus.DISCONNECTED,
    val obdStatusMessage: String = "OBD-II Adaptörü Bağlı Değil",
    val obdSpeedKmh: Int? = null,
    val engineRpm: Int? = null,
    val coolantTempCelsius: Int? = null,
    val controlModuleVoltage: Float? = null,
    val batterySocPercent: Int? = null,
    val supportedPidsMask: String? = null,
    val activeDtcCodes: List<DtcCode> = emptyList(),

    // Driving Safety State (based on real GPS speed)
    val isVehicleMoving: Boolean = false
)

enum class OBDConnectionStatus {
    DISCONNECTED,
    SCANNING,
    CONNECTING,
    CONNECTED,
    ERROR
}

data class DtcCode(
    val code: String,
    val description: String,
    val category: String,
    val severity: DtcSeverity
)

enum class DtcSeverity {
    INFO,
    WARNING,
    CRITICAL
}
