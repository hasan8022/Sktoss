package com.example.hardware

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import android.webkit.WebView
import com.example.model.BluetoothDeviceInfo
import com.example.model.HardwareDiagnosticInfo

class SystemDiagnosticsManager(private val context: Context) {

    fun scanHardwareEnvironment(): HardwareDiagnosticInfo {
        val pm = context.packageManager

        // 1. GMS Availability Test (Safe check without crash on non-GMS AOSP Skywell ET5 units)
        var isGmsInstalled = false
        var gmsStatus = "GMS Bulunamadı (Skywell AOSP Sistemi)"
        try {
            val gmsPackageInfo = pm.getPackageInfo("com.google.android.gms", 0)
            if (gmsPackageInfo != null) {
                isGmsInstalled = true
                gmsStatus = "Yüklü (v${gmsPackageInfo.versionName})"
            }
        } catch (_: PackageManager.NameNotFoundException) {
            isGmsInstalled = false
            gmsStatus = "Google Play Hizmetleri Mevcut Değil (AOSP Ortamı)"
        }

        // 2. Apps Check
        val isMapsInstalled = isPackageInstalled("com.google.android.apps.maps", pm)
        val isSpotifyInstalled = isPackageInstalled("com.spotify.music", pm)
        val isYouTubeInstalled = isPackageInstalled("com.google.android.youtube", pm)

        // 3. ADB Enabled Status
        val adbEnabled = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        } catch (_: Exception) {
            false
        }

        // 4. USB Host Devices
        val usbManager = context.getSystemService(Context.USB_SERVICE) as? UsbManager
        val usbList = mutableListOf<String>()
        usbManager?.deviceList?.values?.forEach { dev ->
            usbList.add("${dev.deviceName} [VID:0x${Integer.toHexString(dev.vendorId)} PID:0x${Integer.toHexString(dev.productId)}]")
        }

        // 5. Bluetooth Paired / Bonded Devices
        val btList = mutableListOf<BluetoothDeviceInfo>()
        var isBtEnabled = false
        try {
            val btAdapter = BluetoothAdapter.getDefaultAdapter()
            if (btAdapter != null && btAdapter.isEnabled) {
                isBtEnabled = true
                btAdapter.bondedDevices?.forEach { dev ->
                    val name = dev.name ?: "Bilinmeyen Cihaz"
                    val isObd = name.contains("OBD", ignoreCase = true) ||
                            name.contains("ELM", ignoreCase = true) ||
                            name.contains("V-LINK", ignoreCase = true) ||
                            name.contains("SCAN", ignoreCase = true)
                    btList.add(BluetoothDeviceInfo(name = name, address = dev.address, isLikelyObd = isObd))
                }
            }
        } catch (_: SecurityException) {
            // Missing Bluetooth permission on newer Android
        }

        // 6. WebView Version
        var webViewPackageName = "Android System WebView"
        var webViewVersionName = "Bilinmiyor"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val webViewPackage = WebView.getCurrentWebViewPackage()
            if (webViewPackage != null) {
                webViewPackageName = webViewPackage.packageName
                webViewVersionName = webViewPackage.versionName ?: "v?"
            }
        }

        // 7. Battery / Power Status
        var batteryPct = -1
        var isCharging = false
        var batteryTempCelsius: Float? = null
        try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, ifilter)
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) {
                batteryPct = ((level / scale.toFloat()) * 100).toInt()
            }
            val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

            val tempTenths = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            if (tempTenths > 0) {
                batteryTempCelsius = tempTenths / 10.0f
            }
        } catch (_: Exception) {}

        // 8. Network Connectivity
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        var netType = "Bağlantı Yok"
        var isNetConnected = false
        if (cm != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val network = cm.activeNetwork
                val capabilities = cm.getNetworkCapabilities(network)
                if (capabilities != null) {
                    when {
                        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                            netType = "Wi-Fi Aktif"
                            isNetConnected = true
                        }
                        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                            netType = "Hücresel Ağ (4G/LTE)"
                            isNetConnected = true
                        }
                        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> {
                            netType = "Ethernet / Araç İçi LAN"
                            isNetConnected = true
                        }
                        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> {
                            netType = "Bluetooth İnternet"
                            isNetConnected = true
                        }
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val activeNet = cm.activeNetworkInfo
                @Suppress("DEPRECATION")
                if (activeNet != null && activeNet.isConnected) {
                    isNetConnected = true
                    netType = activeNet.typeName
                }
            }
        }

        // 9. Android Automotive OS Car API Test
        var isCarApiPresent = false
        try {
            Class.forName("android.car.Car")
            isCarApiPresent = true
        } catch (_: ClassNotFoundException) {
            isCarApiPresent = false
        }

        return HardwareDiagnosticInfo(
            androidVersion = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            manufacturer = Build.MANUFACTURER,
            model = Build.MODEL,
            brand = Build.BRAND,
            board = Build.BOARD,
            hardware = Build.HARDWARE,
            displayBuildId = Build.DISPLAY,
            isAdbEnabled = adbEnabled,
            isGmsAvailable = isGmsInstalled,
            gmsStatusDetail = gmsStatus,
            isGoogleMapsAppInstalled = isMapsInstalled,
            isSpotifyAppInstalled = isSpotifyInstalled,
            isYouTubeAppInstalled = isYouTubeInstalled,
            webViewPackage = webViewPackageName,
            webViewVersion = webViewVersionName,
            usbDevices = usbList,
            bluetoothBondedDevices = btList,
            isBluetoothAvailable = btList.isNotEmpty() || isBtEnabled,
            networkType = netType,
            isInternetConnected = isNetConnected,
            internalBatteryLevel = batteryPct,
            batteryTemperatureCelsius = batteryTempCelsius,
            isDeviceCharging = isCharging,
            isCarApiAvailable = isCarApiPresent
        )
    }

    private fun isPackageInstalled(packageName: String, pm: PackageManager): Boolean {
        return try {
            pm.getPackageInfo(packageName, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }
}
