# Google AI / Gemini in Android Studio için ana görev promptu

Aşağıdaki metni Android Studio'da Gemini'ye tek parça olarak gönder. Önce bu ZIP içindeki projeyi aç ve dosyaları incele. Kullanıcı aracı: **2023 Skywell ET5**. Referans uygulama: `recovery_reference/SkyOS-2.82-original.apk` (SkyOS 2.82; kullanıcı bu APK'nin kendi aracında çalıştığını belirtiyor).

---

Sen kıdemli bir Android Automotive / Android uygulama tersine mühendislik ve Kotlin geliştiricisisin. Bu çalışma alanındaki `SkyOS ET5` projesini, `recovery_reference/SkyOS-2.82-original.apk` referansına dayanarak mümkün olan en yüksek doğrulukta yeniden oluştur. Hedef araç 2023 Skywell ET5'tir.

## 1. Önce incele, sonra değiştir

1. Projedeki tüm Kotlin dosyalarını, Gradle yapılandırmasını, manifesti, Compose ekranlarını, servisleri, Room veritabanını ve `app/src/main/assets/` içeriğini oku.
2. Referans APK'yi değiştirme. Orijinal APK byte-for-byte korunmalı; hash'i `83e97b2b9e6fcc1d826e9385d1fdc8520995156204e8268c860c701cc9fae6f4` olmalıdır.
3. APK içindeki `classes.dex`, `AndroidManifest.xml`, `resources.arsc`, `res/`, `assets/` ve `lib/` içeriklerini analiz et. `classes.dex` için JADX veya eşdeğer bir DEX decompiler kullan. Binary XML ve `resources.arsc` için apktool/aapt2 gibi uygun araçları kullan. Bu araçlar kurulu değilse önce ortamın izin verdiği şekilde kurulum/entegrasyon yolunu belirle; yalnızca string aramasıyla kaynak kodu çözdüğünü iddia etme.
4. Her orijinal sınıfı ve metodu mevcut Kotlin dosyalarıyla eşleştir. Eşleşme tablosu üret: orijinal sınıf/metot, mevcut dosya, taşınan davranış, eksik kalan nokta, kanıt seviyesi.
5. Kaynak APK'de bulunmayan özellikleri orijinalmiş gibi ekleme. Bilinmeyenleri açıkça `UNVERIFIED` olarak işaretle.

## 2. Öncelikli APK izleri

DEX'te görülen adları ve referansları araştır; bunların yalnızca isim/string kanıtı olabileceğini unutma:

- `tr.halil.et5` namespace'i
- `Et5App`, `MainActivity`, `Et5Ayar`, `Et5Arac`, `Et5Klima`, `Et5Kapi`, `Et5Isiklar`, `Et5Koltuk`, `Et5Obd`, `Et5Radyo`, `Et5Spotify`, `Et5Lisans`, `Et5Installer`, `Et5Map`, `Et5Profile`, `Et5Guncelleme`
- `BootReceiver`, `PanelGuardService`, `RadioService`, `Et5InCallService`, `PairingReceiver`, `HomeGate`
- OEM referansları: `com.skyworth.car.*`
- HVAC provider: `com.coolwell.ai.skyhvac`, `content://com.coolwell.ai.skyhvac.database/airconditioner`
- capability adları: `CONTROL_CAR_CLIMATE`, `CONTROL_CAR_DOORS`, `CONTROL_CAR_EXTERIOR_LIGHTS`, `CONTROL_CAR_MIRRORS`, `CONTROL_CAR_SEATS`, `CONTROL_CAR_WINDOWS`
- Spotify App Remote sınıfları, YouTube Music paket referansları, MapLibre, Radio Browser, OBD/vLinker MS
- lisans stringleri: `tr.halil.et5.license`, `License.State.Valid`, `/kontrol/lisans`, `et5_lisans`, `trial_vin`, `trial_used`

Önemli: Bunlar uygulamada gerçek entegrasyon veya yetki bulunduğunu tek başına kanıtlamaz. Çağrı zinciri, manifest izinleri, API imzaları, paket görünürlüğü, servis/provider erişimi ve hata davranışı koddan doğrulanmalı.

## 3. Projeyi gerçek anlamda tamamla

- Kurulum sihirbazı: 2023 Skywell ET5 varsayılanı; kullanıcı girişi gerektiren plaka, sürücü, adres, VIN, lisans gibi alanlar boş başlasın. Sahte varsayılan veri kullanma.
- Ana ekran, araç, klima, kapı, ışık, koltuk, harita, medya, radyo, Spotify, OBD, profil, lisans, güncelleme ve ayarlar ekranlarını orijinal APK akışlarıyla eşleştir.
- Orijinal 3D ET5 modellerini ve web asset'lerini mevcut uygulamada uygun şekilde kullan; lisans ve dosya bütünlüğünü koru.
- `arac.bin` ve `arac.ver` formatını analiz et. `ET5H` başlığını tanımak lisans/VIN/araç doğrulaması değildir. Şema çözülmediyse bunu açıkça raporla.
- Medya sağlayıcılarında sahte şarkı, video, radyo istasyonu veya hesap durumu gösterme. OAuth/SDK gereksinimlerini tamamlamadan hesabı bağlı gösterme.
- Harita sağlayıcısının API key/GMS/tile şartlarını açıkça belirt; gizli anahtarları kaynak koda yazma.
- Gerçek araç kontrollerinde yalnızca doğrulanmış OEM AIDL/HAL/provider API ve izinleri kullan. `CONTROL_CAR_*` adlarından hareketle tahmini komut üretme. Rastgele CAN/UDS ID, PID, baud rate, pinout, batarya hücre dizilimi veya payload uydurma.
- Önce salt-okunur teşhis. Yazma/aktüatör komutları ancak üretici dokümanı, doğru firmware eşleşmesi, gerekli imza/izinler ve güvenli test koşulları doğrulandıktan sonra.
- Video oynatımını sürüş sırasında kilitle. Sürüş güvenliğini bozacak otomasyon ekleme.

## 4. Derleme ve test zorunlulukları

1. Gradle Sync yap; Gradle Wrapper, Android Gradle Plugin, Kotlin, JDK ve compile SDK sürümlerini uyumlu hâle getir. Gerekirse Gradle wrapper dosyalarını Android Studio/Gradle ile üret. Sadece `gradle-wrapper.properties` bulunması wrapper'ın çalıştığı anlamına gelmez; `gradlew` ve `gradle-wrapper.jar` gerekir.
2. Eksik `google-services.json`, `.env`, API key veya imza dosyaları için sahte dosya üretme. Opsiyonel entegrasyonları ana uygulama derlemesini bozmayacak şekilde yapılandır ve gerekenleri dokümante et.
3. `assembleDebug`, unit testler ve lint çalıştır. Gerçek komut çıktısını rapora koy. Başarısız testleri saklama.
4. En azından emülatörde açılış, kurulum, ekran gezinmesi, izin reddi, ağ yokluğu ve boş veri durumlarını test et.
5. Gerçek araç kontrolü iddiası için 2023 ET5 ve hedef head-unit firmware üzerinde doğrulama gerekir. Emülatör testi araç kontrolünü doğrulamaz.
6. Derlenmiş APK oluşturulursa tam yolunu, boyutunu, SHA-256'sini, build variant'ını ve test sonuçlarını raporla. Derleme başarısızsa APK üretildiğini söyleme.

## 5. Teslim edilecek çıktılar

- Düzenlenmiş Android Studio projesi (kaynak kod ve Gradle dosyaları).
- `app/build/outputs/apk/debug/app-debug.apk` (yalnızca gerçekten üretilebilirse).
- `REVERSE_ENGINEERING_MAP.md`: orijinal DEX sınıf/metot eşleştirme tablosu.
- `FEATURE_MATRIX.md`: her özellik `WORKING`, `IMPLEMENTED_UNTESTED`, `OEM_PERMISSION_REQUIRED`, `API_KEY_REQUIRED`, `UNVERIFIED` veya `NOT_IMPLEMENTED` olarak sınıflandırılsın.
- `BUILD_AND_TEST_REPORT.md`: komutlar, ortam sürümleri, test çıktıları, bilinen hatalar.
- `REMAINING_WORK.md`: çözülemeyen dosyalar, API'ler ve araçta doğrulanması gerekenler.

Öncelik sırası: (1) projeyi hatasız derlenebilir yap, (2) APK'den gerçek ekran/akışları çıkarıp eşleştir, (3) gerçek ve güvenli entegrasyonları uygula, (4) eksikleri şeffaf biçimde raporla. Büyük değişikliklerden önce mevcut kaynakları yedekle ve her adımı küçük, derlenebilir değişikliklerle yap. Yalnızca plan veya örnek kod verme; doğrudan bu proje dosyalarını düzenle ve test et.

---

## Kullanıcıdan beklenen işlem

Gemini önce tüm projeyi analiz etsin. İlk cevabında yalnızca dosya listesi vermesin; `classes.dex` ve kaynak eşleştirme planını çıkarsın. Sonra dosyaları gerçekten değiştirsin, Gradle Sync/build/test çalıştırsın ve somut çıktı oluştursun. API anahtarları, VIN, plaka, lisans veya özel imza bilgilerini sohbete yapıştırma; gerekiyorsa yerel güvenli yapılandırma kullan.

## ZORUNLU: Kullanıcının sağladığı gerçek araç fotoğraf ve videolarını incele

Projede `video_reference/` klasöründe kullanıcı tarafından sağlanan iki fotoğraf ve iki videodan çıkarılmış örnek kareler ile `VIDEO_AND_SCREEN_REFERENCE_ANALYSIS_TR.md` analizi bulunur. Önce bu belgeyi ve tüm kareleri açıp incele. Bu materyaller tasarım ve görünen akış için birincil referanstır.

Beklenen ana ekran:
- Landscape otomotiv düzeni, sol sürüş/araç paneli + sağ harita paneli.
- Sol panelde PRND, dış/iç sıcaklık, bağlantı/uyarı ikonları, batarya/menzil, hız, ET5 üstten araç görseli ve altta medya kartı.
- Sağ panelde “Nereye?” araması, mikrofon ve harita.
- Alt sabit dock'ta sıcaklık/fan/koltuk iklim kontrolleri, uygulama ızgarası, sesli asistan, buğu çözücü, telefon, müzik, kamera/video benzeri kısayol ve ses seviyesi.
- Hem açık hem koyu tema.
- Ayarlar/kurulum videosunda kategori listeli koyu ayar ekranları, metin giriş dialogu ve lisans sayfası görünüyor. Bunları ekran akışı olarak yeniden kur; lisans mantığını tahmin etme.
- Uzun araç videosunda harita/araç paneli, park durum uyarıları, park/engel algılama görselleştirmesine benzeyen ekran, sesli asistan etkileşimi ve ana ekrana dönüş görülüyor.

Örnek videolarda görülen hız, sıcaklık, menzil, şarkı adı veya VIN/lisans alanlarını sabit veri olarak kodlama. Bunlar sadece referans görüntüleridir. Gerçek veri kaynağı bulunmazsa açıkça “veri yok/bağlı değil” göster.

ÖNCE tüm ekranları ve mevcut Kotlin kaynaklarını envanterle; sonra ekran ekran gerçek dosyaları düzenle. Sadece tasarım önerisi yazma. Sonunda değiştirilen dosyaları, tamamlanan ekranları, çalışan/çalışmayan fonksiyonları ve gerçek Gradle build çıktısını raporla. DEX içindeki davranış kanıtı ile videodan görülen UI kanıtını birbirinden ayır. Bilinmeyen OEM/CAN/lisans ayrıntılarını uydurma.
