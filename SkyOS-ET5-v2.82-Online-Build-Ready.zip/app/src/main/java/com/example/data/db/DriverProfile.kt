package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "driver_profiles")
data class DriverProfile(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val avatarIndex: Int = 0,
    val cabinTempCelsius: Float = 22.0f,
    val seatPreset: Int = 1,
    val favoriteRadioName: String = "TRT FM",
    val favoriteRadioUrl: String = "https://kral-radyo.medyainternet.com/kral/kralfm/playlist.m3u8",
    val favoriteDestination: String = "Ev",
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
