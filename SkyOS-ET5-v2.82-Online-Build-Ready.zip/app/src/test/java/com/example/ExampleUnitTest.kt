package com.example

import com.example.data.LicenseManager
import com.example.data.obd.SkywellCANProtocolSpec
import com.example.media.MediaSource
import com.example.ui.theme.DarkEt5Colors
import com.example.ui.theme.LightEt5Colors
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testSkywellEt5Specs() {
        assertEquals("Skywell ET5 (EV)", SkywellCANProtocolSpec.VEHICLE_NAME)
        assertEquals("103S (103 Seri Hücre)", SkywellCANProtocolSpec.PACK_SERIES_CONFIG)
        assertEquals(72.0f, SkywellCANProtocolSpec.PACK_CAPACITY_KWH, 0.01f)
        assertEquals(381.1f, SkywellCANProtocolSpec.NOMINAL_PACK_VOLTAGE, 0.1f)
        assertEquals(432.6f, SkywellCANProtocolSpec.MAX_PACK_VOLTAGE, 0.1f)
        assertEquals(150.0f, SkywellCANProtocolSpec.MOTOR_POWER_KW, 0.01f)
        assertEquals(320.0f, SkywellCANProtocolSpec.MOTOR_TORQUE_NM, 0.01f)
    }

    @Test
    fun testRecoveredCarPropertyIds() {
        val props = SkywellCANProtocolSpec.RECOVERED_CAR_PROPERTY_IDS
        assertTrue(props.isNotEmpty())
        assertTrue(props.any { it.propertyIdHex == "0x11400400" }) // GEAR_SELECTION
        assertTrue(props.any { it.propertyIdHex == "0x11600207" }) // PERF_VEHICLE_SPEED
        assertTrue(props.any { it.propertyIdHex == "0x11600333" }) // EV_BATTERY_LEVEL
        assertTrue(props.any { it.propertyIdHex == "0x1160049e" }) // EV_RANGE_REMAINING
        assertTrue(props.any { it.propertyIdHex == "0x15600503" }) // HVAC_TEMPERATURE_SET
    }

    @Test
    fun testDarkAndLightThemePalettes() {
        assertNotEquals(DarkEt5Colors.bg, LightEt5Colors.bg)
        assertNotEquals(DarkEt5Colors.surface, LightEt5Colors.surface)
        assertNotEquals(DarkEt5Colors.text, LightEt5Colors.text)
        assertEquals(DarkEt5Colors.blue, LightEt5Colors.blue)
        assertEquals(DarkEt5Colors.green, LightEt5Colors.green)
    }

    @Test
    fun testLicenseKeyFormatValidation() {
        assertTrue(LicenseManager.isValidFormat("ET5-1234-ABCD-5678-EF90"))
        assertFalse(LicenseManager.isValidFormat("INVALID-KEY"))
        assertFalse(LicenseManager.isValidFormat("ET5-123-ABCD"))
    }

    @Test
    fun testMediaSourcesMatchSkyOs282Enum() {
        val sources = MediaSource.values().toList()
        assertTrue(sources.contains(MediaSource.RADIO))
        assertTrue(sources.contains(MediaSource.FM_RADIO))
        assertTrue(sources.contains(MediaSource.BLUETOOTH))
        assertTrue(sources.contains(MediaSource.USB))
        assertTrue(sources.contains(MediaSource.SPOTIFY))
        assertTrue(sources.contains(MediaSource.YOUTUBE_MUSIC))
        assertTrue(sources.contains(MediaSource.APPLE_MUSIC))
        assertTrue(sources.contains(MediaSource.DEEZER))
        assertTrue(sources.contains(MediaSource.SOUNDCLOUD))
        assertTrue(sources.contains(MediaSource.METROLIST))
    }

    @Test
    fun testObdSpeedFormula() {
        // SAE J1979: Speed PID 010D returns 1 byte (0x32 = 50 km/h)
        val hexByte = "32"
        val speedKmh = hexByte.toInt(16)
        assertEquals(50, speedKmh)
    }

    @Test
    fun testObdRpmFormula() {
        // SAE J1979: RPM PID 010C returns 2 bytes ((A * 256) + B) / 4
        // 0x1F40 = 8000 -> 8000 / 4 = 2000 RPM
        val a = "1F".toInt(16)
        val b = "40".toInt(16)
        val rpm = ((a * 256) + b) / 4
        assertEquals(2000, rpm)
    }

    @Test
    fun testObdCoolantTempFormula() {
        // SAE J1979: Coolant/BMS Temp PID 0105 returns 1 byte: A - 40
        // 0x5A = 90 -> 90 - 40 = 50 °C
        val a = "5A".toInt(16)
        val tempCelsius = a - 40
        assertEquals(50, tempCelsius)
    }

    @Test
    fun testObdVoltageFormula() {
        // SAE J1979: Module Voltage PID 0142 returns 2 bytes: ((A * 256) + B) / 1000
        // 0x367C = 13948 -> 13.948 V
        val a = "36".toInt(16)
        val b = "7C".toInt(16)
        val volts = ((a * 256) + b) / 1000.0f
        assertEquals(13.948f, volts, 0.001f)
    }

    @Test
    fun testDtcCodePrefixCalculation() {
        // First 2 bits: 00 = P, 01 = C, 10 = B, 11 = U
        val b1 = 0x01
        val prefix = when ((b1 and 0xC0) shr 6) {
            0 -> "P"
            1 -> "C"
            2 -> "B"
            3 -> "U"
            else -> "P"
        }
        assertEquals("P", prefix)
    }
}
