package com.example.service.vehicle

import android.content.Context
import android.util.Base64
import android.util.Log
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Exact binary container metadata for assets/arac.bin and assets/arac.ver
 * recovered by disassembling LEE;->m (Et5HelperStarter) in classes.dex.
 *
 * Container layout of assets/arac.bin (30,928 bytes):
 * - Bytes 0..3   (4 bytes) : Magic ASCII "ET5H"
 * - Bytes 4..15  (12 bytes): AES-GCM Initialization Vector (GCMParameterSpec(128, bytes, 4, 12))
 * - Bytes 16..N  (30,912 B): AES/GCM/NoPadding ciphertext + 128-bit authentication tag
 * - Additional Authenticated Data (AAD): "et5-yardimci".toByteArray(UTF_8)
 * - Decryption Key: Base64-decoded "hk" secret returned by the SkyOS license server (LJP;->g)
 * - Decrypted Payload: /data/local/tmp/y<nanoTime>.dex containing class `AracYardimci`,
 *   launched via `setsid su 1000 app_process -cp <dex> /system/bin AracYardimci serve 8724 <token>`.
 */
data class VehicleBinaryProfile(
    val versionString: String,
    val magicHeader: String,
    val binarySizeBytes: Int,
    val containerSignatureRecognized: Boolean,
    val gcmIvHex: String,
    val aadString: String,
    val sha256: String,
    val helperPort: Int = 8724,
    val helperMainClass: String = "AracYardimci",
    val hardwareModel: String = "2023 Skywell ET5 (Coocaa OS / Skyworth IVI)"
)

object VehicleBinaryManager {
    private const val TAG = "VehicleBinaryManager"
    private const val VER_FILE = "arac.ver"
    private const val BIN_FILE = "arac.bin"
    private const val EXPECTED_MAGIC = "ET5H"
    private const val GCM_AAD = "et5-yardimci"

    @Volatile
    private var cachedProfile: VehicleBinaryProfile? = null

    fun loadVehicleProfile(context: Context): VehicleBinaryProfile {
        cachedProfile?.let { return it }

        val profile = try {
            val version = context.assets.open(VER_FILE)
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText().trim() }
            val bytes = context.assets.open(BIN_FILE).use { it.readBytes() }
            val magic = if (bytes.size >= 4) {
                String(bytes, 0, 4, Charsets.US_ASCII)
            } else {
                "UNKNOWN"
            }
            val ivHex = if (bytes.size >= 16) {
                bytes.sliceArray(4 until 16).joinToString("") { "%02x".format(it) }
            } else {
                ""
            }
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(bytes)
                .joinToString("") { "%02x".format(it) }

            VehicleBinaryProfile(
                versionString = version,
                magicHeader = magic,
                binarySizeBytes = bytes.size,
                containerSignatureRecognized = magic == EXPECTED_MAGIC,
                gcmIvHex = ivHex,
                aadString = GCM_AAD,
                sha256 = digest
            ).also {
                Log.i(
                    TAG,
                    "arac.bin okundu: ver=$version magic=$magic size=${bytes.size} iv=$ivHex sha256=$digest"
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "arac.bin okunamadı: ${e.message}", e)
            VehicleBinaryProfile(
                versionString = "Okunamadı",
                magicHeader = "UNKNOWN",
                binarySizeBytes = 0,
                containerSignatureRecognized = false,
                gcmIvHex = "",
                aadString = GCM_AAD,
                sha256 = ""
            )
        }
        cachedProfile = profile
        return profile
    }

    /**
     * Exact AES/GCM/NoPadding decryption routine from LEE;->m (Et5HelperStarter).
     * Requires the server-issued Base64 key ("hk"). Returns null if the key is missing or invalid.
     */
    fun decryptHelperDexIfKeyAvailable(context: Context, base64HkKey: String?): ByteArray? {
        if (base64HkKey.isNullOrBlank()) return null
        return try {
            val bytes = context.assets.open(BIN_FILE).use { it.readBytes() }
            if (bytes.size <= 16) return null
            val magic = String(bytes, 0, 4, StandardCharsets.US_ASCII)
            if (magic != EXPECTED_MAGIC) return null

            val keyBytes = Base64.decode(base64HkKey, Base64.DEFAULT)
            val secretKey = SecretKeySpec(keyBytes, "AES")
            val gcmSpec = GCMParameterSpec(128, bytes, 4, 12)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)
            cipher.updateAAD(GCM_AAD.toByteArray(StandardCharsets.UTF_8))
            cipher.doFinal(bytes, 16, bytes.size - 16)
        } catch (e: Exception) {
            Log.w(TAG, "yardımcı açılamadı (lisans anahtarı eksik veya geçersiz): ${e.message}")
            null
        }
    }
}
