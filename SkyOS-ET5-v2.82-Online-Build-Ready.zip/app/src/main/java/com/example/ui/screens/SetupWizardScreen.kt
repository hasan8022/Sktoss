package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LicenseStatus
import com.example.data.SetupConfiguration
import com.example.media.RadioMediaPlayer
import com.example.service.vehicle.VehicleBinaryManager
import com.example.ui.SkyOsViewModel
import com.example.ui.theme.LocalEt5Colors
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyElectricBlue
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyNavy
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary
import com.example.util.SkywellI18nManager
import kotlinx.coroutines.launch

/**
 * SkyOS 2.82 Setup Wizard (LIC0; in classes.dex: Dil, Hoş geldiniz, Geliştirici modu [MzMyMQ],
 * Uyumluluk, Lisans [7 günlük ücretsiz dene + ET5-XXXX-XXXX-XXXX-XXXX], Kurulum, Profil, Telefon/OBD, Hazır).
 */
@Composable
fun SetupWizardScreen(
    viewModel: SkyOsViewModel,
    onCompleteSetup: (SetupConfiguration) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalEt5Colors.current
    val scope = rememberCoroutineScope()
    var currentStep by remember { mutableIntStateOf(1) }
    val totalSteps = 6

    val stepTitles = listOf(
        "1. Dil & Araç",
        "2. Geliştirici Modu",
        "3. Uyumluluk & İzinler",
        "4. Lisans Doğrulama",
        "5. OBD & Medya",
        "6. Profil & Hazır"
    )

    // Form States (2023 Skywell ET5 defaults, no fabricated personal data)
    var selectedLangCode by remember { mutableStateOf("tr") }
    var selectedVehicleModel by remember { mutableStateOf("Skywell ET5 2023") }
    var licensePlate by remember { mutableStateOf("") }
    var licenseCodeInput by remember { mutableStateOf("") }
    var selectedObdMac by remember { mutableStateOf("") }
    var driverName by remember { mutableStateOf("") }
    var homeAddress by remember { mutableStateOf("") }
    var workAddress by remember { mutableStateOf("") }
    var cabinTemp by remember { mutableFloatStateOf(22.0f) }
    var selectedRadio by remember { mutableStateOf("Kral Türk FM") }

    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val carColorHex by viewModel.carColorHex.collectAsState()
    val hardwareInfo by viewModel.hardwareInfo.collectAsState()
    val gpsTelemetry by viewModel.gpsTelemetry.collectAsState()
    val licenseState by viewModel.licenseState.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.gpsProvider.startListening()
        viewModel.refreshHardwareAudit()
    }

    fun buildConfig(): SetupConfiguration {
        return SetupConfiguration(
            isCompleted = true,
            vehicleModel = selectedVehicleModel,
            licensePlate = licensePlate,
            licenseCode = licenseCodeInput,
            driverName = driverName,
            homeAddress = homeAddress,
            workAddress = workAddress,
            cabinTempCelsius = cabinTemp,
            preferredRadioName = selectedRadio,
            obdMacAddress = selectedObdMac,
            languageCode = selectedLangCode,
            isDarkTheme = isDarkTheme,
            carColorHex = carColorHex
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.bg)
            .testTag("setup_wizard_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(colors.blue.copy(alpha = 0.2f))
                            .border(1.dp, colors.blue.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ElectricCar,
                            contentDescription = null,
                            tint = colors.blue,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "SkyOS 2.82 Kurulum Sihirbazı",
                            color = colors.text,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = stepTitles.getOrElse(currentStep - 1) { "" },
                            color = colors.text2,
                            fontSize = 12.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Quick Theme Toggle in Wizard Header
                    Box(
                        modifier = Modifier
                            .padding(end = 10.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(colors.surface2)
                            .border(1.dp, colors.stroke, RoundedCornerShape(10.dp))
                            .clickable { viewModel.toggleDarkTheme() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = null,
                                tint = colors.blue,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (isDarkTheme) "Koyu Tema" else "Açık Tema",
                                color = colors.text,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Button(
                        onClick = { onCompleteSetup(buildConfig()) },
                        colors = ButtonDefaults.buttonColors(containerColor = colors.surface2),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.padding(end = 10.dp)
                    ) {
                        Text("Doğrudan Kokpite Başla ➔", color = colors.blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    // Step Pills
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (step in 1..totalSteps) {
                            val isDone = step < currentStep
                            val isCurrent = step == currentStep
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isCurrent -> colors.blue
                                            isDone -> colors.green
                                            else -> colors.surface2
                                        }
                                    )
                                    .clickable { currentStep = step },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isDone) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                } else {
                                    Text(
                                        text = "$step",
                                        color = if (isCurrent) Color.White else colors.text2,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Step Content Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, colors.stroke, RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface)
            ) {
                AnimatedContent(
                    targetState = currentStep,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                                slideOutHorizontally { width -> -width } + fadeOut()
                            )
                        } else {
                            (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(
                                slideOutHorizontally { width -> width } + fadeOut()
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                    label = "SetupWizardStepTransition"
                ) { step ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        when (step) {
                            1 -> Step1LanguageAndVehicle(
                                selectedLangCode = selectedLangCode,
                                onSelectLang = { lang ->
                                    selectedLangCode = lang
                                    SkywellI18nManager.setLanguage(viewModel.getApplication(), lang)
                                },
                                selectedModel = selectedVehicleModel,
                                onSelectModel = { selectedVehicleModel = it },
                                licensePlate = licensePlate,
                                onPlateChange = { licensePlate = it }
                            )
                            2 -> Step2DeveloperBridge(
                                isAdbEnabled = hardwareInfo.isAdbEnabled,
                                onRefreshAudit = { viewModel.refreshHardwareAudit() }
                            )
                            3 -> Step3PermissionsAndCompatibility(
                                gpsGranted = gpsTelemetry.hasPermission,
                                bluetoothAvailable = hardwareInfo.isBluetoothAvailable,
                                isCarApiAvailable = hardwareInfo.isCarApiAvailable,
                                onRequestPermissions = {
                                    val permissions = mutableListOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION,
                                        Manifest.permission.RECORD_AUDIO
                                    )
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                        permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
                                        permissions.add(Manifest.permission.BLUETOOTH_SCAN)
                                    }
                                    permissionLauncher.launch(permissions.toTypedArray())
                                }
                            )
                            4 -> Step4LicenseActivation(
                                licenseCodeInput = licenseCodeInput,
                                onLicenseCodeChange = {
                                    licenseCodeInput = viewModel.licenseManager.formatLicenseInput(it)
                                },
                                licenseState = licenseState,
                                onActivateClick = {
                                    scope.launch {
                                        viewModel.licenseManager.activateOrCheckLicense(licenseCodeInput, requestTrial = false)
                                    }
                                },
                                onStartTrialClick = {
                                    scope.launch {
                                        viewModel.licenseManager.activateOrCheckLicense("TRIAL", requestTrial = true)
                                    }
                                }
                            )
                            5 -> Step5ObdAndMediaSetup(
                                bondedDevices = hardwareInfo.bluetoothBondedDevices,
                                selectedMac = selectedObdMac,
                                onSelectMac = { selectedObdMac = it },
                                hardwareInfo = hardwareInfo
                            )
                            6 -> Step6DriverProfileAndFinish(
                                driverName = driverName,
                                onDriverNameChange = { driverName = it },
                                homeAddress = homeAddress,
                                onHomeAddressChange = { homeAddress = it },
                                workAddress = workAddress,
                                onWorkAddressChange = { workAddress = it },
                                cabinTemp = cabinTemp,
                                onCabinTempChange = { cabinTemp = it },
                                selectedRadio = selectedRadio,
                                onSelectRadio = { selectedRadio = it },
                                selectedCarColor = carColorHex,
                                onSelectCarColor = { viewModel.setCarColor(it) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Navigation Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentStep > 1) {
                    OutlinedButton(
                        onClick = { currentStep-- },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.text),
                        modifier = Modifier.testTag("wizard_prev_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Geri", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Spacer(modifier = Modifier.width(10.dp))
                }

                if (currentStep < totalSteps) {
                    Button(
                        onClick = { currentStep++ },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.blue),
                        modifier = Modifier.testTag("wizard_next_button")
                    ) {
                        Text("Devam", color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                } else {
                    Button(
                        onClick = { onCompleteSetup(buildConfig()) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.green),
                        modifier = Modifier.testTag("wizard_finish_button")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Kurulumu Tamamla ve Kokpite Başla",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Step1LanguageAndVehicle(
    selectedLangCode: String,
    onSelectLang: (String) -> Unit,
    selectedModel: String,
    onSelectModel: (String) -> Unit,
    licensePlate: String,
    onPlateChange: (String) -> Unit
) {
    val colors = LocalEt5Colors.current
    val context = LocalContext.current
    val binaryProfile = remember { VehicleBinaryManager.loadVehicleProfile(context) }

    val models = listOf(
        "Skywell ET5 Legend (520 km WLTP)" to "72 kWh Li-Ion Batarya, 150 kW Güç, 320 Nm Tork",
        "Skywell ET5 Premium (520 km WLTP)" to "Panoramik Cam Tavan, Deri Koltuk, Isıtma & Soğutma",
        "Skywell ET5 Exclusive / Long Range (642 km WLTP)" to "86 kWh Batarya, L2.5 Otonom Sürüş, 360° Çevre Görüş"
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "Adım 1: Dil Seçimi ve 2023 Skywell ET5 Donanım Paketi",
            color = colors.blue,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        // Language Selection (assets/i18n/*.json)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "tr" to "Türkçe",
                "en" to "English",
                "de" to "Deutsch",
                "es" to "Español",
                "ru" to "Русский"
            ).forEach { (code, label) ->
                val isSelected = selectedLangCode == code
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) colors.blue else colors.surface2)
                        .clickable { onSelectLang(code) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) Color.White else colors.text,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            models.forEach { (title, subtitle) ->
                val isSelected = selectedModel == title || (selectedModel == "Skywell ET5 2023" && title.contains("Legend"))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectModel(title) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) colors.blue.copy(alpha = 0.14f) else colors.surface2
                    ),
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, colors.blue) else null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsCar,
                            contentDescription = null,
                            tint = if (isSelected) colors.blue else colors.text2,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = title, color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(text = subtitle, color = colors.text2, fontSize = 11.sp)
                        }
                        if (isSelected) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = colors.blue, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        OutlinedTextField(
            value = licensePlate,
            onValueChange = onPlateChange,
            label = { Text("Araç Plakası (İsteğe Bağlı)", color = colors.text2) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.blue,
                unfocusedBorderColor = colors.stroke,
                focusedTextColor = colors.text,
                unfocusedTextColor = colors.text
            )
        )

        // Bundled arac.bin & arac.ver inspection card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = colors.surface2),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = colors.blue, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Orijinal APK Araç Varlıkları (${binaryProfile.versionString})",
                            color = colors.text,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = if (binaryProfile.containerSignatureRecognized) "ET5H AES-GCM (${binaryProfile.binarySizeBytes} B)" else "Bulunamadı",
                        color = colors.green,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "arac.bin (IV: ${binaryProfile.gcmIvHex}, AAD: '${binaryProfile.aadString}') doğrulandı. Çevrimdışı ortamda sunucu 'hk' anahtarı olmadan şifre çözülmez.",
                    color = colors.text2,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun Step2DeveloperBridge(
    isAdbEnabled: Boolean,
    onRefreshAudit: () -> Unit
) {
    val colors = LocalEt5Colors.current
    val context = LocalContext.current

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "Adım 2: Geliştirici Modu ve AracYardimci Köprüsü (setup_00s.jpg)",
            color = colors.blue,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Skywell ET5 multimedya ekranında klima, koltuk, kapı ve VCU verilerini okumak/kontrol etmek için geliştirici seçeneklerinden USB hata ayıklamayı etkinleştirin:",
            color = colors.text2,
            fontSize = 13.sp
        )

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = colors.surface2),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("1. Aşağıdaki 'Ayarlar'ı Aç' düğmesine dokunun.", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text("2. Sistem → Geliştirici seçenekleri bölümüne girin.", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("3. Parola sorulursa Coocaa OS mühendislik parolasını girin: ", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(colors.blue.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("MzMyMQ", color = colors.blue, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                }
                Text("4. 'USB hata ayıklama' seçeneğini açın ve bu ekrana geri dönün.", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = {
                    val devIntent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(devIntent)
                    } catch (_: Exception) {
                        try {
                            context.startActivity(Intent(Settings.ACTION_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
                        } catch (_: Exception) {}
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.blue),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.DeveloperMode, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Ayarlar'ı Aç", color = Color.White, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onRefreshAudit,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isAdbEnabled) "ADB Durumu: AÇIK ✓" else "ADB Durumu: KAPALI (Yeniden Kontrol Et)",
                    color = if (isAdbEnabled) colors.green else colors.amber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun Step3PermissionsAndCompatibility(
    gpsGranted: Boolean,
    bluetoothAvailable: Boolean,
    isCarApiAvailable: Boolean,
    onRequestPermissions: () -> Unit
) {
    val colors = LocalEt5Colors.current
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "Adım 3: Uyumluluk Denetimi ve Sistem İzinleri",
            color = colors.blue,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "SkyOS ET5 uydurma veri kullanmaz. Aracın gerçek hızını, canlı konumunu ve Bluetooth OBD-II adaptörünü kullanabilmek için sistem izinlerini onaylayın.",
            color = colors.text2,
            fontSize = 13.sp
        )

        PermissionCard(
            title = "📍 Hassas Konum (GPS)",
            desc = "LocationManager üzerinden gerçek hız göstergesi ve harita navigasyonu için kullanılır.",
            isGranted = gpsGranted
        )

        PermissionCard(
            title = "📶 Bluetooth & OBD-II (vLinker MS / ELM327)",
            desc = "OBD-II adaptörü ile RFCOMM soket bağlantısı ve eller serbest telefon için gereklidir.",
            isGranted = bluetoothAvailable
        )

        PermissionCard(
            title = "🚗 Android Car API (android.car.CarPropertyManager)",
            desc = if (isCarApiAvailable) "Cihazda Android Automotive Car API algılandı." else "Standart AOSP ortamı (Araç üzerinde CarService / AracYardimci:8724 ile bağlanır).",
            isGranted = isCarApiAvailable
        )

        Button(
            onClick = onRequestPermissions,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = colors.blue),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("request_permissions_btn")
        ) {
            Icon(Icons.Default.Security, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Sistem İzinlerini İste ve Güncelle", color = Color.White, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Step4LicenseActivation(
    licenseCodeInput: String,
    onLicenseCodeChange: (String) -> Unit,
    licenseState: com.example.data.LicenseState,
    onActivateClick: () -> Unit,
    onStartTrialClick: () -> Unit
) {
    val colors = LocalEt5Colors.current
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "Adım 4: Lisans ve Aktivasyon (setup_10s.jpg & setup_20s.jpg)",
            color = colors.blue,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Lisans kodunuzu girerek etkinleştirebilir, 7 günlük deneme talep edebilir veya çevrimdışı yerel kokpit modunda devam edebilirsiniz.",
            color = colors.text2,
            fontSize = 13.sp
        )

        // 7-day trial card matching setup_10s.jpg
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = colors.surface2),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Aracınızda tüm özellikleri 7 gün ücretsiz deneyin", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("Sunucu bağlantısı mevcutsa araca özel deneme belirteci oluşturur.", color = colors.text2, fontSize = 11.sp)
                }
                Button(
                    onClick = onStartTrialClick,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.blue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("7 günlük ücretsiz dene", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // ET5-XXXX-XXXX-XXXX-XXXX input matching setup_20s.jpg
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = licenseCodeInput,
                onValueChange = onLicenseCodeChange,
                label = { Text("Lisans Kodu", color = colors.text2) },
                placeholder = { Text("ET5-XXXX-XXXX-XXXX-XXXX", fontFamily = FontFamily.Monospace) },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.blue,
                    unfocusedBorderColor = colors.stroke,
                    focusedTextColor = colors.text,
                    unfocusedTextColor = colors.text
                )
            )
            Button(
                onClick = onActivateClick,
                colors = ButtonDefaults.buttonColors(containerColor = colors.blue),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.height(54.dp)
            ) {
                if (licenseState.status == LicenseStatus.CHECKING) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                } else {
                    Icon(Icons.Default.Key, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Etkinleştir", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Honest License Status Banner
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = colors.surface2),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Lisans Durumu: ${licenseState.status.name}",
                        color = when (licenseState.status) {
                            LicenseStatus.VALID, LicenseStatus.TRIAL_ACTIVE -> colors.green
                            LicenseStatus.INVALID_CODE, LicenseStatus.EXPIRED -> colors.red
                            else -> colors.amber
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = licenseState.message,
                        color = colors.text2,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionCard(
    title: String,
    desc: String,
    isGranted: Boolean
) {
    val colors = LocalEt5Colors.current
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = colors.surface2),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = desc, color = colors.text2, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isGranted) colors.green.copy(alpha = 0.2f) else colors.amber.copy(alpha = 0.2f))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (isGranted) "Hazır ✓" else "Bekliyor",
                    color = if (isGranted) colors.green else colors.amber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun Step5ObdAndMediaSetup(
    bondedDevices: List<com.example.model.BluetoothDeviceInfo>,
    selectedMac: String,
    onSelectMac: (String) -> Unit,
    hardwareInfo: com.example.model.HardwareDiagnosticInfo
) {
    val colors = LocalEt5Colors.current
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "Adım 5: OBD-II (vLinker MS / ELM327) ve Medya Kaynakları",
            color = colors.blue,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Aracın OBD-II portuna takılı vLinker MS veya ELM327 Bluetooth adaptörünüzü seçin. Cihazınız bağlı değilse atlayabilirsiniz.",
            color = colors.text2,
            fontSize = 12.sp
        )

        if (bondedDevices.isEmpty()) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface2),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Bluetooth, contentDescription = null, tint = colors.amber, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Eşleşmiş Bluetooth OBD cihazı bulunamadı. Daha sonra Kokpitteki OBD menüsünden bağlanabilirsiniz.",
                        color = colors.text2,
                        fontSize = 11.sp
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                bondedDevices.forEach { dev ->
                    val isSelected = selectedMac == dev.address
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectMac(dev.address) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) colors.blue.copy(alpha = 0.2f) else colors.surface2
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = dev.name, color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(text = dev.address, color = colors.text2, fontSize = 11.sp)
                            }
                            if (isSelected) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = colors.blue, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = colors.surface2),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Speed, contentDescription = null, tint = colors.blue, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Desteklenen Medya Kaynakları: İnternet Radyosu, FM Radyo, Bluetooth, USB Müzik, Spotify (${if (hardwareInfo.isSpotifyAppInstalled) "Kurulu" else "Web"}), YouTube Music, Apple Music, Deezer, SoundCloud, Metrolist.",
                    color = colors.text2,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun Step6DriverProfileAndFinish(
    driverName: String,
    onDriverNameChange: (String) -> Unit,
    homeAddress: String,
    onHomeAddressChange: (String) -> Unit,
    workAddress: String,
    onWorkAddressChange: (String) -> Unit,
    cabinTemp: Float,
    onCabinTempChange: (Float) -> Unit,
    selectedRadio: String,
    onSelectRadio: (String) -> Unit,
    selectedCarColor: Int,
    onSelectCarColor: (Int) -> Unit
) {
    val colors = LocalEt5Colors.current
    val carColors = listOf(
        "Ay Gümüşü" to 15330028,
        "Okyanus Mavisi" to 1858450,
        "Lav Kırmızısı" to 10815758,
        "Gece Siyahı" to 1184274
    )

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Adım 6: Sürücü Profili, 3D Araç Rengi ve Başlangıç Tercihleri",
            color = colors.blue,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        OutlinedTextField(
            value = driverName,
            onValueChange = onDriverNameChange,
            label = { Text("Sürücü Adınız (ör. Ahmet / Halil)", color = colors.text2) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.blue,
                unfocusedBorderColor = colors.stroke,
                focusedTextColor = colors.text,
                unfocusedTextColor = colors.text
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = homeAddress,
                onValueChange = onHomeAddressChange,
                label = { Text("Ev Adresi (Navigasyon Kısayolu)", color = colors.text2) },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.blue,
                    unfocusedBorderColor = colors.stroke,
                    focusedTextColor = colors.text,
                    unfocusedTextColor = colors.text
                )
            )

            OutlinedTextField(
                value = workAddress,
                onValueChange = onWorkAddressChange,
                label = { Text("İş Adresi (Navigasyon Kısayolu)", color = colors.text2) },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.blue,
                    unfocusedBorderColor = colors.stroke,
                    focusedTextColor = colors.text,
                    unfocusedTextColor = colors.text
                )
            )
        }

        // 3D Car Paint Color Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("3D ET5 Araç Rengi:", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                carColors.forEach { (label, hex) ->
                    val isSelected = selectedCarColor == hex
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) colors.blue else colors.surface2)
                            .clickable { onSelectCarColor(hex) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else colors.text,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Cabin Temp Slider
        Column {
            Text(
                text = "Varsayılan Klima Hedef Sıcaklığı: ${"%.1f".format(cabinTemp)} °C",
                color = colors.text,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Slider(
                value = cabinTemp,
                onValueChange = onCabinTempChange,
                valueRange = 18.0f..28.0f,
                steps = 19,
                colors = SliderDefaults.colors(thumbColor = colors.blue, activeTrackColor = colors.blue)
            )
        }

        // Starting Radio Station
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            RadioMediaPlayer.PRESET_STATIONS.forEach { st ->
                val isSelected = selectedRadio == st.name
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) colors.blue else colors.surface2)
                        .clickable { onSelectRadio(st.name) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = st.name,
                        color = if (isSelected) Color.White else colors.text,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
