package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.LicenseManager
import com.example.data.db.AppDatabase
import com.example.data.db.DriverProfile
import com.example.hardware.SystemDiagnosticsManager
import com.example.service.vehicle.VehicleBinaryManager
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun readAppNameStringResource() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SkyOS ET5", appName)
    }

    @Test
    fun testRoomDriverProfilePersistence() = runBlocking {
        val dao = db.driverProfileDao()
        val newProfile = DriverProfile(
            name = "Test Sürücü",
            avatarIndex = 1,
            cabinTempCelsius = 21.5f,
            seatPreset = 2,
            favoriteRadioName = "Power FM",
            favoriteDestination = "Ofis",
            isDefault = true
        )

        val id = dao.insertProfile(newProfile)
        assertTrue(id > 0)

        val retrieved = dao.getProfileById(id)
        assertNotNull(retrieved)
        assertEquals("Test Sürücü", retrieved?.name)
        assertEquals(21.5f, retrieved?.cabinTempCelsius ?: 0f, 0.01f)
        assertEquals(2, retrieved?.seatPreset)
    }

    @Test
    fun testSystemDiagnosticsScan() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val diagManager = SystemDiagnosticsManager(context)
        val info = diagManager.scanHardwareEnvironment()

        assertNotNull(info)
        assertNotNull(info.androidVersion)
        assertNotNull(info.gmsStatusDetail)
    }

    @Test
    fun testRadioPresetsAndDefaultStation() {
        val stations = com.example.media.RadioMediaPlayer.PRESET_STATIONS
        assertTrue(stations.isNotEmpty())
        assertEquals("kral_turk_fm", stations[0].id)
        assertEquals("KRAL TÜRK FM", stations[0].name)
        assertEquals("Radyo7", stations[0].logoText)
    }

    @Test
    fun testYouTubeDrivingLockoutHtmlGeneration() {
        val ytManager = com.example.media.YouTubePlayerManager()
        val lockedHtml = ytManager.buildEmbeddedHtml("jNQXAC9IVRw", isDrivingRestricted = true)
        assertTrue(lockedHtml.contains("SÜRÜŞ GÜVENLİĞİ KİLİDİ"))

        val activeHtml = ytManager.buildEmbeddedHtml("jNQXAC9IVRw", isDrivingRestricted = false)
        assertTrue(activeHtml.contains("iframe"))
        assertTrue(activeHtml.contains("jNQXAC9IVRw"))
    }

    @Test
    fun testMediaCoordinatorVolumeBounds() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val coordinator = com.example.media.CarMediaCoordinator(context)
        assertEquals(15, coordinator.volumeLevel.value)

        coordinator.adjustVolume(5)
        assertEquals(20, coordinator.volumeLevel.value)

        coordinator.adjustVolume(-25)
        assertEquals(0, coordinator.volumeLevel.value)

        coordinator.adjustVolume(50)
        assertEquals(30, coordinator.volumeLevel.value)
    }

    @Test
    fun testSkywellGAppsManager() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val gappsManager = com.example.service.gapps.SkywellGAppsManager(context)
        val packages = gappsManager.packages.value

        assertTrue(packages.isNotEmpty())
        assertTrue(packages.any { it.packageName == com.example.service.gapps.SkywellGAppsManager.PKG_GMS })
        assertTrue(packages.any { it.packageName == com.example.service.gapps.SkywellGAppsManager.PKG_GOOGLE_MAPS })
        assertTrue(packages.any { it.packageName == com.example.service.gapps.SkywellGAppsManager.PKG_SPOTIFY })
        assertTrue(packages.any { it.packageName == com.example.service.gapps.SkywellGAppsManager.PKG_YOUTUBE })

        val guide = gappsManager.getSkywellGAppsGuide()
        assertTrue(guide.isNotEmpty())
        assertTrue(guide[0].contains("Skywell ET5"))
    }

    @Test
    fun testSetupManagerConfigurationAndThemePersistence() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        com.example.data.SetupManager.resetSetup(context)
        assertEquals(false, com.example.data.SetupManager.isSetupCompleted(context))

        com.example.data.SetupManager.saveConfiguration(
            context = context,
            vehicleModel = "Skywell ET5 Legend (520 km)",
            licensePlate = "34 SKY 005",
            driverName = "Ahmet Yılmaz",
            homeAddress = "Kadıköy, İstanbul",
            workAddress = "Maslak, İstanbul",
            cabinTempCelsius = 22.5f,
            preferredRadioName = "Kral Türk FM",
            obdMacAddress = "00:1D:A5:00:11:22",
            isDarkTheme = false,
            carColorHex = "#3E6AE1"
        )

        assertEquals(true, com.example.data.SetupManager.isSetupCompleted(context))
        val config = com.example.data.SetupManager.getConfiguration(context)
        assertEquals("Skywell ET5 Legend (520 km)", config.vehicleModel)
        assertEquals("34 SKY 005", config.licensePlate)
        assertEquals("Ahmet Yılmaz", config.driverName)
        assertEquals("Kadıköy, İstanbul", config.homeAddress)
        assertEquals("Maslak, İstanbul", config.workAddress)
        assertEquals(22.5f, config.cabinTempCelsius, 0.01f)
        assertEquals("Kral Türk FM", config.preferredRadioName)
        assertFalse(config.isDarkTheme)
        assertEquals("#3E6AE1", config.carColorHex)

        com.example.data.SetupManager.setDarkTheme(context, true)
        assertTrue(com.example.data.SetupManager.isDarkTheme(context))

        com.example.data.SetupManager.resetSetup(context)
        assertEquals(false, com.example.data.SetupManager.isSetupCompleted(context))
    }

    @Test
    fun testLicenseManagerHonestValidation() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val licenseManager = LicenseManager(context)
        licenseManager.clearLicense()

        val badResult = licenseManager.saveKeyForVerification("WRONG-FORMAT")
        assertFalse(badResult)

        val validFormatResult = licenseManager.saveKeyForVerification("ET5-1234-ABCD-5678-EF90")
        assertTrue(validFormatResult)
        assertFalse(licenseManager.state.value.isVerified)
        assertTrue(licenseManager.state.value.statusText.contains("sunucu imzası doğrulanmadı"))
    }

    @Test
    fun testVehicleBinaryManagerInspectsAracBinHeader() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val binManager = VehicleBinaryManager(context)
        val info = binManager.inspectFirmwareAsset()
        assertNotNull(info)
        if (info.isLoaded) {
            assertEquals("ET5H", info.magicHeader)
            assertEquals("VER a8ff73d5e1f6", info.versionString)
            assertEquals("AES/GCM/NoPadding", info.cipherAlgorithm)
        }
    }
}
