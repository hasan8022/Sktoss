package com.example.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.EventSeat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.vehicle.SkywellCarServiceBridge
import com.example.service.vehicle.VehicleBinaryManager
import com.example.service.vehicle.VehicleConnectionMode
import com.example.ui.SkyOsViewModel
import com.example.ui.components.Skywell3DCarView
import com.example.ui.theme.LocalEt5Colors
import kotlinx.coroutines.launch

/**
 * Exact 21 Settings Categories from SkyOS 2.82 classes.dex (Ln90; enum).
 */
enum class SkyOsSettingsCategory(val title: String, val icon: ImageVector) {
    QUICK("Hızlı Kontroller", Icons.Default.Tune),
    PROFILES("Profiller", Icons.Default.Person),
    SMART("Akıllı Mod", Icons.Default.ElectricBolt),
    CLIMATE("Klima", Icons.Default.AcUnit),
    DRIVING("Sürüş", Icons.Default.DirectionsCar),
    NAVIGATION("Navigasyon", Icons.Default.Navigation),
    SEATS("Koltuklar ve Aynalar", Icons.Default.EventSeat),
    LIGHTS("Işıklar", Icons.Default.Lightbulb),
    LOCKS("Kilitler", Icons.Default.Lock),
    CHARGING("Şarj ve Batarya", Icons.Default.BatteryChargingFull),
    ENERGY("Enerji", Icons.Default.Speed),
    OBD("OBD (vLinker MS)", Icons.Default.Bluetooth),
    DOCS("Bakım ve Belgeler", Icons.Default.Description),
    SAFETY("Güvenlik ve Park", Icons.Default.Security),
    CLUSTER("Gösterge Paneli", Icons.Default.Speed),
    DISPLAY("Ekran", Icons.Default.LightMode),
    SOUND("Ses ve Medya", Icons.Default.VolumeUp),
    CONNECTIVITY("Bağlantılar", Icons.Default.Wifi),
    SMARTHOME("Akıllı Ev", Icons.Default.Home),
    SOFTWARE("Yazılım", Icons.Default.SystemUpdate),
    SERVICE("Servis", Icons.Default.Build)
}

@Composable
fun VehicleControlScreen(
    viewModel: SkyOsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val colors = LocalEt5Colors.current
    val scope = rememberCoroutineScope()

    val vehicleProfile = remember { VehicleBinaryManager.loadVehicleProfile(context) }
    val hardwareInfo by viewModel.hardwareInfo.collectAsState()
    val vehicleState by viewModel.vehicleState.collectAsState()
    val licenseState by viewModel.licenseState.collectAsState()
    val isDriving by viewModel.isDriving.collectAsState()
    val effectiveSpeed by viewModel.effectiveSpeedKmh.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val use3DCarView by viewModel.use3DCarView.collectAsState()
    val carColorHex by viewModel.carColorHex.collectAsState()
    val blockVideoInMotion by viewModel.blockVideoInMotion.collectAsState()
    val radarDistanceCm by viewModel.radarDistanceCm.collectAsState()

    var selectedCategory by remember { mutableStateOf(SkyOsSettingsCategory.QUICK) }
    var searchFilter by remember { mutableStateOf("") }
    var actionFeedback by remember { mutableStateOf<String?>(null) }

    // Password / PIN Modal Dialog state (matching runtime_360s.jpg: "Lütfen parolanı girin...")
    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordDialogTitle by remember { mutableStateOf("Lütfen parolanı girin...") }
    var passwordInput by remember { mutableStateOf("") }
    var onPasswordConfirmed by remember { mutableStateOf<(String) -> Unit>({}) }

    // Local UI controls synced with vehicle bridge
    var cabinTempTarget by remember { mutableFloatStateOf(vehicleState.hvacTargetTempC) }
    var fanSpeed by remember { mutableFloatStateOf(vehicleState.hvacFanSpeed.toFloat()) }
    var isAcActive by remember { mutableStateOf(vehicleState.hvacAcOn) }
    var isRecirculation by remember { mutableStateOf(vehicleState.hvacRecircOn) }
    var regenLevel by remember { mutableFloatStateOf(vehicleState.regenPercent.toFloat()) }
    var chargeLimitPct by remember { mutableFloatStateOf(vehicleState.chargeLimitPercent.toFloat()) }
    var activeSmartMode by remember { mutableStateOf("KAPALI") } // KAPALI, KAMP, EVCIL, UYKU, YIKAMA, VALE
    var joeModeEnabled by remember { mutableStateOf(false) }
    var homeAssistantUrl by remember { mutableStateOf("") }

    val filteredCategories = remember(searchFilter) {
        if (searchFilter.isBlank()) SkyOsSettingsCategory.entries
        else SkyOsSettingsCategory.entries.filter {
            it.title.contains(searchFilter, ignoreCase = true)
        }
    }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(colors.bg)
            .testTag("vehicle_control_screen")
    ) {
        // Left Sidebar: 21 SkyOS 2.82 Categories (Ln90;)
        Column(
            modifier = Modifier
                .width(225.dp)
                .fillMaxHeight()
                .background(colors.surface)
                .border(1.dp, colors.stroke)
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Ayarlar & Araç",
                    color = colors.text,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
                IconButton(
                    onClick = { viewModel.openMap() },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Haritaya Dön", tint = colors.text2, modifier = Modifier.size(16.dp))
                }
            }

            OutlinedTextField(
                value = searchFilter,
                onValueChange = { searchFilter = it },
                placeholder = { Text("Ayarlarda ara...", fontSize = 11.sp) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = colors.text,
                    unfocusedTextColor = colors.text,
                    focusedBorderColor = colors.blue,
                    unfocusedBorderColor = colors.stroke
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredCategories) { cat ->
                    val isSelected = cat == selectedCategory
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) colors.blue else Color.Transparent)
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = cat.icon,
                            contentDescription = null,
                            tint = if (isSelected) Color.White else colors.text2,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = cat.title,
                            color = if (isSelected) Color.White else colors.text,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Right Content Area
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(14.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top Vehicle Connection & Safety Status Banner
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, colors.stroke, RoundedCornerShape(14.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${selectedCategory.title} • ${vehicleState.statusDetail}",
                            color = colors.text,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (vehicleState.connectionMode == VehicleConnectionMode.DISCONNECTED) {
                                "VCU/CarPropertyManager bağlı değil — komutlar yalnızca araç üzerinde CarService veya AracYardimci:8724 aktifken uygulanır."
                            } else {
                                "Canlı araç veri yolu aktif (${vehicleState.connectionMode.name})."
                            },
                            color = colors.text2,
                            fontSize = 11.sp
                        )
                        actionFeedback?.let { fb ->
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = fb, color = colors.blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isDriving) colors.red.copy(alpha = 0.15f) else colors.green.copy(alpha = 0.15f)
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = if (isDriving) "SÜRÜŞTE (${"%.0f".format(effectiveSpeed)} km/s)" else "PARK (P)",
                            color = if (isDriving) colors.red else colors.green,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Always show the 3D Skywell ET5 Model on Quick Controls, Doors/Locks, Lights, or Display
            if (selectedCategory in listOf(
                    SkyOsSettingsCategory.QUICK,
                    SkyOsSettingsCategory.LOCKS,
                    SkyOsSettingsCategory.LIGHTS,
                    SkyOsSettingsCategory.DISPLAY,
                    SkyOsSettingsCategory.SEATS
                )
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = colors.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, colors.stroke, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Skywell ET5 3D Model (et5.glb • ${vehicleProfile.versionString})",
                                color = colors.text,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Parçalara dokunarak kapı/bagaj kontrolü",
                                color = colors.text2,
                                fontSize = 10.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(230.dp)
                        ) {
                            Skywell3DCarView(
                                doors = vehicleState.doorsOpen,
                                isHoodOpen = vehicleState.hoodOpen,
                                isTrunkOpen = vehicleState.trunkOpen,
                                isHeadlightOn = vehicleState.lowBeamOn || vehicleState.highBeamOn,
                                radarDistanceCm = radarDistanceCm,
                                carColorHex = carColorHex,
                                onPartTap = { part ->
                                    when (part) {
                                        "dFL", "dFR", "dRL", "dRR" -> viewModel.toggleDriverDoor()
                                        "trunk" -> viewModel.toggleTrunk()
                                    }
                                },
                                showControls = true,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }

            // Category-specific content
            when (selectedCategory) {
                SkyOsSettingsCategory.QUICK,
                SkyOsSettingsCategory.LOCKS,
                SkyOsSettingsCategory.LIGHTS -> {
                    SettingsSectionCard(title = "Hızlı Kontroller, Kapılar, Bagaj, Cam Tavan ve Aydınlatma") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ActionBtn("Kapı Kilidi", Icons.Default.LockOpen, Modifier.weight(1f)) {
                                viewModel.toggleDriverDoor()
                            }
                            ActionBtn("Bagaj Kapağı", Icons.Default.DirectionsCar, Modifier.weight(1f)) {
                                viewModel.toggleTrunk()
                            }
                            ActionBtn("LED Farlar", Icons.Default.Lightbulb, Modifier.weight(1f)) {
                                viewModel.toggleHeadlights()
                            }
                            ActionBtn(
                                if (isDarkTheme) "Açık Tema" else "Koyu Tema",
                                if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                Modifier.weight(1f)
                            ) {
                                viewModel.toggleDarkTheme()
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ActionBtn("Cam Tavan Aç/Kapat", Icons.Default.Air, Modifier.weight(1f)) {
                                scope.launch {
                                    viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                        SkywellCarServiceBridge.PROP_SUNROOF_POS, 0, "i", "50"
                                    )
                                }
                            }
                            ActionBtn("Güneşlik Perde", Icons.Default.Tune, Modifier.weight(1f)) {
                                scope.launch {
                                    viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                        SkywellCarServiceBridge.PROP_SUNROOF_SHADE, 0, "i", "1"
                                    )
                                }
                            }
                            ActionBtn("Camları Havalandır", Icons.Default.Air, Modifier.weight(1f)) {
                                scope.launch {
                                    viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                        SkywellCarServiceBridge.PROP_WINDOW_POS, 16, "i", "15", requireParkGear = true
                                    )
                                }
                            }
                        }
                    }
                }

                SkyOsSettingsCategory.CLIMATE -> {
                    SettingsSectionCard(title = "Kabin İklimlendirme & Klima (0x15600503 / SkyHVAC)") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("A/C Kompresör & Klima Gücü", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Switch(
                                checked = isAcActive,
                                onCheckedChange = {
                                    isAcActive = it
                                    scope.launch {
                                        viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                            SkywellCarServiceBridge.PROP_HVAC_AC, 0, "b", it.toString()
                                        )
                                    }
                                },
                                colors = SwitchDefaults.colors(checkedThumbColor = colors.blue)
                            )
                        }

                        Text("Hedef Sıcaklık: ${"%.1f".format(cabinTempTarget)} °C", color = colors.blue, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Slider(
                            value = cabinTempTarget,
                            onValueChange = {
                                cabinTempTarget = it
                                viewModel.adjustDriverTemp(it - viewModel.driverTempC.value)
                            },
                            valueRange = 18f..32f,
                            steps = 27,
                            colors = SliderDefaults.colors(thumbColor = colors.blue, activeTrackColor = colors.blue)
                        )

                        Text("Fan Kademesi: ${fanSpeed.toInt()} (1-7)", color = colors.text2, fontSize = 12.sp)
                        Slider(
                            value = fanSpeed,
                            onValueChange = {
                                fanSpeed = it
                                scope.launch {
                                    viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                        SkywellCarServiceBridge.PROP_HVAC_FAN_SPEED, 0, "i", it.toInt().toString()
                                    )
                                }
                            },
                            valueRange = 1f..7f,
                            steps = 5,
                            colors = SliderDefaults.colors(thumbColor = colors.blue, activeTrackColor = colors.blue)
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionBtn("Ön Buğu Çözme", Icons.Default.Air, Modifier.weight(1f)) {
                                viewModel.toggleFrontDefrost()
                            }
                            ActionBtn("Arka Rezistans", Icons.Default.AcUnit, Modifier.weight(1f)) {
                                viewModel.toggleRearDefrost()
                            }
                            ActionBtn(
                                if (isRecirculation) "İç Dolaşım: Açık" else "Dış Hava",
                                Icons.Default.Refresh,
                                Modifier.weight(1f)
                            ) {
                                isRecirculation = !isRecirculation
                                scope.launch {
                                    viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                        SkywellCarServiceBridge.PROP_HVAC_RECIRC, 0, "b", isRecirculation.toString()
                                    )
                                }
                            }
                        }
                    }
                }

                SkyOsSettingsCategory.SMART -> {
                    SettingsSectionCard(title = "Akıllı Modlar (Kamp, Evcil Hayvan, Uyku, Oto Yıkama, Vale Modu)") {
                        Text(
                            text = "Aktif Mod: $activeSmartMode (Yalnızca P vitesinde etkinleştirilebilir)",
                            color = colors.blue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("KAMP", "EVCİL HAYVAN", "UYKU", "OTO YIKAMA", "VALE MODU").forEach { mode ->
                                val isAct = activeSmartMode == mode
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isAct) colors.blue else colors.surface2)
                                        .clickable {
                                            if (isDriving) {
                                                actionFeedback = "Güvenlik: sadece P vitesinde"
                                            } else if (mode == "VALE MODU") {
                                                passwordDialogTitle = "Vale modu için 4 haneli PIN girin..."
                                                passwordInput = ""
                                                onPasswordConfirmed = { pin ->
                                                    if (pin.length >= 4) {
                                                        activeSmartMode = if (isAct) "KAPALI" else "VALE MODU"
                                                        actionFeedback = "Vale Modu PIN doğrulandı: $activeSmartMode"
                                                    } else {
                                                        actionFeedback = "PIN en az 4 karakter olmalıdır"
                                                    }
                                                }
                                                showPasswordDialog = true
                                            } else {
                                                activeSmartMode = if (isAct) "KAPALI" else mode
                                                actionFeedback = "$mode seçildi (P vitesi kontrol edildi)"
                                            }
                                        }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = mode,
                                        color = if (isAct) Color.White else colors.text,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                SkyOsSettingsCategory.DRIVING -> {
                    SettingsSectionCard(title = "Sürüş Modu, Rejeneratif Frenleme (Geri Kazanım) & ESC") {
                        Text("Rejeneratif Geri Kazanım Oranı: %${regenLevel.toInt()}", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Slider(
                            value = regenLevel,
                            onValueChange = {
                                regenLevel = it
                                scope.launch {
                                    viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                        SkywellCarServiceBridge.PROP_REGEN_LEVEL, 0, "i", it.toInt().toString()
                                    )
                                }
                            },
                            valueRange = 0f..100f,
                            steps = 9,
                            colors = SliderDefaults.colors(thumbColor = colors.blue, activeTrackColor = colors.blue)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionBtn("Normal Mod", Icons.Default.DirectionsCar, Modifier.weight(1f)) {
                                scope.launch {
                                    viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                        SkywellCarServiceBridge.PROP_DRIVE_MODE, 0, "i", "0"
                                    )
                                }
                            }
                            ActionBtn("Eco Mod", Icons.Default.ElectricBolt, Modifier.weight(1f)) {
                                scope.launch {
                                    viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                        SkywellCarServiceBridge.PROP_DRIVE_MODE, 0, "i", "1"
                                    )
                                }
                            }
                            ActionBtn("Sport Mod", Icons.Default.Speed, Modifier.weight(1f)) {
                                scope.launch {
                                    viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                        SkywellCarServiceBridge.PROP_DRIVE_MODE, 0, "i", "2"
                                    )
                                }
                            }
                            ActionBtn("ESC Aç/Kapat", Icons.Default.Security, Modifier.weight(1f)) {
                                viewModel.toggleEsc()
                            }
                        }
                    }
                }

                SkyOsSettingsCategory.DISPLAY -> {
                    SettingsSectionCard(title = "Ekran, Açık/Koyu Tema ve 3D Araç Görünümü") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Kokpit Teması (Koyu / Açık)", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("SkyOS 2.82 orijinal koyu ve açık tema renk paletleri (LCx;)", color = colors.text2, fontSize = 11.sp)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { viewModel.setDarkTheme(true) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isDarkTheme) colors.blue else colors.surface2
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Koyu", color = if (isDarkTheme) Color.White else colors.text, fontSize = 12.sp)
                                }
                                Button(
                                    onClick = { viewModel.setDarkTheme(false) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (!isDarkTheme) colors.blue else colors.surface2
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Açık", color = if (!isDarkTheme) Color.White else colors.text, fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Sol Sürüş Panelinde 3D ET5 Modeli Göster", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("Kapalıyken 2D üstten görünüm (arac_ust.png) kullanılır", color = colors.text2, fontSize = 11.sp)
                            }
                            Switch(
                                checked = use3DCarView,
                                onCheckedChange = { viewModel.toggle3DCarView() },
                                colors = SwitchDefaults.colors(checkedThumbColor = colors.blue)
                            )
                        }
                    }
                }

                SkyOsSettingsCategory.SOUND,
                SkyOsSettingsCategory.SAFETY -> {
                    SettingsSectionCard(title = "Ses, Medya ve Sürüş Güvenliği (surus_video & Joe Modu)") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Sürüş Sırasında Video Oynatımını Engelle", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("Vites P dışında veya hız > 0 km/s olduğunda video görüntüsü güvenlik gereği kilitlenir.", color = colors.text2, fontSize = 11.sp)
                            }
                            Switch(
                                checked = blockVideoInMotion,
                                onCheckedChange = { viewModel.setBlockVideoInMotion(it) },
                                colors = SwitchDefaults.colors(checkedThumbColor = colors.green)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Joe Modu (Arka Koltuk Sessizliği)", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("Uyarı seslerini kısar ve ses alanını sürücü koltuğuna odaklar (Et5Joe).", color = colors.text2, fontSize = 11.sp)
                            }
                            Switch(
                                checked = joeModeEnabled,
                                onCheckedChange = {
                                    joeModeEnabled = it
                                    actionFeedback = if (it) "Joe modu açıldı (ses öne odaklandı)" else "Joe modu kapandı"
                                },
                                colors = SwitchDefaults.colors(checkedThumbColor = colors.blue)
                            )
                        }
                    }
                }

                SkyOsSettingsCategory.CHARGING,
                SkyOsSettingsCategory.ENERGY -> {
                    SettingsSectionCard(title = "Şarj Sınırı (0x11600319), Batarya ve Tüketim") {
                        Text("Hedef Şarj Sınırı: %${chargeLimitPct.toInt()}", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Slider(
                            value = chargeLimitPct,
                            onValueChange = {
                                chargeLimitPct = it
                                scope.launch {
                                    viewModel.vehicleBridge.sendVehiclePropertyCommand(
                                        SkywellCarServiceBridge.PROP_CHARGE_LIMIT_PCT, 0, "f", it.toInt().toString()
                                    )
                                }
                            },
                            valueRange = 50f..100f,
                            steps = 9,
                            colors = SliderDefaults.colors(thumbColor = colors.green, activeTrackColor = colors.green)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionBtn("Şarjı Durdur", Icons.Default.BatteryChargingFull, Modifier.weight(1f)) {
                                viewModel.stopCharging()
                            }
                            ActionBtn("OBD & Enerji Ekranı", Icons.Default.Speed, Modifier.weight(1f)) {
                                viewModel.openObdDiagnostics()
                            }
                        }
                    }
                }

                SkyOsSettingsCategory.PROFILES -> {
                    SettingsSectionCard(title = "Sürücü Profilleri") {
                        ActionBtn("Sürücü Profilleri Yöneticisini Aç", Icons.Default.Person, Modifier.fillMaxWidth()) {
                            viewModel.openDriverProfiles()
                        }
                    }
                }

                SkyOsSettingsCategory.OBD -> {
                    SettingsSectionCard(title = "OBD-II (vLinker MS / ELM327) Canlı Veri ve Arıza Teşhisi") {
                        ActionBtn("OBD-II & CAN Teşhis Merkezini Aç", Icons.Default.Bluetooth, Modifier.fillMaxWidth()) {
                            viewModel.openObdDiagnostics()
                        }
                    }
                }

                SkyOsSettingsCategory.SMARTHOME -> {
                    SettingsSectionCard(title = "Akıllı Ev (Home Assistant Entegrasyonu)") {
                        OutlinedTextField(
                            value = homeAssistantUrl,
                            onValueChange = { homeAssistantUrl = it },
                            label = { Text("Home Assistant Sunucu Adresi (ör. http://192.168.1.50:8123)", color = colors.text2) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = colors.text,
                                unfocusedTextColor = colors.text,
                                focusedBorderColor = colors.blue,
                                unfocusedBorderColor = colors.stroke
                            )
                        )
                    }
                }

                SkyOsSettingsCategory.SOFTWARE,
                SkyOsSettingsCategory.SERVICE -> {
                    SettingsSectionCard(title = "Yazılım, Lisans, Geliştirici Parolası ve Kurtarma (SkyOS 2.82 · Yapı 193)") {
                        Text(
                            text = "Sürüm: SkyOS 2.82 (versionCode 193) • Araç Varlığı: ${vehicleProfile.versionString}",
                            color = colors.text,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Lisans Durumu: ${licenseState.status.name} — ${licenseState.message}",
                            color = colors.text2,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionBtn("Parola / PIN Gir", Icons.Default.Key, Modifier.weight(1f)) {
                                passwordDialogTitle = "Lütfen parolanı girin..."
                                passwordInput = ""
                                onPasswordConfirmed = { pwd ->
                                    if (pwd == "MzMyMQ") {
                                        val devIntent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        }
                                        try { context.startActivity(devIntent) } catch (_: Exception) {}
                                        actionFeedback = "Coocaa OS geliştirici parolası (MzMyMQ) doğrulandı."
                                    } else {
                                        actionFeedback = "Girilen parola: $pwd"
                                    }
                                }
                                showPasswordDialog = true
                            }
                            ActionBtn("Kurulum Sihirbazı", Icons.Default.Refresh, Modifier.weight(1f)) {
                                viewModel.restartSetupWizard()
                            }
                            ActionBtn("Orijinal Araç Ekranına Dön", Icons.Default.DirectionsCar, Modifier.weight(1f)) {
                                viewModel.returnToStockLauncher()
                            }
                        }
                    }
                }

                else -> {
                    SettingsSectionCard(title = selectedCategory.title) {
                        Text(
                            text = "${selectedCategory.title} ayarları SkywellCarServiceBridge (CarPropertyManager / AracYardimci:8724) üzerinden yönetilir.",
                            color = colors.text2,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionBtn("Sistem & Donanım Teşhisi", Icons.Default.Settings, Modifier.weight(1f)) {
                                viewModel.selectDockTab(com.example.ui.components.ActiveDockTab.APPS)
                            }
                            ActionBtn("360° Kamera Aç", Icons.Default.Security, Modifier.weight(1f)) {
                                viewModel.launchOem360Camera()
                            }
                        }
                    }
                }
            }
        }
    }

    // Password / PIN Input Modal Dialog (matching runtime_360s.jpg: "Lütfen parolanı girin...", "Tamam", "İptal")
    if (showPasswordDialog) {
        AlertDialog(
            onDismissRequest = { showPasswordDialog = false },
            containerColor = colors.surface,
            title = {
                Text(passwordDialogTitle, color = colors.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Coocaa OS geliştirici seçenekleri için 'MzMyMQ' veya 4 haneli Vale PIN kodunuzu girin:",
                        color = colors.text2,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        placeholder = { Text("Parola / PIN", fontFamily = FontFamily.Monospace) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = colors.text,
                            unfocusedTextColor = colors.text,
                            focusedBorderColor = colors.blue,
                            unfocusedBorderColor = colors.stroke
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPasswordDialog = false
                        onPasswordConfirmed(passwordInput.trim())
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.blue)
                ) {
                    Text("Tamam", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPasswordDialog = false }) {
                    Text("İptal", color = colors.text2)
                }
            }
        )
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    val colors = LocalEt5Colors.current
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = colors.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, colors.stroke, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = title, color = colors.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun ActionBtn(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalEt5Colors.current
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = colors.surface2),
        modifier = modifier
    ) {
        Icon(icon, contentDescription = null, tint = colors.blue, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, color = colors.text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}
