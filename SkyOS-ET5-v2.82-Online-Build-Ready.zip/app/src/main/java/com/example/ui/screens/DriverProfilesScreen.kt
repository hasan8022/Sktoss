package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.DriverProfile
import com.example.ui.SkyOsViewModel
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCard
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyDivider
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyNavy
import com.example.ui.theme.SkyRed
import com.example.ui.theme.SkySurface
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary

@Composable
fun DriverProfilesScreen(
    viewModel: SkyOsViewModel,
    modifier: Modifier = Modifier
) {
    val profiles by viewModel.driverProfiles.collectAsState()
    val activeProfile by viewModel.activeProfile.collectAsState()

    var newDriverName by remember { mutableStateOf("") }
    var targetTemp by remember { mutableFloatStateOf(22.0f) }
    var seatPreset by remember { mutableIntStateOf(1) }
    var favoriteRadio by remember { mutableStateOf("TRT FM") }
    var favoriteDestination by remember { mutableStateOf("Ev") }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(SkyNavy)
            .padding(16.dp)
            .testTag("driver_profiles_screen"),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Saved Profiles List
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Kayıtlı Sürücü Profilleri (Room Veritabanı)",
                    color = SkyTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(profiles) { profile ->
                        val isActive = profile.id == activeProfile?.id || (activeProfile == null && profile.isDefault)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isActive) SkyCyan.copy(alpha = 0.15f) else SkyNavy)
                                .clickable { viewModel.setActiveProfile(profile) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(if (isActive) SkyCyan else SkySurface, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = if (isActive) Color(0xFF041E26) else SkyTextPrimary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = profile.name,
                                            color = if (isActive) SkyCyan else SkyTextPrimary,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (isActive) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(SkyGreen, RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Text("AKTİF", color = Color(0xFF041E26), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                    Text(
                                        text = "Klima: ${"%.1f".format(profile.cabinTempCelsius)}°C | Koltuk: ${profile.seatPreset} | Radyo: ${profile.favoriteRadioName}",
                                        color = SkyTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (!isActive) {
                                    Button(
                                        onClick = { viewModel.setActiveProfile(profile) },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = SkyCyan),
                                        modifier = Modifier.height(30.dp)
                                    ) {
                                        Text("Seç", color = Color(0xFF041E26), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                if (profiles.size > 1) {
                                    IconButton(
                                        onClick = { viewModel.deleteProfile(profile) },
                                        modifier = Modifier.size(30.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Sil",
                                            tint = SkyRed,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Right Column: Add New Driver Profile Form
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Yeni Sürücü Profili Ekle",
                    color = SkyCyan,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = newDriverName,
                    onValueChange = { newDriverName = it },
                    label = { Text("Sürücü Adı & Soyadı", fontSize = 12.sp) },
                    placeholder = { Text("Örn: Hasan Yılmaz", fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SkyNavy,
                        unfocusedContainerColor = SkyNavy,
                        focusedTextColor = SkyTextPrimary,
                        unfocusedTextColor = SkyTextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Column {
                    Text("Hedef Kabin Sıcaklığı: ${"%.1f".format(targetTemp)}°C", color = SkyTextSecondary, fontSize = 12.sp)
                    Slider(
                        value = targetTemp,
                        onValueChange = { targetTemp = it },
                        valueRange = 17f..28f,
                        steps = 22,
                        colors = SliderDefaults.colors(thumbColor = SkyCyan, activeTrackColor = SkyCyan)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Koltuk Hafıza Pozisyonu:", color = SkyTextSecondary, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (i in 1..3) {
                            Button(
                                onClick = { seatPreset = i },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (seatPreset == i) SkyCyan else SkyNavy
                                ),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Text(
                                    text = "$i",
                                    color = if (seatPreset == i) Color(0xFF041E26) else SkyTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = favoriteRadio,
                    onValueChange = { favoriteRadio = it },
                    label = { Text("Favori Radyo İstasyonu", fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SkyNavy,
                        unfocusedContainerColor = SkyNavy,
                        focusedTextColor = SkyTextPrimary,
                        unfocusedTextColor = SkyTextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = favoriteDestination,
                    onValueChange = { favoriteDestination = it },
                    label = { Text("Favori Navigasyon Hedefi", fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SkyNavy,
                        unfocusedContainerColor = SkyNavy,
                        focusedTextColor = SkyTextPrimary,
                        unfocusedTextColor = SkyTextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.weight(1f))

                Button(
                    onClick = {
                        if (newDriverName.isNotBlank()) {
                            viewModel.addNewProfile(
                                name = newDriverName.trim(),
                                temp = targetTemp,
                                seat = seatPreset,
                                radio = favoriteRadio.trim(),
                                dest = favoriteDestination.trim()
                            )
                            newDriverName = ""
                        }
                    },
                    enabled = newDriverName.isNotBlank(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SkyCyan),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF041E26), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Profili Kaydet", color = Color(0xFF041E26), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
