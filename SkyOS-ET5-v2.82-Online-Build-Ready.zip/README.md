# SkyOS ET5 — Android Studio source project

SkyOS ET5 is an Android/Jetpack Compose automotive UI project intended for development and hardware validation. This repository is a development baseline, not a certified vehicle-control system.

## What is included

- Kotlin + Jetpack Compose cockpit UI
- Driver profiles stored with Room
- Android GPS provider and system diagnostics
- Bluetooth RFCOMM / Wi-Fi TCP ELM327 transport layer for generic OBD-II
- Internet radio playback using Android MediaPlayer
- Official Spotify Web Player WebView pane
- Official YouTube web/embedded-player approach
- Local ET5 3D model assets and map-lite assets
- Explicit safety and integration status documentation (`REALITY_STATUS.md`)

## Important limitations

- No validated Skywell ET5 OEM control API, proprietary CAN map, BMS map or safe actuator command protocol is included. HVAC, doors, trunk, lights, gear and seat-heating actions are intentionally not sent to the vehicle.
- Generic OBD-II does not guarantee EV battery SOC/SoH, cell voltages, battery temperature, HVAC state or EV motor telemetry.
- Spotify HUD account/playlist integration is not implemented. OAuth credentials and a supported Spotify playback integration are required. The official Spotify Web Player view is provided separately.
- YouTube Data API search is not configured. The project no longer fabricates search results or sample videos.
- Radio stream URLs require validation on the target network/device.
- Google Maps, GMS-free behavior, and all infotainment-specific behavior require real-device tests.

See `REALITY_STATUS.md` before treating any feature as operational.

## Open in Android Studio

1. Use a current Android Studio release compatible with Android Gradle Plugin 9.1.1.
2. Open this folder as an existing Gradle project.
3. Use JDK 17 or the JDK required by the installed Android Gradle Plugin.
4. Allow Android Studio to resolve the Gradle distribution and dependencies.
5. Add any required local configuration only after reviewing `.env.example` and the relevant provider documentation.
6. Sync, build, and run unit/instrumentation tests.

The archive currently does not include a Gradle Wrapper JAR or wrapper launch scripts. Android Studio may need to configure/download the Gradle distribution before building. No APK build is claimed from this delivery.

## Hardware validation required

Before enabling any vehicle control, obtain the correct VIN/model-year/firmware-specific Skywell documentation or manufacturer-approved API access. Verify read-only signals first with a safe test setup. Do not transmit guessed CAN frames or UDS commands.

## Target vehicle configuration
The current target is the user's 2023 Skywell ET5. Setup defaults were changed to this model year; personal fields such as plate, driver name, and addresses are left blank rather than populated with invented values.

## APK-first recovery (SkyOS 2.82)

The original `SkyOS-2.82.apk` is the primary evidence source for this reconstruction. The complete APK ZIP payload is extracted under `recovery_reference/full_apk_dump/`; the compiled resource table, DEX and binary manifest are also indexed under `recovery_reference/compiled_android/`. Exact copies of all APK `assets/` entries are available to the app under `app/src/main/assets/recovered_original/`.

See `APK_FULL_RECOVERY_REPORT.md` and `APK_FULL_INVENTORY.json` for the SHA-256, byte sizes and complete extracted-file inventory. Compiled resources and DEX are preserved as evidence; they are not mistaken for original Kotlin/XML source. Only assets with understood runtime paths should be wired into the app. OEM services and vehicle write operations require verified interfaces and hardware testing.
