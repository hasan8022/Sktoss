package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HardwareDiagnosticInfo
import com.example.ui.SkyOsViewModel
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCard
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyDivider
import com.example.ui.theme.SkyElectricBlue
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyNavy
import com.example.ui.theme.SkyRed
import com.example.ui.theme.SkySurface
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary

@Composable
fun SystemDiagnosticsScreen(
    viewModel: SkyOsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hardwareInfo by viewModel.hardwareInfo.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SkyNavy)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("system_diagnostics_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Geliştirici & Sistem Teşhis Merkezi",
                    color = SkyTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Skywell ET5 / Android Donanım Ortamı Denetimi",
                    color = SkyCyan,
                    fontSize = 12.sp
                )
            }

            Button(
                onClick = { viewModel.refreshHardwareAudit() },
                colors = ButtonDefaults.buttonColors(containerColor = SkyCyan),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF041E26), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Yeniden Tara", color = Color(0xFF041E26), fontWeight = FontWeight.Bold)
            }
        }

        // Section 1: Android OS & Device Info
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Android, contentDescription = null, tint = SkyGreen, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("İşletim Sistemi & Donanım Kimliği", color = SkyTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(12.dp))

                DiagRow("Android Sürümü", "${hardwareInfo.androidVersion} (API ${hardwareInfo.sdkInt})")
                DiagRow("Üretici (Manufacturer)", hardwareInfo.manufacturer)
                DiagRow("Model", hardwareInfo.model)
                DiagRow("Marka (Brand)", hardwareInfo.brand)
                DiagRow("Anakart (Board)", hardwareInfo.board)
                DiagRow("Donanım (Hardware SoC)", hardwareInfo.hardware)
                DiagRow("Yapı Numarası (Display ID)", hardwareInfo.displayBuildId)
            }
        }

        // Section 2: GApps / Google Play Services & WebView Status
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = SkyCyan, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("GApps (Google Play Hizmetleri) & Bağımsızlık Analizi", color = SkyTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(12.dp))

                DiagRow(
                    label = "Google Play Hizmetleri (GMS)",
                    value = hardwareInfo.gmsStatusDetail,
                    valueColor = if (hardwareInfo.isGmsAvailable) SkyGreen else SkyAmber
                )
                DiagRow("Google Haritalar Uygulaması", if (hardwareInfo.isGoogleMapsAppInstalled) "Yüklü" else "Yüklü Değil (Web Fallback Devrede)")
                DiagRow("Spotify Uygulaması", if (hardwareInfo.isSpotifyAppInstalled) "Yüklü (App Remote Destekli)" else "Yüklü Değil")
                DiagRow("YouTube Uygulaması", if (hardwareInfo.isYouTubeAppInstalled) "Yüklü" else "Yüklü Değil")
                DiagRow("Android System WebView Paketi", hardwareInfo.webViewPackage)
                DiagRow("WebView Sürümü", hardwareInfo.webViewVersion)

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { viewModel.openGAppsHub() },
                    colors = ButtonDefaults.buttonColors(containerColor = SkyCyan),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF041E26), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Skywell GApps & Uygulama Paket Yöneticisi", color = Color(0xFF041E26), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Section 3: Developer Options, ADB & USB Host
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DeveloperMode, contentDescription = null, tint = SkyAmber, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("USB Hata Ayıklama (ADB) & USB Host Portları", color = SkyTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(12.dp))

                DiagRow(
                    label = "ADB Hata Ayıklama Durumu",
                    value = if (hardwareInfo.isAdbEnabled) "ETKİN (Açık)" else "DEVRE DIŞI (Kapalı)",
                    valueColor = if (hardwareInfo.isAdbEnabled) SkyGreen else SkyAmber
                )

                DiagRow(
                    label = "Bağlı USB Cihaz Sayısı",
                    value = "${hardwareInfo.usbDevices.size} Cihaz Algılandı"
                )

                if (hardwareInfo.usbDevices.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    for (dev in hardwareInfo.usbDevices) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SkyNavy, RoundedCornerShape(6.dp))
                                .padding(8.dp)
                        ) {
                            Text(dev, color = SkyCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                }
            }
        }

        // Section 4: Network & Battery Power
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Wifi, contentDescription = null, tint = SkyElectricBlue, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Ağ Bağlantısı & Güç Kaynağı", color = SkyTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(12.dp))

                DiagRow(
                    label = "İnternet Bağlantısı",
                    value = if (hardwareInfo.isInternetConnected) "Bağlı (${hardwareInfo.networkType})" else "Bağlantı Yok",
                    valueColor = if (hardwareInfo.isInternetConnected) SkyGreen else SkyRed
                )

                if (hardwareInfo.internalBatteryLevel >= 0) {
                    DiagRow("Cihaz Bataryası / Şarj", "%${hardwareInfo.internalBatteryLevel} (${if (hardwareInfo.isDeviceCharging) "Şarj Oluyor / Kontak Açık" else "Bataryada"})")
                }
            }
        }

        // Section 5: Android System Settings Shortcuts (Legitimate OS Settings Navigation)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Android Sistem Ayarları Kısayolları", color = SkyTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Güvenlik gereği ayarlar arka planda izinsiz değiştirilmez; ilgili Android ayar sayfası doğrudan açılır.",
                    color = SkyTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            try { context.startActivity(intent) } catch (_: Exception) {
                                context.startActivity(Intent(Settings.ACTION_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Geliştirici Ayarları", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            try { context.startActivity(intent) } catch (_: Exception) {}
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Bluetooth", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            try { context.startActivity(intent) } catch (_: Exception) {}
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Wi-Fi & Ağ", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            try { context.startActivity(intent) } catch (_: Exception) {}
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("GPS Konum", fontSize = 11.sp)
                    }
                }
            }
        }

        // Section 6: Kurulum Sihirbazı & Araç Yapılandırması
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SkyOS ET5 Kurulum & Araç Yapılandırması",
                    color = SkyTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Araç donanım paketini (Legend/Premium/Exclusive), plaka bilgisini, sürücü adını, ev/iş rotalarını veya OBD-II eşleştirmesini değiştirmek için kurulum sihirbazını başlatın.",
                    color = SkyTextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { viewModel.restartSetupWizard() },
                    colors = ButtonDefaults.buttonColors(containerColor = SkyElectricBlue),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("restart_setup_wizard_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Kurulum Sihirbazını Yeniden Başlat", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DiagRow(label: String, value: String, valueColor: Color = SkyCyan) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = SkyTextSecondary, fontSize = 12.sp)
        Text(text = value, color = valueColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
