package com.example.data.db

import kotlinx.coroutines.flow.Flow

class DriverProfileRepository(private val dao: DriverProfileDao) {
    val allProfiles: Flow<List<DriverProfile>> = dao.getAllProfiles()
    val defaultProfile: Flow<DriverProfile?> = dao.getDefaultProfile()

    suspend fun insertProfile(profile: DriverProfile): Long = dao.insertProfile(profile)

    suspend fun updateProfile(profile: DriverProfile) = dao.updateProfile(profile)

    suspend fun deleteProfile(profile: DriverProfile) = dao.deleteProfile(profile)

    suspend fun setActiveProfile(id: Long) {
        dao.clearDefaultFlags()
        dao.setDefaultProfile(id)
    }
}
