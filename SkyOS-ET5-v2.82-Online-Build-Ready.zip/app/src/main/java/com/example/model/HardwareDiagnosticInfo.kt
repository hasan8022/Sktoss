package com.example.model

/**
 * Inspection details of the host device (Skywell ET5 IVI unit, tablet or phone).
 */
data class HardwareDiagnosticInfo(
    val androidVersion: String = "",
    val sdkInt: Int = 0,
    val manufacturer: String = "",
    val model: String = "",
    val brand: String = "",
    val board: String = "",
    val hardware: String = "",
    val displayBuildId: String = "",
    val isAdbEnabled: Boolean = false,
    val isGmsAvailable: Boolean = false,
    val gmsStatusDetail: String = "",
    val isGoogleMapsAppInstalled: Boolean = false,
    val isSpotifyAppInstalled: Boolean = false,
    val isYouTubeAppInstalled: Boolean = false,
    val webViewPackage: String = "",
    val webViewVersion: String = "",
    val usbDevices: List<String> = emptyList(),
    val bluetoothBondedDevices: List<BluetoothDeviceInfo> = emptyList(),
    val isBluetoothAvailable: Boolean = false,
    val networkType: String = "",
    val isInternetConnected: Boolean = false,
    val internalBatteryLevel: Int = -1,
    val batteryTemperatureCelsius: Float? = null,
    val isDeviceCharging: Boolean = false,
    val isCarApiAvailable: Boolean = false
)

data class BluetoothDeviceInfo(
    val name: String,
    val address: String,
    val isLikelyObd: Boolean
)
