package com.example.ui.components

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.LocalEt5Colors
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GoogleMapsPane(
    latitude: Double,
    longitude: Double,
    isInternetConnected: Boolean,
    onVoiceSearch: () -> Unit,
    onOpenGAppsHub: (() -> Unit)? = null,
    homeAddress: String = "",
    workAddress: String = "",
    bearing: Float = 0f,
    speedKmh: Float = 0f,
    showRearCameraOverlay: Boolean = false,
    onCloseRearCamera: (() -> Unit)? = null,
    onLaunchOem360Camera: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val colors = LocalEt5Colors.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var networkError by remember { mutableStateOf<String?>(null) }
    var currentTime by remember { mutableStateOf("11:05") }
    // Default to embedded SkyOS Leaflet MapLite so cockpit looks clean without browser UI chrome
    var isMapLiteActive by remember { mutableStateOf(true) }

    // Interactive Search & Turn-by-Turn Navigation States
    var isSearchExpanded by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var activeNavDestination by remember { mutableStateOf<String?>(null) }
    var destLat by remember { mutableStateOf<Double?>(null) }
    var destLng by remember { mutableStateOf<Double?>(null) }
    var isCameraFullScreen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            currentTime = sdf.format(Date())
            delay(1000)
        }
    }

    val baseMapUrl = remember(latitude, longitude) {
        if (latitude != 0.0 && longitude != 0.0) {
            "https://www.google.com/maps/@$latitude,$longitude,16z"
        } else {
            "https://www.google.com/maps"
        }
    }

    fun startNavigationTo(label: String, targetLat: Double? = null, targetLng: Double? = null) {
        activeNavDestination = label
        isSearchExpanded = false
        val baseLat = if (latitude != 0.0) latitude else 41.01
        val baseLng = if (longitude != 0.0) longitude else 28.97
        destLat = targetLat ?: (baseLat + 0.012)
        destLng = targetLng ?: (baseLng + 0.015)
        if (!isMapLiteActive) {
            val encoded = Uri.encode(label)
            webViewRef?.loadUrl("https://www.google.com/maps/dir/?api=1&destination=$encoded")
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.mapBg)
            .testTag("google_maps_pane")
    ) {
        if (isMapLiteActive) {
            MapLiteView(
                latitude = latitude,
                longitude = longitude,
                bearing = bearing,
                speedKmh = speedKmh,
                isNavigationActive = activeNavDestination != null,
                destinationLat = destLat,
                destinationLng = destLng,
                modifier = Modifier.fillMaxSize()
            )
        } else if (!isInternetConnected && networkError != null) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(32.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.WifiOff, contentDescription = null, tint = colors.red, modifier = Modifier.size(42.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Harita Bağlantısı Kurulamadı", color = colors.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "İnternet bağlantınızı kontrol edip tekrar deneyin veya SkyOS Hafif Harita'ya geçin.",
                        color = colors.text2,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { isMapLiteActive = true },
                            colors = ButtonDefaults.buttonColors(containerColor = colors.blue),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("SkyOS Haritayı Aç", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                networkError = null
                                webViewRef?.loadUrl(baseMapUrl)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = colors.cool),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Yeniden Yükle", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        val cookieManager = CookieManager.getInstance()
                        cookieManager.setAcceptCookie(true)
                        cookieManager.setAcceptThirdPartyCookies(this, true)

                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            setGeolocationEnabled(true)
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            mediaPlaybackRequiresUserGesture = false
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onGeolocationPermissionsShowPrompt(
                                origin: String?,
                                callback: GeolocationPermissions.Callback?
                            ) {
                                callback?.invoke(origin, true, false)
                            }
                        }

                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                super.onPageStarted(view, url, favicon)
                                isLoading = true
                                networkError = null
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                isLoading = false
                            }

                            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                                handler?.proceed()
                            }

                            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                                super.onReceivedError(view, request, error)
                                if (request?.isForMainFrame == true) {
                                    isLoading = false
                                    networkError = error?.description?.toString() ?: "Ağ hatası"
                                }
                            }
                        }

                        loadUrl(baseMapUrl)
                        webViewRef = this
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Top Search Bar, Voice Button, Ev/İş Shortcuts & Clock Header (matching reference photos)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 14.dp, top = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Floating Search Pill: [🔍 Nereye?] + [🎙]
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(22.dp))
                        .background(colors.glass)
                        .border(1.dp, colors.stroke, RoundedCornerShape(22.dp))
                        .clickable { isSearchExpanded = !isSearchExpanded }
                        .padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = colors.text2,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = activeNavDestination ?: "Nereye?",
                        color = colors.text,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(24.dp))

                    // Blue circle microphone button
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(colors.blue)
                            .clickable { onVoiceSearch() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Sesli Arama",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }

                // [🏠 Ev] Shortcut Pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(colors.glass)
                        .border(1.dp, colors.stroke, RoundedCornerShape(18.dp))
                        .clickable {
                            val target = homeAddress.ifBlank { "Ev" }
                            startNavigationTo(target)
                        }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = "Ev",
                        tint = colors.text2,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Ev",
                        color = colors.text,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // [💼 İş] Shortcut Pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(colors.glass)
                        .border(1.dp, colors.stroke, RoundedCornerShape(18.dp))
                        .clickable {
                            val target = workAddress.ifBlank { "İş Yeri" }
                            startNavigationTo(target)
                        }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Business,
                        contentDescription = "İş",
                        tint = colors.text2,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "İş",
                        color = colors.text,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Right side: Map Engine Switcher + Clock Pill ("11:05")
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(colors.glass)
                        .border(1.dp, colors.stroke, RoundedCornerShape(14.dp))
                        .clickable { isMapLiteActive = !isMapLiteActive }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Map,
                            contentDescription = null,
                            tint = colors.blue,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isMapLiteActive) "SkyOS Harita" else "Google Web",
                            color = colors.text,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(colors.glass)
                        .border(1.dp, colors.stroke, RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = currentTime,
                        color = colors.text,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Expanded Destination Search Panel
        AnimatedVisibility(
            visible = isSearchExpanded,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 14.dp, top = 56.dp)
                .width(380.dp)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                modifier = Modifier.border(1.dp, colors.stroke, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Adres, cadde veya şarj istasyonu ara...", fontSize = 12.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = colors.text,
                                unfocusedTextColor = colors.text,
                                focusedBorderColor = colors.blue,
                                unfocusedBorderColor = colors.stroke
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                if (searchQuery.isNotBlank()) {
                                    startNavigationTo(searchQuery.trim())
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = colors.blue),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Rota", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Quick POI chips
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf(
                            "⚡ DC Hızlı Şarj" to "En Yakın DC Hızlı Şarj İstasyonu",
                            "🅿 Otopark" to "En Yakın Otopark",
                            "🏥 Hastane" to "En Yakın Hastane"
                        ).forEach { (chipLabel, queryTarget) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(colors.surface2)
                                    .clickable { startNavigationTo(queryTarget) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(chipLabel, color = colors.text, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }

        // Turn-by-Turn Active Route Banner (matching runtime_160s.jpg: "100 m ... Rota")
        activeNavDestination?.let { destName ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 14.dp, top = if (isSearchExpanded) 190.dp else 56.dp)
                    .border(1.dp, colors.stroke, RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(colors.blue),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Navigation,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "100 m • $destName yönüne ilerleyin",
                            color = colors.text,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Canlı GPS rotası aktif • Şarj planlayıcı devrede",
                            color = colors.text2,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(
                        onClick = {
                            activeNavDestination = null
                            destLat = null
                            destLng = null
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Rotayı İptal Et", tint = colors.text2, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // Rear Camera / 360 EVS Overlay (LfH;->c & LfH;->h in classes.dex: "Arka kamera", "Küçült", "Tam ekran", "Kapat")
        if (showRearCameraOverlay) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0B0E14)),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(14.dp)
                    .then(
                        if (isCameraFullScreen) Modifier.fillMaxSize()
                        else Modifier.width(420.dp).height(250.dp)
                    )
                    .border(1.5.dp, colors.blue, RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Camera Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF141820))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Videocam, contentDescription = null, tint = colors.green, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Arka Kamera & 360° Çevre Görüş (EVS)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (onLaunchOem360Camera != null) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(colors.blue)
                                        .clickable { onLaunchOem360Camera() }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("OEM 360° Aç", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0x33FFFFFF))
                                    .clickable { isCameraFullScreen = !isCameraFullScreen }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (isCameraFullScreen) "Küçült" else "Tam ekran",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(colors.red.copy(alpha = 0.8f))
                                    .clickable { onCloseRearCamera?.invoke() }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("Kapat", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Camera Feed / Parking Trajectory Area
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Videocam, contentDescription = null, tint = colors.text2, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Kamera 0 — Araç AVIN / EVS video girişi bekleniyor",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Skywell ET5 üzerinde com.skyworth.car.evs veya donanım kamera akışı bağlandığında canlı görüntü burada gösterilir.",
                                color = Color(0xFF9B9EA4),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Bottom right map attribution matching photo
        Text(
            text = "Harita ©Google · © OpenStreetMap katkıcıları",
            color = colors.text2,
            fontSize = 9.sp,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 12.dp, bottom = 6.dp)
        )

        if (isLoading) {
            CircularProgressIndicator(
                color = colors.blue,
                strokeWidth = 2.dp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(32.dp)
            )
        }
    }
}
