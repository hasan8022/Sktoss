# Android Studio'da devam etme — Türkçe

1. ZIP'i bilgisayara çıkar. Android Studio'da **Open** seçip ZIP'ten çıkan `SkyOS-ET5-Master-Recovered` klasörünü aç. ZIP dosyasını doğrudan açma.
2. Android Studio'nun JDK/Gradle indirmelerine izin ver. Proje `gradle-wrapper.properties` içinde Gradle 9.3.1 ve Version Catalog'da AGP 9.1.1 hattını tanımlar; Android Studio önerdiği uyumlu JDK/SDK bileşenlerini kurmalı.
3. Bu teslimde `gradlew` ve `gradle-wrapper.jar` bulunmayabilir. Android Studio wrapper'ı oluşturamıyorsa terminalde sistem Gradle kurulu olmalı; ardından proje kökünde `gradle wrapper --gradle-version 9.3.1` çalıştırılabilir. Komut bulunamazsa Gradle'ı Android Studio'nun yönergeleriyle kur.
4. Android Studio Gemini panelini aç. `GEMINI_ANDROID_STUDIO_PROMPT_TR.md` dosyasının tamamını Gemini'ye gönder. Önce APK ve kaynak kodu analiz etmesini, sonra doğrudan proje dosyalarını değiştirmesini ve test/build yapmasını iste.
5. `google-services.json`, `.env`, API anahtarı, Spotify OAuth, YouTube Data API, Map tile key ve release signing keystore gibi dosyalar yoksa sahte dosya/anahtar üretme. Gerekli entegrasyonları opsiyonel tut.
6. İlk derleme için **Build > Make Project**; ardından **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Hataları Gemini'ye tam Gradle çıktısıyla ver.
7. Önce emülatörde test et. Araç kontrolünü ancak hedef 2023 Skywell ET5 ve head-unit firmware üzerinde, üretici API/izinleri doğrulandıktan sonra test et.

## Şu anki dürüst durum

- Orijinal APK'nin 297 ZIP girdisi çıkarıldı ve byte karşılaştırmasıyla doğrulandı.
- APK'nin özgün 24 asset'i ayrı referans kopyası olarak korundu.
- `classes.dex`, `resources.arsc` ve binary manifest saklandı; bunlar henüz Kotlin/XML kaynak koduna tam dönüştürülmüş değil.
- Bu paket için bu çalışma ortamında Android APK build/test yapılmadı.

Ek: `VIDEO_AND_SCREEN_REFERENCE_ANALYSIS_TR.md` dosyasını ve `video_reference/` klasöründeki örnek kareleri Gemini'ye mutlaka incelet. Bu materyaller gerçek araç ekranı ve kurulum/lisans akışının tasarım referansıdır.
