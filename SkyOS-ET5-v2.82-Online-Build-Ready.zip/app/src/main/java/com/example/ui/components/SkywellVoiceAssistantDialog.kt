package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.AirlineSeatReclineExtra
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.service.voice.CarVoiceAssistant
import com.example.service.voice.VoiceState
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyDeepCockpit
import com.example.ui.theme.SkyElectricBlue
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyNavy
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SkywellVoiceAssistantDialog(
    voiceAssistant: CarVoiceAssistant,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val voiceState by voiceAssistant.voiceState.collectAsState()
    val spokenText by voiceAssistant.lastSpokenText.collectAsState()
    val assistantResponse by voiceAssistant.assistantResponse.collectAsState()

    // Smooth Infinite Animations for the Automotive AI Assistant Orb
    val infiniteTransition = rememberInfiniteTransition(label = "AssistantOrbPulse")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbRotation"
    )

    val scalePulse by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (voiceState == VoiceState.LISTENING) 1.15f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (voiceState == VoiceState.LISTENING) 600 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OrbScalePulse"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = Color(0xEE080F1D),
            shape = RoundedCornerShape(24.dp),
            modifier = modifier
                .fillMaxWidth(0.92f)
                .padding(16.dp)
                .border(1.dp, SkyCyan.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                .testTag("skywell_voice_assistant_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Bar with Title and Close Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(
                                    when (voiceState) {
                                        VoiceState.LISTENING -> SkyGreen
                                        VoiceState.PROCESSING -> SkyAmber
                                        VoiceState.SPEAKING -> SkyCyan
                                        else -> SkyElectricBlue
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SkyOS Akıllı Sesli Asistan",
                            color = SkyTextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat", tint = SkyTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // The Central Animated AI Assistant Orb
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .scale(scalePulse),
                    contentAlignment = Alignment.Center
                ) {
                    // Outer Pulsing Glow Ring
                    Box(
                        modifier = Modifier
                            .size(108.dp)
                            .clip(CircleShape)
                            .rotate(rotation)
                            .background(
                                Brush.sweepGradient(
                                    listOf(
                                        Color(0xFF00E5FF),
                                        Color(0xFF2979FF),
                                        Color(0xFFFF4081),
                                        Color(0xFFFFD600),
                                        Color(0xFF00E5FF)
                                    )
                                )
                            )
                    )

                    // Inner Dark Core with Interactive Mic
                    Box(
                        modifier = Modifier
                            .size(92.dp)
                            .clip(CircleShape)
                            .background(SkyDeepCockpit)
                            .clickable {
                                if (voiceState == VoiceState.LISTENING) {
                                    voiceAssistant.stopListening()
                                } else {
                                    voiceAssistant.startListening()
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (voiceState == VoiceState.LISTENING) Icons.Default.Mic else Icons.Default.Mic,
                            contentDescription = "Dinle",
                            tint = when (voiceState) {
                                VoiceState.LISTENING -> SkyGreen
                                VoiceState.SPEAKING -> SkyCyan
                                else -> SkyCyan
                            },
                            modifier = Modifier.size(42.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Status Banner / Dialogue
                Text(
                    text = when (voiceState) {
                        VoiceState.LISTENING -> "Sizi Dinliyorum... Konuşun"
                        VoiceState.PROCESSING -> "Komut İşleniyor..."
                        VoiceState.SPEAKING -> "Yanıt Veriliyor..."
                        VoiceState.ERROR -> "Mikrofon / Bağlantı Uyarısı"
                        VoiceState.IDLE -> "Mikrofona Dokunun veya Aşağıdan Seçin"
                    },
                    color = when (voiceState) {
                        VoiceState.LISTENING -> SkyGreen
                        VoiceState.PROCESSING -> SkyAmber
                        else -> SkyCyan
                    },
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Spoken Text or Assistant Response
                Text(
                    text = if (spokenText.isNotBlank()) "\"$spokenText\"" else assistantResponse,
                    color = SkyTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Quick Action Chips (Automotive Voice Shortcuts for Hands-Free Driving)
                Text(
                    text = "Sık Kullanılan Araç Komutları (Tek Dokunuş)",
                    color = SkyTextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AssistantChip(
                        icon = Icons.Default.AcUnit,
                        label = "Klimayı 22°C Yap",
                        onClick = { voiceAssistant.executeTextCommand("Klimayı 22 derece yap") }
                    )
                    AssistantChip(
                        icon = Icons.Default.Home,
                        label = "Eve Git",
                        onClick = { voiceAssistant.executeTextCommand("Eve git") }
                    )
                    AssistantChip(
                        icon = Icons.Default.EvStation,
                        label = "En Yakın Şarj",
                        onClick = { voiceAssistant.executeTextCommand("En yakın şarj istasyonunu bul") }
                    )
                    AssistantChip(
                        icon = Icons.Default.AirlineSeatReclineExtra,
                        label = "Koltuk Isıtma",
                        onClick = { voiceAssistant.executeTextCommand("Koltuk ısıtmayı aç") }
                    )
                    AssistantChip(
                        icon = Icons.Default.DirectionsCar,
                        label = "Bagajı Aç",
                        onClick = { voiceAssistant.executeTextCommand("Bagajı aç") }
                    )
                    AssistantChip(
                        icon = Icons.Default.Lightbulb,
                        label = "Farları Aç",
                        onClick = { voiceAssistant.executeTextCommand("Farları aç") }
                    )
                    AssistantChip(
                        icon = Icons.Default.Radio,
                        label = "Kral Türk FM",
                        onClick = { voiceAssistant.executeTextCommand("Kral Türk FM aç") }
                    )
                    AssistantChip(
                        icon = Icons.Default.MusicNote,
                        label = "Spotify Aç",
                        onClick = { voiceAssistant.executeTextCommand("Spotify aç") }
                    )
                    AssistantChip(
                        icon = Icons.Default.Videocam,
                        label = "YouTube Aç",
                        onClick = { voiceAssistant.executeTextCommand("YouTube aç") }
                    )
                    AssistantChip(
                        icon = Icons.Default.WbSunny,
                        label = "Kamp Modu",
                        onClick = { voiceAssistant.executeTextCommand("Kamp modu aç") }
                    )
                    AssistantChip(
                        icon = Icons.Default.Pets,
                        label = "Evcil Hayvan Modu",
                        onClick = { voiceAssistant.executeTextCommand("Evcil hayvan modunu aç") }
                    )
                }
            }
        }
    }
}

@Composable
private fun AssistantChip(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF132034))
            .border(1.dp, SkyCyan.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = SkyCyan,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            color = SkyTextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
