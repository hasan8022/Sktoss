package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CarRental
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OBDConnectionStatus
import com.example.service.voice.VoiceState
import com.example.ui.AutomotiveScreen
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCard
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyNavy
import com.example.ui.theme.SkyRed
import com.example.ui.theme.SkySurface
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AutomotiveTopBar(
    activeProfileName: String,
    effectiveSpeedKmh: Float,
    obdStatus: OBDConnectionStatus,
    isInternetConnected: Boolean,
    voiceState: VoiceState,
    voicePrompt: String,
    onVoiceClick: () -> Unit
) {
    var currentTime by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            currentTime = formatter.format(Date())
            delay(1000)
        }
    }

    Surface(
        color = SkyNavy,
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .testTag("automotive_top_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand & Clock
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "SKYOS",
                    color = SkyCyan,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .background(SkyCyan.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "ET5",
                        color = SkyCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = currentTime,
                    color = SkyTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Voice Assistant Prompter (center)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(SkyCard)
                    .clickable { onVoiceClick() }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                val micColor = when (voiceState) {
                    VoiceState.LISTENING -> SkyCyan
                    VoiceState.PROCESSING -> SkyAmber
                    VoiceState.SPEAKING -> SkyGreen
                    VoiceState.ERROR -> SkyRed
                    VoiceState.IDLE -> SkyTextSecondary
                }
                Icon(
                    imageVector = if (voiceState == VoiceState.ERROR) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Sesli Asistan",
                    tint = micColor,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = voicePrompt.take(40),
                    color = if (voiceState == VoiceState.LISTENING) SkyCyan else SkyTextSecondary,
                    fontSize = 13.sp,
                    fontWeight = if (voiceState == VoiceState.LISTENING) FontWeight.Bold else FontWeight.Normal
                )
            }

            // System Status Indicators
            Row(verticalAlignment = Alignment.CenterVertically) {
                // OBD Status Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(
                            color = when (obdStatus) {
                                OBDConnectionStatus.CONNECTED -> SkyGreen.copy(alpha = 0.15f)
                                OBDConnectionStatus.CONNECTING, OBDConnectionStatus.SCANNING -> SkyAmber.copy(alpha = 0.15f)
                                else -> SkyTextMuted.copy(alpha = 0.15f)
                            },
                            shape = RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(
                                color = when (obdStatus) {
                                    OBDConnectionStatus.CONNECTED -> SkyGreen
                                    OBDConnectionStatus.CONNECTING, OBDConnectionStatus.SCANNING -> SkyAmber
                                    else -> SkyRed
                                },
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = when (obdStatus) {
                            OBDConnectionStatus.CONNECTED -> "OBD: CAN 500k"
                            OBDConnectionStatus.CONNECTING -> "OBD: Bağlanıyor"
                            OBDConnectionStatus.SCANNING -> "OBD: Taranıyor"
                            OBDConnectionStatus.ERROR -> "OBD: Hata"
                            OBDConnectionStatus.DISCONNECTED -> "OBD: Bağlı Değil"
                            else -> "OBD: Bağlı Değil"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = when (obdStatus) {
                            OBDConnectionStatus.CONNECTED -> SkyGreen
                            OBDConnectionStatus.CONNECTING, OBDConnectionStatus.SCANNING -> SkyAmber
                            else -> SkyTextSecondary
                        }
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Network
                Icon(
                    imageVector = if (isInternetConnected) Icons.Default.Wifi else Icons.Default.WifiOff,
                    contentDescription = "Ağ Durumu",
                    tint = if (isInternetConnected) SkyCyan else SkyTextMuted,
                    modifier = Modifier.size(18.dp)
                )

                Spacer(modifier = Modifier.width(12.dp))

                // Active Driver Avatar
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(SkyCyan.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Sürücü",
                            tint = SkyCyan,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = activeProfileName,
                        color = SkyTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun AutomotiveBottomBar(
    currentScreen: AutomotiveScreen,
    onNavigate: (AutomotiveScreen) -> Unit
) {
    Surface(
        color = SkySurface,
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .testTag("automotive_bottom_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            DockItem(
                title = "Ana Ekran",
                icon = Icons.Default.Dashboard,
                isSelected = currentScreen == AutomotiveScreen.DASHBOARD,
                onClick = { onNavigate(AutomotiveScreen.DASHBOARD) }
            )
            DockItem(
                title = "Harita",
                icon = Icons.Default.Navigation,
                isSelected = currentScreen == AutomotiveScreen.NAVIGATION,
                onClick = { onNavigate(AutomotiveScreen.NAVIGATION) }
            )
            DockItem(
                title = "Medya",
                icon = Icons.Default.MusicNote,
                isSelected = currentScreen == AutomotiveScreen.MEDIA,
                onClick = { onNavigate(AutomotiveScreen.MEDIA) }
            )
            DockItem(
                title = "Kontroller",
                icon = Icons.Default.DirectionsCar,
                isSelected = currentScreen == AutomotiveScreen.VEHICLE_CONTROLS,
                onClick = { onNavigate(AutomotiveScreen.VEHICLE_CONTROLS) }
            )
            DockItem(
                title = "OBD & Teşhis",
                icon = Icons.Default.Power,
                isSelected = currentScreen == AutomotiveScreen.OBD_DIAGNOSTICS,
                onClick = { onNavigate(AutomotiveScreen.OBD_DIAGNOSTICS) }
            )
            DockItem(
                title = "Sürücüler",
                icon = Icons.Default.Person,
                isSelected = currentScreen == AutomotiveScreen.DRIVER_PROFILES,
                onClick = { onNavigate(AutomotiveScreen.DRIVER_PROFILES) }
            )
            DockItem(
                title = "Sistem",
                icon = Icons.Default.Settings,
                isSelected = currentScreen == AutomotiveScreen.SYSTEM_DIAGNOSTICS,
                onClick = { onNavigate(AutomotiveScreen.SYSTEM_DIAGNOSTICS) }
            )
        }
    }
}

@Composable
private fun DockItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val activeColor = SkyCyan
    val inactiveColor = SkyTextSecondary

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) SkyCyan.copy(alpha = 0.12f) else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("dock_item_${title.lowercase(Locale.ROOT)}")
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isSelected) activeColor else inactiveColor,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = title,
            color = if (isSelected) activeColor else inactiveColor,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
