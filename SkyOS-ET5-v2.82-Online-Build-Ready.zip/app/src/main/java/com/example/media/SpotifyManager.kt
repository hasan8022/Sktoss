package com.example.media

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri

/** Launch/search helper for the official Spotify client. Not an account or playback SDK. */
class SpotifyManager(private val context: Context) {
    companion object {
        const val SPOTIFY_PACKAGE = "com.spotify.music"
        const val SPOTIFY_WEB_URL = "https://open.spotify.com"
    }

    fun isSpotifyInstalled(): Boolean = try {
        context.packageManager.getPackageInfo(SPOTIFY_PACKAGE, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    fun createOpenSpotifyIntent(): Intent {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(SPOTIFY_PACKAGE)
        return launchIntent ?: Intent(Intent.ACTION_VIEW, Uri.parse(SPOTIFY_WEB_URL)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun createSearchIntent(query: String): Intent {
        val uri = if (isSpotifyInstalled()) {
            Uri.parse("spotify:search:${Uri.encode(query)}")
        } else {
            Uri.parse("https://open.spotify.com/search/${Uri.encode(query)}")
        }
        return Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
    }

    fun getOAuthInstructions(): String =
        "Bu yardımcı yalnızca resmi Spotify uygulamasını/web oynatıcısını açar. SkyOS içinde hesap kitaplığı ve oynatma kontrolü henüz OAuth/App Remote ile entegre değildir."
}
