# SkyOS ET5 APK Recovery Report

## Scope
This package combines the previously prepared Android Studio project with recoverable resources from the supplied SkyOS 2.82 APK. The original APK is retained byte-for-byte under `recovery_reference/SkyOS-2.82-original.apk`. Its DEX, binary manifest, native libraries and assets are retained under `recovery_reference/apk_payload/`.

## Critical limitation
An APK is a compiled application package, not the original Android Studio project. It does not normally contain Kotlin source, Gradle source configuration, original comments, complete module structure, or signing private keys. `classes.dex` contains compiled bytecode. This recovery package does **not** claim to have reconstructed the original source code or its complete build process. A decompiler (such as JADX) and further manual analysis are needed to recover readable approximate code. Even decompiled output is not the original source.

## Confirmed package evidence from DEX strings
- App namespace/class descriptors found: `tr.halil.et5` (including `Et5App`, `MainActivity`, `BootReceiver`, `PanelGuardService`, `RadioService`, `HomeGate`, `Et5InCallService`, `PairingReceiver`, and related classes).
- Vehicle-system package references include `com.skyworth.car.*`.
- HVAC provider reference: `com.coolwell.ai.skyhvac` and `content://com.coolwell.ai.skyhvac.database/airconditioner`.
- Vehicle-control capability labels present: `CONTROL_CAR_CLIMATE`, `CONTROL_CAR_DOORS`, `CONTROL_CAR_EXTERIOR_LIGHTS`, `CONTROL_CAR_MIRRORS`, `CONTROL_CAR_SEATS`, `CONTROL_CAR_WINDOWS`.
- Spotify App Remote-related strings and classes are present.
- YouTube Music package references include official and alternative package identifiers; this alone does not establish a working embedded YouTube video player.
- MapLibre Android references and native library are present.
- OBD/vLinker MS strings and pin references are present.
- Radio Browser API endpoint strings and `tr.halil.et5.radio.RadioService` are present.
- `assets/arac.bin` and `assets/arac.ver` are preserved. The binary format/key/meaning have not been decoded or validated.

## Important distinction
The supplied owner statement says the installed APK works fully. This report records that as the user's operational assertion, not as an independently reproduced test. Static APK inspection can establish that implementation traces exist; it cannot prove that a specific vehicle, head unit, account, permission set, or adapter is currently functioning.

## Recovery contents
- `app/src/main/assets/recovered_original/`: exact assets extracted from APK, copied into the Android project as reference assets (not assumed to be wired into app code).
- `recovery_reference/SkyOS-2.82-original.apk`: untouched original APK.
- `recovery_reference/apk_payload/`: DEX, binary manifest, assets and native libraries for further reverse engineering.
- `APK_EVIDENCE.json`: keyword evidence extracted from DEX strings.

## Safe next reverse-engineering steps
1. Decode `AndroidManifest.xml` and inspect permissions, exported components, services, receivers and provider declarations.
2. Decompile `classes.dex` to approximate Java/Kotlin and map call sites around vehicle services, HVAC content provider, Spotify App Remote, OBD and radio.
3. Compare the recovered calls with the target ET5 head unit's installed packages, granted permissions and Android build.
4. Start with read-only vehicle telemetry and log actual values. Only implement write controls when the OEM service contract, property IDs, value types, permissions and safety conditions are confirmed.
5. Rebuild and test on the actual target head unit. Never infer CAN frames or property IDs from names alone.

## SHA-256
- Original APK: `83e97b2b9e6fcc1d826e9385d1fdc8520995156204e8268c860c701cc9fae6f4`
- classes.dex: `7dd4baaf02f031a00785b841c0bbc1e4d4aa23fea99b0c6cb130c9207a9b1d8b`

## User-provided target vehicle
The user states the target vehicle is a 2023 Skywell ET5 and reports that the supplied SkyOS 2.82 APK is fully functional on their setup. This is recorded as user-provided context; the exact IVI firmware/build and installed OEM packages still need confirmation from the promotional/installation video or device diagnostics.
