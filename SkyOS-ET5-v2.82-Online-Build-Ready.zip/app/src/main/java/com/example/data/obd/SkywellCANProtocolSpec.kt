package com.example.data.obd

/**
 * Skywell ET5 Protocol & Property Registry.
 * Combines:
 * 1. Exact Android CarPropertyManager property IDs recovered by disassembling LMg0; and LHf;
 *    from SkyOS 2.82 classes.dex.
 * 2. Published 2023 Skywell ET5 EV powertrain specifications and standard SAE J1979 OBD-II PIDs.
 */
object SkywellCANProtocolSpec {
    const val VEHICLE_NAME = "Skywell ET5 (EV)"
    const val PLATFORM_NAME = "Coocaa OS / Skyworth IVI + Android CarPropertyManager + AracYardimci:8724"

    // Published 2023 Skywell ET5 72 kWh nominal powertrain constants (used in LDg; energy calculations)
    const val PACK_SERIES_CONFIG = "103S (103 Seri Hücre)"
    const val PACK_CAPACITY_KWH = 72.0f
    const val NOMINAL_PACK_VOLTAGE = 381.1f
    const val MAX_PACK_VOLTAGE = 432.6f
    const val MOTOR_POWER_KW = 150.0f
    const val MOTOR_TORQUE_NM = 320.0f

    val STANDARD_PIDS = listOf(
        "0100" to "Desteklenen PID bitmask sorgusu (ECU yanıtı doğrulanmalı)",
        "010C" to "Motor devri — genel SAE PID; EV güç aktarma sisteminde destek garanti edilmez",
        "010D" to "Araç hızı — genel SAE PID; araç ECU desteği doğrulanmalıdır",
        "0105" to "Motor soğutma suyu sıcaklığı — BMS veya kabin sıcaklığı değildir",
        "0142" to "Kontrol modülü besleme gerilimi — yüksek voltaj batarya paketi gerilimi değildir",
        "03" to "Emisyon ECU arıza kodlarını oku; EV üretici teşhisi yerine geçmez",
        "04" to "Emisyon ECU arıza kodlarını sil; araç üreticisi prosedürü olmadan kullanılmamalıdır"
    )

    /**
     * Exact CarPropertyManager Property IDs extracted from SkyOS 2.82 classes.dex (LMg0; & LHf;).
     */
    val RECOVERED_CAR_PROPERTY_IDS = listOf(
        "0x11400400 (area 0)" to "Vites Durumu (P / R / N / D)",
        "0x11600207 (area 2)" to "Araç Hızı (km/sa)",
        "0x11600333 (area 0)" to "Yüksek Voltaj Batarya SOC (%)",
        "0x1160049e (area 0)" to "Kalan Menzil (km)",
        "0x1160031b (area 0)" to "Anlık Güç Tüketimi / Geri Kazanım (kW)",
        "0x11400317 (area 0)" to "Şarj Durumu (AC / DC / Kablo Takılı)",
        "0x11400330 (area 0)" to "Şarj Tamamlanmasına Kalan Süre (dk)",
        "0x11600319 (area 0)" to "AC/DC Şarj Hedef Sınırı (%)",
        "0x11600470 (area 5)" to "Dış Ortam Sıcaklığı (°C)",
        "0x11600517 / 0x11600518" to "Kabin İç Sıcaklığı (°C)",
        "0x15600503 (area 1/4)" to "Klima Hedef Sıcaklığı (18.0°C - 32.0°C)",
        "0x15400500 (area 0)" to "Klima Fan Kademesi (1 - 7)",
        "0x15200510 / 0x15200505" to "Klima Güç (Power) ve A/C Kompresör Durumu",
        "0x13200504 (area 0/1/2)" to "Ön Cam Buğu Çözücü ve Arka Cam Rezistansı",
        "0x15400b9c / 0x15400b9b" to "Sürücü ve Yolcu Koltuk Isıtma / Soğutma",
        "0x11400d2d (16/64/256/1024)" to "Sol Ön / Sağ Ön / Sol Arka / Sağ Arka Kapı Açıklık Durumu",
        "0x11400551 / 0x11400562" to "Elektrikli Bagaj ve Ön Kaput Durumu",
        "0x16400b06 / 0x16400b05" to "Panoramik Cam Tavan ve Güneşlik Perdesi",
        "0x11610449 / 44a / 44b" to "Ön / Arka / Yan Park Radar Mesafe Dizileri (m)",
        "0x11610497 (area 0)" to "TPMS Lastik Basınçları (4 Tekerlek)",
        "0x11400408 / 0x11400e03 / e05" to "Sinyaller, Dörtlüler, Kısa/Uzun/Sis Farları ve Fren Lambası",
        "0x1160049a / 0x1160049b" to "Toplam Kilometre (Odometer) ve Ortalama Tüketim (kWh/100km)"
    )

    val CAN_BUS_CHANNELS: List<Pair<String, String>> = listOf(
        "CarPropertyManager" to "android.car.Car üzerinden VCU/BCM özellik okuma ve yazma (LMg0;)",
        "AracYardimci (127.0.0.1:8724)" to "arac.bin içinden çözülen yerel sistem köprüsü (AUTH / WATCH / SET)",
        "SkyHVAC ContentProvider" to "content://com.coolwell.ai.skyhvac.database/airconditioner",
        "vLinker MS / ELM327 SPP" to "Bluetooth RFCOMM (00001101-0000-1000-8000-00805F9B34FB) & Wi-Fi (192.168.0.10:35000)"
    )

    val OBD_PINS: List<Pair<String, String>> = listOf(
        "Pin 4 & 5" to "Şasi ve Sinyal Topraklaması (GND)",
        "Pin 6 & 14" to "ISO 15765-4 CAN High (Pin 6) / CAN Low (Pin 14) - 500 kbps",
        "Pin 16" to "+12V Sürekli Akü Beslemesi"
    )

    const val OEM_INTEGRATION_NOTICE = """
    SkyOS 2.82 (yapı 193) APK'sından çözümlenen 0x11400400..0x21400620 CarPropertyManager
    özellik kimlikleri ve content://com.coolwell.ai.skyhvac.database/airconditioner sağlayıcısı
    sisteme entegre edilmiştir. Araç üzerinde CarService veya AracYardimci (127.0.0.1:8724)
    aktif olduğunda gerçek araç verileri okunur; bağlantı yokken hiçbir sahte değer üretilmez.
    """
}
