package com.example.media

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class RadioStation(
    val id: String,
    val name: String,
    val subtitle: String = "TR - İnternet Radyosu",
    val streamUrl: String,
    val logoText: String = "Radyo7",
    val category: String = "Pop & Karma",
    val badgeColorHex: Long = 0xFFD32F2F,
    val isFavorite: Boolean = false
) {
    val genre: String get() = category
}

enum class PlaybackState {
    IDLE,
    BUFFERING,
    PLAYING,
    PAUSED,
    ERROR
}

class RadioMediaPlayer(
    private val context: Context,
    private val coordinator: CarMediaCoordinator? = null
) {

    companion object {
        val PRESET_STATIONS = listOf(
            RadioStation(
                id = "kral_turk_fm",
                name = "KRAL TÜRK FM",
                subtitle = "TR - İnternet Radyosu",
                streamUrl = "https://kral-radyo.medyainternet.com/kral/kralfm/playlist.m3u8",
                logoText = "Radyo7",
                category = "Türkçe Pop & Klasik",
                badgeColorHex = 0xFFD32F2F,
                isFavorite = true
            ),
            RadioStation(
                id = "trt_fm",
                name = "TRT FM",
                subtitle = "TR - İnternet Radyosu",
                streamUrl = "https://trt-radyo.medyainternet.com/trt/trtfm/playlist.m3u8",
                logoText = "TRT",
                category = "Pop & Yol Durumu",
                badgeColorHex = 0xFF1976D2,
                isFavorite = true
            ),
            RadioStation(
                id = "trt_radyo1",
                name = "TRT RADYO 1",
                subtitle = "TR - İnternet Radyosu",
                streamUrl = "https://trt-radyo.medyainternet.com/trt/trtradyo1/playlist.m3u8",
                logoText = "TRT1",
                category = "Haber & Kültür",
                badgeColorHex = 0xFF0D47A1,
                isFavorite = false
            ),
            RadioStation(
                id = "power_fm",
                name = "POWER FM",
                subtitle = "TR - İnternet Radyosu",
                streamUrl = "https://powerfm.listenpowerapp.com/powerfm/mpeg/icecast.audio",
                logoText = "PWR",
                category = "Yabancı Hit & Dans",
                badgeColorHex = 0xFFE65100,
                isFavorite = false
            ),
            RadioStation(
                id = "super_fm",
                name = "SÜPER FM",
                subtitle = "TR - İnternet Radyosu",
                streamUrl = "https://playerservices.streamtheworld.com/api/livestream-redirect/SUPER_FM.mp3",
                logoText = "SPR",
                category = "Türkçe Hit Pop",
                badgeColorHex = 0xFFC2185B,
                isFavorite = false
            )
        )
    }

    private var mediaPlayer: MediaPlayer? = null
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val _stations = MutableStateFlow(PRESET_STATIONS)
    val stations: StateFlow<List<RadioStation>> = _stations.asStateFlow()

    private val _currentStation = MutableStateFlow(PRESET_STATIONS[0])
    val currentStation: StateFlow<RadioStation> = _currentStation.asStateFlow()

    private val _playbackState = MutableStateFlow(PlaybackState.IDLE)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _volume = MutableStateFlow(0.75f)
    val volume: StateFlow<Float> = _volume.asStateFlow()

    fun setVolume(vol: Float) {
        _volume.value = vol.coerceIn(0f, 1f)
        val targetDelta = ((vol - 0.5f) * 10).toInt()
        coordinator?.adjustVolume(targetDelta)
    }

    fun playStation(station: RadioStation) {
        _currentStation.value = station
        _errorMessage.value = null
        _playbackState.value = PlaybackState.BUFFERING

        coordinator?.updateNowPlaying(
            title = station.name,
            subtitle = station.subtitle,
            badgeText = station.logoText,
            badgeColorHex = station.badgeColorHex,
            source = MediaSource.RADIO,
            isPlaying = true
        )

        releasePlayer()

        try {
            requestAudioFocus()

            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(station.streamUrl)

                setOnPreparedListener { mp ->
                    mp.start()
                    _playbackState.value = PlaybackState.PLAYING
                    coordinator?.setPlaybackState(true)
                }

                setOnErrorListener { _, what, extra ->
                    _playbackState.value = PlaybackState.ERROR
                    _errorMessage.value = "Yayın akışı geçici olarak alınamadı ($what/$extra)"
                    coordinator?.setPlaybackState(false)
                    false
                }

                setOnCompletionListener {
                    _playbackState.value = PlaybackState.IDLE
                    coordinator?.setPlaybackState(false)
                }

                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            _playbackState.value = PlaybackState.ERROR
            _errorMessage.value = "Radyo başlatılamadı: ${e.localizedMessage}"
            coordinator?.setPlaybackState(false)
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer ?: run {
            playStation(_currentStation.value)
            return
        }

        if (player.isPlaying) {
            player.pause()
            _playbackState.value = PlaybackState.PAUSED
            coordinator?.setPlaybackState(false)
        } else {
            player.start()
            _playbackState.value = PlaybackState.PLAYING
            coordinator?.setPlaybackState(true)
        }
    }

    fun nextStation() {
        val currentList = _stations.value
        val currentIndex = currentList.indexOfFirst { it.id == _currentStation.value.id }
        val nextIndex = (currentIndex + 1) % currentList.size
        playStation(currentList[nextIndex])
    }

    fun previousStation() {
        val currentList = _stations.value
        val currentIndex = currentList.indexOfFirst { it.id == _currentStation.value.id }
        val prevIndex = if (currentIndex <= 0) currentList.size - 1 else currentIndex - 1
        playStation(currentList[prevIndex])
    }

    fun toggleFavorite(stationId: String) {
        val updated = _stations.value.map { st ->
            if (st.id == stationId) st.copy(isFavorite = !st.isFavorite) else st
        }
        _stations.value = updated
        if (_currentStation.value.id == stationId) {
            _currentStation.value = _currentStation.value.copy(isFavorite = !_currentStation.value.isFavorite)
        }
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener { focusChange ->
                    when (focusChange) {
                        AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> mediaPlayer?.pause()
                        AudioManager.AUDIOFOCUS_GAIN -> mediaPlayer?.start()
                        AudioManager.AUDIOFOCUS_LOSS -> releasePlayer()
                    }
                }
                .build()
            am.requestAudioFocus(focusRequest)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                { focusChange ->
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS) releasePlayer()
                },
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }
    }

    fun releasePlayer() {
        mediaPlayer?.let { player ->
            try {
                if (player.isPlaying) {
                    player.stop()
                }
                player.release()
            } catch (_: Exception) {}
        }
        mediaPlayer = null
    }
}
