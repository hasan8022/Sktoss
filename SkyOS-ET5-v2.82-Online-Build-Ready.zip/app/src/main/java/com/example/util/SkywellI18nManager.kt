package com.example.util

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.io.InputStream
import java.nio.charset.StandardCharsets

object SkywellI18nManager {
    private const val TAG = "SkywellI18nManager"
    private val translations = mutableMapOf<String, Map<String, String>>()
    private var currentLanguage = "tr" // Turkish is primary

    val supportedLanguages = listOf(
        "tr" to "Türkçe (Orijinal)",
        "en" to "English",
        "de" to "Deutsch",
        "es" to "Español",
        "ru" to "Русский"
    )

    fun initialize(context: Context, initialLanguage: String = "tr") {
        currentLanguage = initialLanguage
        if (initialLanguage != "tr") {
            loadLanguage(context, initialLanguage)
        }
    }

    fun setLanguage(context: Context, lang: String) {
        currentLanguage = lang
        if (lang != "tr" && !translations.containsKey(lang)) {
            loadLanguage(context, lang)
        }
    }

    fun getCurrentLanguage(): String = currentLanguage

    private fun loadLanguage(context: Context, lang: String) {
        try {
            val fileName = "i18n/$lang.json"
            context.assets.open(fileName).use { stream: InputStream ->
                val jsonStr = stream.readBytes().toString(StandardCharsets.UTF_8)
                val json = JSONObject(jsonStr)
                val map = mutableMapOf<String, String>()
                val keys = json.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    map[k] = json.optString(k, k)
                }
                translations[lang] = map
                Log.i(TAG, "Yüklendi: $lang (${map.size} çeviri anahtarı)")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Çeviri yüklenemedi $lang: ${e.message}")
        }
    }

    fun t(key: String, vararg args: Any): String {
        if (currentLanguage == "tr") {
            return formatString(key, args)
        }
        val langMap = translations[currentLanguage]
        val translated = langMap?.get(key) ?: key
        return formatString(translated, args)
    }

    private fun formatString(template: String, args: Array<out Any>): String {
        if (args.isEmpty()) return template
        var result = template
        args.forEachIndexed { index, arg ->
            result = result.replace("{$index}", arg.toString())
        }
        return result
    }
}
