package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Surface
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.obd.LogDirection
import com.example.model.OBDConnectionStatus
import com.example.data.obd.SkywellCANProtocolSpec
import com.example.model.DtcCode
import com.example.model.DtcSeverity
import com.example.ui.SkyOsViewModel
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCard
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyDivider
import com.example.ui.theme.SkyElectricBlue
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyNavy
import com.example.ui.theme.SkyRed
import com.example.ui.theme.SkySurface
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary

@Composable
fun ObdDiagnosticsScreen(
    viewModel: SkyOsViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val obdStatus by viewModel.obdStatus.collectAsState()
    val statusMessage by viewModel.obdStatusMessage.collectAsState()
    val telemetry by viewModel.obdTelemetry.collectAsState()
    val terminalLogs by viewModel.obdLogs.collectAsState()
    val hardwareInfo by viewModel.hardwareInfo.collectAsState()

    var showClearDtcDialog by remember { mutableStateOf(false) }
    var clearDtcResult by remember { mutableStateOf<String?>(null) }
    var isQueryingDtc by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SkyNavy)
            .testTag("obd_diagnostics_screen")
    ) {
        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = SkySurface,
            contentColor = SkyCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = SkyCyan
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Bağlantı & Canlı Veri", fontWeight = FontWeight.SemiBold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Arıza Kodları (DTC)", fontWeight = FontWeight.SemiBold) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Terminal & CAN Günlüğü", fontWeight = FontWeight.SemiBold) }
            )
            Tab(
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 },
                text = { Text("Skywell ET5 CAN Protokolü", fontWeight = FontWeight.SemiBold) }
            )
        }

        // Top Status Header
        Surface(
            color = SkyCard,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                color = when (obdStatus) {
                                    OBDConnectionStatus.CONNECTED -> SkyGreen
                                    OBDConnectionStatus.CONNECTING, OBDConnectionStatus.SCANNING -> SkyAmber
                                    else -> SkyRed
                                },
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = statusMessage,
                        color = SkyTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (obdStatus == OBDConnectionStatus.CONNECTED || obdStatus == OBDConnectionStatus.CONNECTING) {
                    OutlinedButton(
                        onClick = { viewModel.disconnectObd() },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SkyRed)
                    ) {
                        Text("Bağlantıyı Kes", fontSize = 11.sp)
                    }
                }
            }
        }

        when (selectedTab) {
            0 -> ObdConnectionAndLiveTab(viewModel, obdStatus, telemetry, hardwareInfo)
            1 -> ObdDtcTab(
                dtcList = telemetry.activeDtcCodes,
                isConnected = obdStatus == OBDConnectionStatus.CONNECTED,
                isQuerying = isQueryingDtc,
                onQueryDtc = {
                    isQueryingDtc = true
                    viewModel.queryDtcCodes {
                        isQueryingDtc = false
                    }
                },
                onRequestClearDtc = { showClearDtcDialog = true },
                clearResult = clearDtcResult
            )
            2 -> ObdTerminalLogTab(terminalLogs)
            3 -> SkywellSpecTab()
        }

        // Two-Factor Confirmation Dialog for Mode 04 Clear DTC (Mandatory Safety Rule)
        if (showClearDtcDialog) {
            AlertDialog(
                onDismissRequest = { showClearDtcDialog = false },
                containerColor = SkyCard,
                icon = {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = SkyAmber, modifier = Modifier.size(36.dp))
                },
                title = {
                    Text("Arıza Kodlarını Sıfırla (Mode 04)", color = SkyTextPrimary, fontWeight = FontWeight.Bold)
                },
                text = {
                    Text(
                        text = "DİKKAT: Arıza kodlarını sıfırlamak ECU ve BMS hata kayıtlarını ve donmuş kare (Freeze Frame) verilerini siler.\n\nBu işlem yalnızca yetkili servis teknisyeni gözetiminde veya arıza fiziksel olarak giderildikten sonra yapılmalıdır. Devam etmek istiyor musunuz?",
                        color = SkyTextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showClearDtcDialog = false
                            viewModel.clearDtcCodes { success ->
                                clearDtcResult = if (success) "Mode 04: Arıza kodları başarıyla silindi." else "Arıza kodları silinemedi (ECU reddetti)."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SkyRed)
                    ) {
                        Text("Onayla ve Sil", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showClearDtcDialog = false }) {
                        Text("İptal", color = SkyCyan)
                    }
                }
            )
        }
    }
}

@Composable
private fun ObdConnectionAndLiveTab(
    viewModel: SkyOsViewModel,
    obdStatus: OBDConnectionStatus,
    telemetry: com.example.model.VehicleTelemetry,
    hardwareInfo: com.example.model.HardwareDiagnosticInfo
) {
    var wifiIp by remember { mutableStateOf("192.168.0.10") }
    var wifiPort by remember { mutableStateOf("35000") }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Connection Manager (Bluetooth Paired List & Wi-Fi Input)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Text(
                    text = "OBD-II Adaptör Seçimi",
                    color = SkyTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Bluetooth Paired Devices
                Text("Eşleşmiş Bluetooth Cihazları:", color = SkyTextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))

                if (hardwareInfo.bluetoothBondedDevices.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SkyNavy, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "Eşleşmiş Bluetooth cihazı bulunamadı.\n(OBD adaptörünü önce Android Bluetooth ayarlarından eşleştirin)",
                            color = SkyTextMuted,
                            fontSize = 11.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(hardwareInfo.bluetoothBondedDevices) { device ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (device.isLikelyObd) SkyCyan.copy(alpha = 0.12f) else SkyNavy)
                                    .clickable { viewModel.connectObdBluetooth(device.address) }
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Bluetooth,
                                        contentDescription = null,
                                        tint = if (device.isLikelyObd) SkyCyan else SkyTextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(device.name, color = SkyTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                        Text(device.address, color = SkyTextMuted, fontSize = 10.sp)
                                    }
                                }

                                Button(
                                    onClick = { viewModel.connectObdBluetooth(device.address) },
                                    shape = RoundedCornerShape(6.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = SkyCyan),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("Bağlan", color = Color(0xFF041E26), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Wi-Fi Socket Connection Alternative
                Text("Wi-Fi ELM327 Doğrudan TCP Soketi:", color = SkyTextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = wifiIp,
                        onValueChange = { wifiIp = it },
                        label = { Text("IP Adresi", fontSize = 10.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = SkyNavy,
                            unfocusedContainerColor = SkyNavy,
                            focusedTextColor = SkyTextPrimary,
                            unfocusedTextColor = SkyTextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1.5f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    OutlinedTextField(
                        value = wifiPort,
                        onValueChange = { wifiPort = it },
                        label = { Text("Port", fontSize = 10.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = SkyNavy,
                            unfocusedContainerColor = SkyNavy,
                            focusedTextColor = SkyTextPrimary,
                            unfocusedTextColor = SkyTextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            val portInt = wifiPort.toIntOrNull() ?: 35000
                            viewModel.connectObdWifi(wifiIp, portInt)
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SkyCyan)
                    ) {
                        Text("Wi-Fi", color = Color(0xFF041E26), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Right Column: Live Real Telemetry Values
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Canlı OBD-II Sensör Verileri (SAE J1979 Mode 01)",
                    color = SkyTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                if (obdStatus != OBDConnectionStatus.CONNECTED) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(SkyNavy, RoundedCornerShape(12.dp))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Power, contentDescription = null, tint = SkyAmber, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "OBD-II Adaptörü Bağlı Değil",
                                color = SkyTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Kural Gereği Sahte Değer Üretilmez.\nSol panelden eşleşmiş bir Bluetooth ELM327 veya Wi-Fi soketi seçerek bağlanın.",
                                color = SkyTextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                        }
                    }
                } else {
                    // Live Sensor Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        LiveSensorCard("ARAÇ HIZI", telemetry.obdSpeedKmh?.let { "$it km/s" } ?: "--", "010D", Modifier.weight(1f))
                        LiveSensorCard("MOTOR DEVRİ (ECU DESTEKLERSE)", telemetry.engineRpm?.toString() ?: "--", "010C", Modifier.weight(1f))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        LiveSensorCard("MOTOR SOĞUTMA SIVISI", telemetry.coolantTempCelsius?.let { "$it °C" } ?: "--", "0105", Modifier.weight(1f))
                        LiveSensorCard("ECU KONTROL VOLTAJI", telemetry.controlModuleVoltage?.let { "${"%.2f".format(it)} V" } ?: "--", "0142", Modifier.weight(1f))
                    }

                    // Supported PIDs Mask
                    telemetry.supportedPidsMask?.let { mask ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = SkyNavy),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Desteklenen PID Bitmask (0100):", color = SkyTextMuted, fontSize = 10.sp)
                                Text(mask, color = SkyCyan, fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveSensorCard(title: String, value: String, pid: String, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SkyNavy),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = title, color = SkyTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                Text(text = "PID: $pid", color = SkyCyan.copy(alpha = 0.7f), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
            Text(text = value, color = SkyCyan, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ObdDtcTab(
    dtcList: List<DtcCode>,
    isConnected: Boolean,
    isQuerying: Boolean,
    onQueryDtc: () -> Unit,
    onRequestClearDtc: () -> Unit,
    clearResult: String?
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Actions Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Arıza Teşhis Kodları (DTC - Mode 03)",
                    color = SkyTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isConnected) "Araç ECU/VCU hata belleği okunabilir." else "Hata kodlarını okumak için OBD bağlı olmalıdır.",
                    color = SkyTextSecondary,
                    fontSize = 12.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onQueryDtc,
                    enabled = isConnected && !isQuerying,
                    colors = ButtonDefaults.buttonColors(containerColor = SkyCyan),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    if (isQuerying) {
                        CircularProgressIndicator(color = Color(0xFF041E26), modifier = Modifier.size(16.dp))
                    } else {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF041E26), modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Kodları Oku", color = Color(0xFF041E26), fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onRequestClearDtc,
                    enabled = isConnected,
                    colors = ButtonDefaults.buttonColors(containerColor = SkyRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Sıfırla (Mode 04)")
                }
            }
        }

        clearResult?.let { res ->
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = SkyCard),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = res, color = SkyGreen, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
            }
        }

        // DTC List
        if (dtcList.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(SkyCard, RoundedCornerShape(16.dp))
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SkyGreen, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Aktif Arıza Kodu Bulunmadı (P0000)", color = SkyTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Güç aktarım, gövde, şasi ve ağ protokollerinde kayıtlı hata kodu yok.", color = SkyTextSecondary, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(dtcList) { dtc ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SkyCard),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(dtc.code, color = SkyRed, fontSize = 18.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(SkyRed.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(dtc.category, color = SkyRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(dtc.description, color = SkyTextPrimary, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ObdTerminalLogTab(logs: List<com.example.data.obd.ObdLogEntry>) {
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF03070E)),
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "ELM327 Doğrudan AT / CAN Terminal Günlüğü (Ham Veri)",
                color = SkyCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (logs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Bağlantı kurulduğunda gönderilen/alınan ham komutlar burada akar.", color = SkyTextMuted, fontSize = 12.sp)
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(logs) { entry ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "[${entry.timestamp}]",
                                color = SkyTextMuted,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when (entry.direction) {
                                    LogDirection.TX -> "TX -> "
                                    LogDirection.RX -> "RX <- "
                                    LogDirection.SYS -> "SYS :: "
                                },
                                color = when (entry.direction) {
                                    LogDirection.TX -> SkyElectricBlue
                                    LogDirection.RX -> SkyGreen
                                    LogDirection.SYS -> SkyAmber
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = entry.message,
                                color = if (entry.direction == LogDirection.RX) Color.White else SkyTextPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SkywellSpecTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(androidx.compose.foundation.rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Skywell ET5 Donanım & CAN Bus Mimarisi", color = SkyCyan, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Bu teknik kılavuz, Skywell ET5'in batarya paketi, OBD-II portu pin bağlantısı ve üretici CAN haberleşme protokollerini açıklar.",
                    color = SkyTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("2023 Skywell ET5 Batarya & Güç Aktarma Özeti", color = SkyTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                SpecRow("Araç Modeli", SkywellCANProtocolSpec.VEHICLE_NAME)
                SpecRow("Hücre Dizilimi", SkywellCANProtocolSpec.PACK_SERIES_CONFIG)
                SpecRow("Batarya Kapasitesi", "${SkywellCANProtocolSpec.PACK_CAPACITY_KWH} kWh")
                SpecRow("Nominal / Maks Gerilim", "${SkywellCANProtocolSpec.NOMINAL_PACK_VOLTAGE} V / ${SkywellCANProtocolSpec.MAX_PACK_VOLTAGE} V")
                SpecRow("Motor Gücü / Tork", "${SkywellCANProtocolSpec.MOTOR_POWER_KW.toInt()} kW / ${SkywellCANProtocolSpec.MOTOR_TORQUE_NM.toInt()} Nm")
            }
        }

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("DEX'ten Kurtarılan OEM CarPropertyManager Kimlikleri (LMg0; / LDE;)", color = SkyCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                SkywellCANProtocolSpec.RECOVERED_CAR_PROPERTY_IDS.forEach { prop ->
                    SpecRow("${prop.name} (${prop.propertyIdHex})", prop.description)
                }
            }
        }

        // Manufacturer OEM Skylink Architecture Notice
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = SkyAmber, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("OEM Skylink Android Başlık Ünitesi Entegrasyon Kılavuzu", color = SkyAmber, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = SkywellCANProtocolSpec.OEM_INTEGRATION_NOTICE.trimIndent(),
                    color = SkyTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
private fun SpecRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = SkyTextSecondary, fontSize = 12.sp)
        Text(text = value, color = SkyCyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
