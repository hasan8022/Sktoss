package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.AirlineSeatReclineExtra
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalEt5Colors

enum class ActiveDockTab {
    MAPS,
    MEDIA,
    BATTERY,
    PHONE,
    CAMERA,
    APPS,
    VOICE
}

@Composable
fun AutomotiveBottomHvacDock(
    driverTempC: Float,
    fanLevel: Int,
    driverSeatHeatingLevel: Int,
    passengerSeatHeatingLevel: Int,
    volumeLevel: Int,
    activeTab: ActiveDockTab,
    onDriverTempChange: (Float) -> Unit,
    onFanLevelChange: () -> Unit,
    onDriverSeatHeatingChange: () -> Unit,
    onPassengerSeatHeatingChange: () -> Unit,
    onVolumeChange: (Int) -> Unit,
    onSelectDockTab: (ActiveDockTab) -> Unit,
    onCarSettingsClick: () -> Unit,
    onVoiceAssistantClick: () -> Unit,
    frontDefrostOn: Boolean = false,
    rearDefrostOn: Boolean = false,
    escEnabled: Boolean = true,
    isMuted: Boolean = false,
    onToggleFrontDefrost: (() -> Unit)? = null,
    onToggleRearDefrost: (() -> Unit)? = null,
    onToggleEsc: (() -> Unit)? = null,
    onToggleMute: (() -> Unit)? = null,
    onRecoveryClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val colors = LocalEt5Colors.current

    Surface(
        color = colors.surface,
        modifier = modifier
            .fillMaxWidth()
            .height(66.dp)
            .border(width = 1.dp, color = colors.stroke)
            .testTag("automotive_bottom_hvac_dock")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left Group: Car Settings + Driver Temp (< 22,0° >) + Fan (2) + Driver Seat
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // 1. Car / Settings Icon
                IconButton(
                    onClick = onCarSettingsClick,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(colors.surface2)
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsCar,
                        contentDescription = "Araç Ayarları",
                        tint = colors.text,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // 2. Driver Temperature Stepper: < 22,0° > (blue cool left, red heat right)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(colors.surface2)
                        .padding(horizontal = 2.dp, vertical = 2.dp)
                ) {
                    IconButton(
                        onClick = { onDriverTempChange(-0.5f) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronLeft,
                            contentDescription = "Soğut",
                            tint = colors.cool,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = "${"%.1f".format(driverTempC).replace('.', ',')}°",
                        color = colors.text,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 2.dp)
                    )
                    IconButton(
                        onClick = { onDriverTempChange(0.5f) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Isıt",
                            tint = colors.heat,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // 3. Fan Level: 🌀 2
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(colors.surface2)
                        .clickable { onFanLevelChange() }
                        .padding(horizontal = 8.dp, vertical = 7.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Air,
                        contentDescription = "Fan",
                        tint = colors.blue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$fanLevel",
                        color = colors.text,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // 4. Driver Seat Heating / Ventilation
                IconButton(
                    onClick = onDriverSeatHeatingChange,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (driverSeatHeatingLevel > 0) colors.heat.copy(alpha = 0.2f)
                            else colors.surface2
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.AirlineSeatReclineExtra,
                        contentDescription = "Sürücü Koltuk Isıtma",
                        tint = if (driverSeatHeatingLevel > 0) colors.heat else colors.text2,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Center Group: SkyOS 2.82 Fixed Dock Icons (matching runtime_000s.jpg & reference photos)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 5. App Grid (88)
                DockIcon(
                    icon = Icons.Default.Apps,
                    label = "Uygulamalar",
                    isSelected = activeTab == ActiveDockTab.APPS,
                    onClick = { onSelectDockTab(ActiveDockTab.APPS) }
                )

                // 6. Colorful AI Voice Assistant Orb
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                listOf(
                                    Color(0xFF00E5FF),
                                    Color(0xFF3E6AE1),
                                    Color(0xFFFF4081),
                                    Color(0xFFFFB020),
                                    Color(0xFF00E5FF)
                                )
                            )
                        )
                        .clickable { onVoiceAssistantClick() }
                        .padding(3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(colors.surface),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF3A8BFF), Color(0xFFFF4081))
                                    )
                                )
                        )
                    }
                }

                // 7. Front Windshield Defrost
                if (onToggleFrontDefrost != null) {
                    DockIcon(
                        icon = Icons.Default.WbSunny,
                        label = "Ön Buğu Çözücü",
                        isSelected = frontDefrostOn,
                        onClick = onToggleFrontDefrost
                    )
                }

                // 8. Rear Window Defrost
                if (onToggleRearDefrost != null) {
                    DockIcon(
                        icon = Icons.Default.AcUnit,
                        label = "Arka Cam Rezistansı",
                        isSelected = rearDefrostOn,
                        onClick = onToggleRearDefrost
                    )
                }

                // 9. Phone
                DockIcon(
                    icon = Icons.Default.Phone,
                    label = "Telefon",
                    isSelected = activeTab == ActiveDockTab.PHONE,
                    onClick = { onSelectDockTab(ActiveDockTab.PHONE) }
                )

                // 10. Music / Media Hub
                DockIcon(
                    icon = Icons.Default.MusicNote,
                    label = "Medya",
                    isSelected = activeTab == ActiveDockTab.MEDIA,
                    onClick = { onSelectDockTab(ActiveDockTab.MEDIA) }
                )

                // 11. Camera / Rear View
                DockIcon(
                    icon = Icons.Default.Videocam,
                    label = "Kamera",
                    isSelected = activeTab == ActiveDockTab.CAMERA,
                    onClick = { onSelectDockTab(ActiveDockTab.CAMERA) }
                )

                // 12. Map / Navigation
                DockIcon(
                    icon = Icons.Default.Explore,
                    label = "Harita",
                    isSelected = activeTab == ActiveDockTab.MAPS,
                    onClick = { onSelectDockTab(ActiveDockTab.MAPS) }
                )

                // 13. OBD / Cluster / Energy
                DockIcon(
                    icon = Icons.Default.Speed,
                    label = "OBD & Enerji",
                    isSelected = activeTab == ActiveDockTab.BATTERY,
                    onClick = { onSelectDockTab(ActiveDockTab.BATTERY) }
                )

                // 14. Recovery / Original System
                if (onRecoveryClick != null) {
                    DockIcon(
                        icon = Icons.Default.Refresh,
                        label = "Kurtarma",
                        isSelected = false,
                        onClick = onRecoveryClick
                    )
                }

                // 15. ESC Quick Badge (matching reference_dashboard_dark.jpg)
                if (onToggleEsc != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (escEnabled) colors.surface2 else colors.amber.copy(alpha = 0.25f))
                            .clickable { onToggleEsc() }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (escEnabled) "ESC" else "ESC OFF",
                            color = if (escEnabled) colors.text2 else colors.amber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Right Group: Passenger Seat Heating & Master Volume Stepper (< 🔊 5 >)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Passenger Seat Heating
                IconButton(
                    onClick = onPassengerSeatHeatingChange,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (passengerSeatHeatingLevel > 0) colors.heat.copy(alpha = 0.2f)
                            else colors.surface2
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.AirlineSeatReclineExtra,
                        contentDescription = "Yolcu Koltuk",
                        tint = if (passengerSeatHeatingLevel > 0) colors.heat else colors.text2,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Volume Stepper: < [Speaker] 5 >
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(colors.surface2)
                        .padding(horizontal = 2.dp, vertical = 2.dp)
                ) {
                    IconButton(
                        onClick = { onVolumeChange(-1) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronLeft,
                            contentDescription = "Kıs",
                            tint = colors.text2,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Icon(
                        imageVector = if (isMuted || volumeLevel == 0) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Ses",
                        tint = if (isMuted || volumeLevel == 0) colors.red else colors.blue,
                        modifier = Modifier
                            .size(16.dp)
                            .clickable { onToggleMute?.invoke() }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isMuted) "0" else "$volumeLevel",
                        color = colors.text,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 2.dp)
                    )
                    IconButton(
                        onClick = { onVolumeChange(1) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Aç",
                            tint = colors.text2,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DockIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = LocalEt5Colors.current
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) colors.blue.copy(alpha = 0.2f) else colors.surface2)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) colors.blue else colors.text,
            modifier = Modifier.size(19.dp)
        )
    }
}
