package com.skyos.rebuilt

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import java.util.Locale

class CarJsBridge(
    private val state: VehicleState,
    private val onUiSync: () -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    var webView: WebView? = null
    var isReady: Boolean = false
        private set

    @JavascriptInterface
    fun ready() {
        mainHandler.post {
            isReady = true
            syncAllToCar()
            onUiSync()
        }
    }

    @JavascriptInterface
    fun onPart(part: String?) {
        if (part.isNullOrBlank()) return
        mainHandler.post {
            when (part) {
                "dFL" -> {
                    state.doors[0] = !state.doors[0]
                    eval("window.CAR && window.CAR.door(0, ${state.doors[0]})")
                }
                "dFR" -> {
                    state.doors[1] = !state.doors[1]
                    eval("window.CAR && window.CAR.door(1, ${state.doors[1]})")
                }
                "dRL" -> {
                    state.doors[2] = !state.doors[2]
                    eval("window.CAR && window.CAR.door(2, ${state.doors[2]})")
                }
                "dRR" -> {
                    state.doors[3] = !state.doors[3]
                    eval("window.CAR && window.CAR.door(3, ${state.doors[3]})")
                }
                "hood" -> {
                    state.hoodOpen = !state.hoodOpen
                    eval("window.CAR && window.CAR.hood(${state.hoodOpen})")
                }
                "trunk" -> {
                    state.trunkOpen = !state.trunkOpen
                    eval("window.CAR && window.CAR.trunk(${state.trunkOpen})")
                }
                "charge" -> {
                    state.chargePortOpen = !state.chargePortOpen
                    eval("window.CAR && window.CAR.charge(${state.chargePortOpen})")
                }
            }
            onUiSync()
        }
    }

    @JavascriptInterface
    fun onLabel(side: String?, x: Double, y: Double, dist: Double) {
        mainHandler.post {
            if (side == "front") {
                state.frontMinLabelDist = if (x < 0 || dist <= 0) -1f else dist.toFloat()
            } else if (side == "rear") {
                state.rearMinLabelDist = if (x < 0 || dist <= 0) -1f else dist.toFloat()
            }
            onUiSync()
        }
    }

    fun eval(js: String) {
        val wv = webView ?: return
        mainHandler.post {
            wv.evaluateJavascript(js, null)
        }
    }

    fun syncAllToCar() {
        setColor(state.paintColorHex)
        setStopThreshold(state.stopThresholdM)
        for (i in 0..3) {
            setDoor(i, state.doors[i])
            setWindow(i, state.windows[i])
        }
        setHood(state.hoodOpen)
        setTrunk(state.trunkOpen)
        setChargePort(state.chargePortOpen)
        setSunroof(state.sunroofOpen)
        setSignals(state.leftSignal, state.rightSignal, state.hazardLights)
        setBrake(state.brakeLights)
        setCameraView(state.cameraView)
        syncParkSensors()
    }

    fun setColor(hex: String) {
        state.paintColorHex = hex
        eval("window.CAR && window.CAR.setColor('$hex')")
    }

    fun setStopThreshold(meters: Double) {
        state.stopThresholdM = meters
        eval(String.format(Locale.US, "window.CAR && window.CAR.setStop(%.2f)", meters))
    }

    fun setDoor(index: Int, open: Boolean) {
        if (index in 0..3) {
            state.doors[index] = open
            eval("window.CAR && window.CAR.door($index, $open)")
        }
    }

    fun setAllDoors(open: Boolean) {
        for (i in 0..3) {
            state.doors[i] = open
            eval("window.CAR && window.CAR.door($i, $open)")
        }
    }

    fun setWindow(index: Int, open: Boolean) {
        if (index in 0..3) {
            state.windows[index] = open
            eval("window.CAR && window.CAR.window($index, $open)")
        }
    }

    fun setAllWindows(open: Boolean) {
        for (i in 0..3) state.windows[i] = open
        eval("window.CAR && window.CAR.allWindows($open)")
    }

    fun setHood(open: Boolean) {
        state.hoodOpen = open
        eval("window.CAR && window.CAR.hood($open)")
    }

    fun setTrunk(open: Boolean) {
        state.trunkOpen = open
        eval("window.CAR && window.CAR.trunk($open)")
    }

    fun setChargePort(open: Boolean) {
        state.chargePortOpen = open
        eval("window.CAR && window.CAR.charge($open)")
    }

    fun setSunroof(open: Boolean) {
        state.sunroofOpen = open
        eval("window.CAR && window.CAR.sunroof($open)")
    }

    fun setSignals(left: Boolean, right: Boolean, hazard: Boolean) {
        state.leftSignal = left
        state.rightSignal = right
        state.hazardLights = hazard
        eval("window.CAR && window.CAR.signals($left, $right, $hazard)")
    }

    fun setBrake(active: Boolean) {
        state.brakeLights = active
        eval("window.CAR && window.CAR.brake($active)")
    }

    fun setCameraView(viewName: String) {
        state.cameraView = viewName
        eval("window.CAR && window.CAR.view('$viewName')")
    }

    fun syncParkSensors() {
        if (!state.parkSensorsActive) {
            eval("window.CAR && window.CAR.park(null, null, null)")
            state.frontMinLabelDist = -1f
            state.rearMinLabelDist = -1f
            return
        }
        val f = state.frontSensors.joinToString(",") { String.format(Locale.US, "%.2f", it) }
        val r = state.rearSensors.joinToString(",") { String.format(Locale.US, "%.2f", it) }
        val s = state.sideSensors.joinToString(",") { String.format(Locale.US, "%.2f", it) }
        eval("window.CAR && window.CAR.park([$f], [$r], [$s])")
    }
}

class MapJsBridge(
    private val state: VehicleState,
    private val onUiSync: () -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    var webView: WebView? = null
    var isReady: Boolean = false
        private set

    @JavascriptInterface
    fun ready() {
        mainHandler.post {
            isReady = true
            applyTileTheme(state.mapDarkTheme)
            updateFix(state.currentLat, state.currentLng, state.currentBearing, state.routeProgressFrac)
            loadRoutePreset(state.activeRouteIndex, fitBounds = false)
            onUiSync()
        }
    }

    @JavascriptInterface
    fun onUserMove() {
        mainHandler.post {
            state.mapFollow = false
            onUiSync()
        }
    }

    @JavascriptInterface
    fun prefetch(payloadJson: String?) {
        // Harita döşeme önbellekleme bildirimi
    }

    fun eval(js: String) {
        val wv = webView ?: return
        mainHandler.post {
            wv.evaluateJavascript(js, null)
        }
    }

    fun applyTileTheme(dark: Boolean) {
        state.mapDarkTheme = dark
        val url = if (dark) {
            "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        } else {
            "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        }
        val attr = "© OpenStreetMap, © CARTO"
        eval("window.LITE && window.LITE.setTiles('$url', '$attr', $dark)")
    }

    fun updateFix(lat: Double, lng: Double, bearing: Double, routeFrac: Double? = null) {
        state.currentLat = lat
        state.currentLng = lng
        state.currentBearing = bearing
        val fracArg = if (routeFrac != null && state.mapNavActive) {
            String.format(Locale.US, "%.4f", routeFrac)
        } else {
            "null"
        }
        val js = String.format(
            Locale.US,
            "window.LITE && window.LITE.setFix(%.6f, %.6f, %.1f, '#43D0BE', %s)",
            lat, lng, bearing, fracArg
        )
        eval(js)
    }

    fun setFollow(follow: Boolean, zoom: Int = 17) {
        state.mapFollow = follow
        eval("window.LITE && window.LITE.setFollow($follow, $zoom)")
    }

    fun loadRoutePreset(index: Int, fitBounds: Boolean = true) {
        if (index !in state.routes.indices) return
        state.activeRouteIndex = index
        val route = state.routes[index]
        val ptsArray = JSONArray()
        for ((lat, lng) in route.points) {
            val pt = JSONArray()
            pt.put(lat)
            pt.put(lng)
            ptsArray.put(pt)
        }
        val allRoutes = JSONArray()
        allRoutes.put(ptsArray)

        val endPt = route.points.last()
        eval("window.LITE && window.LITE.setRoutes($allRoutes, 0, $fitBounds)")
        eval(String.format(Locale.US, "window.LITE && window.LITE.setDest(%.6f, %.6f)", endPt.first, endPt.second))

        if (route.points.size >= 3) {
            val turnArrowPts = JSONArray()
            for (i in 1..minOf(3, route.points.size - 1)) {
                val p = JSONArray()
                p.put(route.points[i].first)
                p.put(route.points[i].second)
                turnArrowPts.put(p)
            }
            eval("window.LITE && window.LITE.setArrow($turnArrowPts)")
        }
    }

    fun setNavMode(enabled: Boolean, headUp3D: Boolean = state.mapHeadUp3D) {
        state.mapNavActive = enabled
        state.mapHeadUp3D = headUp3D
        if (enabled) {
            state.mapFollow = true
            loadRoutePreset(state.activeRouteIndex, fitBounds = false)
        }
        eval("window.LITE && window.LITE.setNav($enabled, $headUp3D)")
    }

    fun showPlace(lat: Double, lng: Double) {
        eval(String.format(Locale.US, "window.LITE && window.LITE.showPlace(%.6f, %.6f)", lat, lng))
    }

    fun resize() {
        eval("window.LITE && window.LITE.resize()")
    }
}
