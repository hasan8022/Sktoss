# SkyOS 2.82 — Kullanıcının Fotoğraf ve Video İncelemesi

Bu belge, kullanıcı tarafından bu konuşmada sağlanan iki fotoğraf ve iki videodan gözlemlenebilen arayüz/akış bilgilerini kaydeder. Video dosyaları:
- `108179.mp4` — 45,4 saniye, dikey 474×850, kurulum/ayar/lisans akışı görünen kayıt.
- `108187.mp4` — 400,8 saniye, dikey 576×1024, araç ekranında çalışan ana arayüzün kaydı.

## Fotoğraflarda görülen ana ekran

İki fotoğrafta da yatay, otomotiv ekranına uygun bölünmüş ana sayfa görülüyor:
- Sol sürüş paneli: P/R/N/D göstergesi, dış/iç sıcaklık, uyarı/bağlantı simgeleri, batarya göstergesi/menzil, büyük hız değeri ve ortada üstten ET5 araç görseli.
- Sol alt medya kartı: albüm/USB veya Spotify kaynağı, parça adı/sanatçı, önceki-oynat/sonraki kontrolleri ve ilerleme çubuğu.
- Sağ panel: harita, arama alanı (“Nereye?”), sesli arama mikrofonu ve konum işaretçisi.
- Alt sabit dock: araç/ana sayfa, sıcaklık ayarı ve okları, fan seviyesi, koltuk/iklim işlevi simgeleri, uygulama ızgarası, sesli asistan, cam buğu çözücü/arka cam rezistansı, telefon, müzik, video/kamera benzeri medya kısayolu, gösterge/performans simgesi, yenileme benzeri simge, artı ve ses seviyesi kontrolleri.
- İki görselde açık/koyu tema örneği mevcut. İlk görüntüde koyu tema ve 41 km/sa; ikinci fotoğrafta açık tema ve 16 km/sa, park uyarısı ve 375 km menzil görülüyor. Bunlar örnek ekran değerleridir; gerçek araç verisi olarak kodlanmamalıdır.

## 108179.mp4 — kurulum/ayar/lisans videosu

Zaman örneklemesi:
- 0–5 sn: ekranda sistem/uygulama yapılandırmasıyla ilgili bir pencere ve ardından sol tarafta kategorileri olan koyu ayarlar ekranı.
- 10 sn: ayarlar arayüzünde birden fazla bölüm ve durum/kontrol kartı.
- 15–20 sn: metin girişi gerektiren açılır pencere ve ekran klavyesi.
- 25 sn: ayarlar sayfasına geri dönüş.
- 30–40 sn: “Lisans” başlıklı ekran. Üstte uzun mavi bir işlem/başlatma çubuğu, ortada ET5 biçimli lisans/VIN benzeri metin alanı, durum satırları ve kırmızı uyarı/sonuç alanı görülüyor.

Not: Kayıtta lisans ekranı görünmesi lisans mekanizmasının nasıl çalıştığını veya sunucu uç noktalarını kanıtlamaz. VIN, lisans anahtarı ve doğrulama değerleri videodan tahmin edilmemeli; kullanıcının gerçek verisi olmadan örnek/sahte lisans üretilmemelidir.

## 108187.mp4 — araçta çalışan ana arayüz

Yaklaşık 6 dakika 41 saniyelik kayıt. Örnek karelerde:
- Ana ekran sürekli iki bölmeli: solda araç durumu/araç görseli ve medya; sağda harita.
- Sol panelde üstten araç görseli, durum/park etiketleri ve araçla ilgili durum satırları bulunuyor.
- Alt kısımda uygulama/iklim kısayol dock'u ve durum çubuğu görülüyor.
- Kayıt içinde koyu temalı harita/araç ekranı, harita görünümü değişiklikleri, kırmızı park/engel algılama görselleştirmesine benzeyen ekran, sesli asistan etkileşimi ve tekrar ana ekrana dönüş gözlemleniyor.
- Bazı karelerde vites/park durumu ve sürüş ekranı farklılaşıyor. Videodan gerçek CAN/OEM servis çağrıları, veri kaynağı veya kontrol protokolü belirlenemez.

## Uygulama yeniden oluşturma için gereksinimler

1. Ana ekranı yatay (landscape), araç ekranına uygun, iki panelli düzen olarak oluştur.
2. Sol sürüş panelini; vites, dış/iç sıcaklık, bağlantı/uyarı simgeleri, menzil/batarya, hız, ET5 üstten 3D/görseli ve medya kartı olarak böl.
3. Sağ paneli harita ve “Nereye?” araması, konum ve sesli arama öğeleriyle oluştur.
4. Alt dock'u sürekli görünür tut; iklim sıcaklığı/fan, koltuk/ısıtma, uygulama ızgarası, asistan, buğu çözücü, telefon, medya ve ses kontrollerini ayrı aksiyonlara bağla.
5. Açık/koyu tema desteği ekle; videolardaki örnekleri tasarım referansı olarak kullan.
6. Ayarlar sayfasında kategori listesi, ayar kartları ve metin girişi gerektiren dialog akışlarını yeniden oluştur.
7. Lisans ekranının görsel yapısını yeniden oluştur; gerçek doğrulama protokolü DEX/servis incelemesiyle bulunmadan sahte doğrulama yapma.
8. Sürüş sırasında video oynatma veya dikkat dağıtıcı etkileşimleri engelle.
9. Görünen araç değerleri örnek veridir; çalışma zamanında yalnızca gerçek kaynaktan gelen veriyi göster, yoksa “bağlı değil/veri yok” de.
10. Her UI eylemi çalışır olmalı; sahte düğmeler ve yalnızca görsel demo bırakma.

## Kanıt sınırı

Fotoğraf ve videolar arayüz düzeni, görünen etiketler ve kullanıcının kayıtta yaptığı işlemleri destekler. Ancak kaynak kod, OEM API isimleri, CAN mesajları, lisans algoritması, harita sağlayıcı ayarları veya gerçek sensörlerin kaynağını tek başına kanıtlamaz. Bu ayrıntılar APK DEX/manifest/asset incelemesi ve araç üzerinde kontrollü test gerektirir.
