package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color

private val AutomotiveDarkColorScheme = darkColorScheme(
    primary = DarkEt5Colors.blue,
    onPrimary = Color.White,
    primaryContainer = DarkEt5Colors.surface2,
    onPrimaryContainer = DarkEt5Colors.text,
    secondary = DarkEt5Colors.cool,
    onSecondary = Color.White,
    secondaryContainer = DarkEt5Colors.surface3,
    onSecondaryContainer = DarkEt5Colors.text,
    tertiary = DarkEt5Colors.amber,
    onTertiary = Color.Black,
    background = DarkEt5Colors.bg,
    onBackground = DarkEt5Colors.text,
    surface = DarkEt5Colors.surface,
    onSurface = DarkEt5Colors.text,
    surfaceVariant = DarkEt5Colors.surface2,
    onSurfaceVariant = DarkEt5Colors.text2,
    outline = DarkEt5Colors.stroke,
    outlineVariant = DarkEt5Colors.surface3,
    error = DarkEt5Colors.red,
    onError = Color.White
)

private val AutomotiveLightColorScheme = lightColorScheme(
    primary = LightEt5Colors.blue,
    onPrimary = Color.White,
    primaryContainer = LightEt5Colors.surface2,
    onPrimaryContainer = LightEt5Colors.text,
    secondary = LightEt5Colors.cool,
    onSecondary = Color.White,
    secondaryContainer = LightEt5Colors.surface3,
    onSecondaryContainer = LightEt5Colors.text,
    tertiary = LightEt5Colors.amber,
    onTertiary = Color.Black,
    background = LightEt5Colors.bg,
    onBackground = LightEt5Colors.text,
    surface = LightEt5Colors.surface,
    onSurface = LightEt5Colors.text,
    surfaceVariant = LightEt5Colors.surface2,
    onSurfaceVariant = LightEt5Colors.text2,
    outline = LightEt5Colors.stroke,
    outlineVariant = LightEt5Colors.surface3,
    error = LightEt5Colors.red,
    onError = Color.White
)

@Composable
fun SkyOsTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val et5Colors = if (darkTheme) DarkEt5Colors else LightEt5Colors
    val colorScheme = if (darkTheme) AutomotiveDarkColorScheme else AutomotiveLightColorScheme

    CompositionLocalProvider(LocalEt5Colors provides et5Colors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
