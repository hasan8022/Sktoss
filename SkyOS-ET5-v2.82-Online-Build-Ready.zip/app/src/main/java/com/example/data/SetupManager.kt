package com.example.data

import android.content.Context
import android.content.SharedPreferences

data class SetupConfiguration(
    val isCompleted: Boolean,
    val vehicleModel: String = "Skywell ET5 2023",
    val licensePlate: String,
    val licenseCode: String = "",
    val driverName: String,
    val homeAddress: String = "",
    val workAddress: String = "",
    val cabinTempCelsius: Float = 22.0f,
    val preferredRadioName: String = "Kral Türk FM",
    val obdMacAddress: String = "",
    val webhookUrl: String = "",
    val languageCode: String = "tr",
    val isDarkTheme: Boolean = true,
    val carColorHex: Int = 15330028, // #E9EAF0 Moon Silver
    val use3DCarView: Boolean = true,
    val blockVideoInMotion: Boolean = true
)

object SetupManager {

    private const val PREFS_NAME = "skyos_setup_preferences"
    private const val KEY_SETUP_COMPLETED = "is_setup_completed"
    private const val KEY_VEHICLE_MODEL = "vehicle_model"
    private const val KEY_LICENSE_PLATE = "license_plate"
    private const val KEY_LICENSE_CODE = "license_code"
    private const val KEY_DRIVER_NAME = "driver_name"
    private const val KEY_HOME_ADDRESS = "home_address"
    private const val KEY_WORK_ADDRESS = "work_address"
    private const val KEY_CABIN_TEMP = "cabin_temp"
    private const val KEY_PREFERRED_RADIO = "preferred_radio"
    private const val KEY_OBD_MAC = "obd_mac"
    private const val KEY_WEBHOOK_URL = "webhook_url"
    private const val KEY_LANG_CODE = "language_code"
    private const val KEY_DARK_THEME = "is_dark_theme"
    private const val KEY_CAR_COLOR = "car_color_hex"
    private const val KEY_USE_3D_CAR = "use_3d_car_view"
    private const val KEY_BLOCK_VIDEO = "surus_video_engelle"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun isSetupCompleted(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_SETUP_COMPLETED, false)
    }

    fun setSetupCompleted(context: Context, completed: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_SETUP_COMPLETED, completed).apply()
    }

    fun setDarkTheme(context: Context, isDark: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_DARK_THEME, isDark).apply()
    }

    fun setCarColorHex(context: Context, colorHex: Int) {
        getPrefs(context).edit().putInt(KEY_CAR_COLOR, colorHex).apply()
    }

    fun setUse3DCarView(context: Context, use3D: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_USE_3D_CAR, use3D).apply()
    }

    fun setBlockVideoInMotion(context: Context, block: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_BLOCK_VIDEO, block).apply()
    }

    fun saveConfiguration(
        context: Context,
        vehicleModel: String = "Skywell ET5 2023",
        licensePlate: String = "",
        licenseCode: String = "",
        driverName: String = "",
        homeAddress: String = "",
        workAddress: String = "",
        cabinTempCelsius: Float = 22.0f,
        preferredRadioName: String = "Kral Türk FM",
        obdMacAddress: String = "",
        webhookUrl: String = "",
        languageCode: String = "tr",
        isDarkTheme: Boolean = true,
        carColorHex: Int = 15330028,
        use3DCarView: Boolean = true,
        blockVideoInMotion: Boolean = true
    ) {
        getPrefs(context).edit()
            .putBoolean(KEY_SETUP_COMPLETED, true)
            .putString(KEY_VEHICLE_MODEL, vehicleModel)
            .putString(KEY_LICENSE_PLATE, licensePlate)
            .putString(KEY_LICENSE_CODE, licenseCode)
            .putString(KEY_DRIVER_NAME, driverName)
            .putString(KEY_HOME_ADDRESS, homeAddress)
            .putString(KEY_WORK_ADDRESS, workAddress)
            .putFloat(KEY_CABIN_TEMP, cabinTempCelsius)
            .putString(KEY_PREFERRED_RADIO, preferredRadioName)
            .putString(KEY_OBD_MAC, obdMacAddress)
            .putString(KEY_WEBHOOK_URL, webhookUrl)
            .putString(KEY_LANG_CODE, languageCode)
            .putBoolean(KEY_DARK_THEME, isDarkTheme)
            .putInt(KEY_CAR_COLOR, carColorHex)
            .putBoolean(KEY_USE_3D_CAR, use3DCarView)
            .putBoolean(KEY_BLOCK_VIDEO, blockVideoInMotion)
            .apply()
    }

    fun getConfiguration(context: Context): SetupConfiguration {
        val prefs = getPrefs(context)
        return SetupConfiguration(
            isCompleted = prefs.getBoolean(KEY_SETUP_COMPLETED, false),
            vehicleModel = prefs.getString(KEY_VEHICLE_MODEL, "Skywell ET5 2023") ?: "Skywell ET5 2023",
            licensePlate = prefs.getString(KEY_LICENSE_PLATE, "") ?: "",
            licenseCode = prefs.getString(KEY_LICENSE_CODE, "") ?: "",
            driverName = prefs.getString(KEY_DRIVER_NAME, "") ?: "",
            homeAddress = prefs.getString(KEY_HOME_ADDRESS, "") ?: "",
            workAddress = prefs.getString(KEY_WORK_ADDRESS, "") ?: "",
            cabinTempCelsius = prefs.getFloat(KEY_CABIN_TEMP, 22.0f),
            preferredRadioName = prefs.getString(KEY_PREFERRED_RADIO, "Kral Türk FM") ?: "Kral Türk FM",
            obdMacAddress = prefs.getString(KEY_OBD_MAC, "") ?: "",
            webhookUrl = prefs.getString(KEY_WEBHOOK_URL, "") ?: "",
            languageCode = prefs.getString(KEY_LANG_CODE, "tr") ?: "tr",
            isDarkTheme = prefs.getBoolean(KEY_DARK_THEME, true),
            carColorHex = prefs.getInt(KEY_CAR_COLOR, 15330028),
            use3DCarView = prefs.getBoolean(KEY_USE_3D_CAR, true),
            blockVideoInMotion = prefs.getBoolean(KEY_BLOCK_VIDEO, true)
        )
    }

    fun resetSetup(context: Context) {
        getPrefs(context).edit().putBoolean(KEY_SETUP_COMPLETED, false).apply()
    }
}
