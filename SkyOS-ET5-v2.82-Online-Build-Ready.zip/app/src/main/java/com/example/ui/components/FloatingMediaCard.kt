package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.media.MediaSource
import com.example.media.NowPlayingMetadata
import com.example.ui.theme.LocalEt5Colors

@Composable
fun FloatingMediaCard(
    nowPlaying: NowPlayingMetadata,
    onTogglePlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onClickCard: () -> Unit,
    onSelectSource: ((MediaSource) -> Unit)? = null,
    tripDurationText: String = "00:00",
    odometerKm: Float? = null,
    avgConsumptionKwh: Float? = null,
    tirePressuresBar: List<Float>? = null,
    modifier: Modifier = Modifier
) {
    val colors = LocalEt5Colors.current
    var activePage by remember { mutableIntStateOf(0) } // 0: Media, 1: Trip/Energy, 2: TPMS
    var showSourceMenu by remember { mutableStateOf(false) }

    val selectableSources = remember {
        listOf(
            MediaSource.RADIO,
            MediaSource.FM_RADIO,
            MediaSource.BLUETOOTH,
            MediaSource.USB,
            MediaSource.SPOTIFY,
            MediaSource.YOUTUBE_MUSIC,
            MediaSource.APPLE_MUSIC,
            MediaSource.DEEZER,
            MediaSource.SOUNDCLOUD,
            MediaSource.METROLIST
        )
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = colors.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, colors.stroke, RoundedCornerShape(18.dp))
            .clickable { onClickCard() }
            .testTag("floating_media_card")
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            when (activePage) {
                0 -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Station / Media Source Badge + Title info
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(nowPlaying.badgeColorHex))
                                        .clickable {
                                            if (onSelectSource != null) {
                                                showSourceMenu = true
                                            } else {
                                                onClickCard()
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = nowPlaying.badgeLogoText,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        maxLines = 1
                                    )
                                }

                                DropdownMenu(
                                    expanded = showSourceMenu,
                                    onDismissRequest = { showSourceMenu = false },
                                    modifier = Modifier.background(colors.surface2)
                                ) {
                                    selectableSources.forEach { src ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = src.displayName,
                                                    color = colors.text,
                                                    fontSize = 12.sp,
                                                    fontWeight = if (src == nowPlaying.source) FontWeight.Bold else FontWeight.Normal
                                                )
                                            },
                                            onClick = {
                                                showSourceMenu = false
                                                onSelectSource?.invoke(src)
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = nowPlaying.title,
                                    color = colors.text,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = nowPlaying.subtitle,
                                    color = colors.text2,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Controls: Previous, Play/Pause, Next
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            IconButton(
                                onClick = onPrevious,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipPrevious,
                                    contentDescription = "Önceki",
                                    tint = colors.text,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            IconButton(
                                onClick = onTogglePlay,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = if (nowPlaying.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Oynat / Durdur",
                                    tint = colors.blue,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            IconButton(
                                onClick = onNext,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "Sonraki",
                                    tint = colors.text,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Subtle track progress line matching SkyOS 2.82 card
                    LinearProgressIndicator(
                        progress = { if (nowPlaying.isPlaying) 0.35f else 0f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                            .clip(RoundedCornerShape(1.dp)),
                        color = colors.blue,
                        trackColor = colors.surface3
                    )
                }

                1 -> {
                    // Page 1: Trip & Energy Summary (Lcw; in classes.dex)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Bu sürüş • Süre: $tripDurationText", color = colors.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "Tüketim: ${avgConsumptionKwh?.let { "%.1f kWh/100km".format(it) } ?: "-- kWh/100km"}",
                                color = colors.text2,
                                fontSize = 10.sp
                            )
                        }
                        Text(
                            text = odometerKm?.let { "${it.toInt()} km" } ?: "-- km",
                            color = colors.blue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                else -> {
                    // Page 2: Tire Pressures TPMS (0x11610497 in classes.dex)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val fl = tirePressuresBar?.getOrNull(0)?.let { "%.1f".format(it) } ?: "--"
                        val fr = tirePressuresBar?.getOrNull(1)?.let { "%.1f".format(it) } ?: "--"
                        val rl = tirePressuresBar?.getOrNull(2)?.let { "%.1f".format(it) } ?: "--"
                        val rr = tirePressuresBar?.getOrNull(3)?.let { "%.1f".format(it) } ?: "--"
                        Column {
                            Text("Lastik Basınçları (TPMS)", color = colors.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Ön: $fl / $fr bar • Arka: $rl / $rr bar", color = colors.text2, fontSize = 10.sp)
                        }
                        Text("BAR", color = colors.blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Pagination Dots (...) — clickable to cycle Media / Trip / TPMS
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { activePage = (activePage + 1) % 3 }
            ) {
                for (i in 0..2) {
                    Box(
                        modifier = Modifier
                            .size(if (activePage == i) 6.dp else 4.dp)
                            .background(
                                if (activePage == i) colors.text else colors.text3.copy(alpha = 0.5f),
                                CircleShape
                            )
                    )
                }
            }
        }
    }
}
