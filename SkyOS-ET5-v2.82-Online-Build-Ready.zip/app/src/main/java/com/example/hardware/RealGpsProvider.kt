package com.example.hardware

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class GpsTelemetry(
    val hasPermission: Boolean = false,
    val isGpsEnabled: Boolean = false,
    val speedKmh: Float = 0f,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val altitudeMeters: Double = 0.0,
    val bearingDegrees: Float = 0f,
    val accuracyMeters: Float = 0f,
    val lastFixTimestamp: Long = 0L,
    val statusMessage: String = "GPS Başlatılıyor..."
)

class RealGpsProvider(private val context: Context) {

    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    private val _telemetry = MutableStateFlow(GpsTelemetry())
    val telemetry: StateFlow<GpsTelemetry> = _telemetry.asStateFlow()

    private var isListening = false

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            val speedKmh = if (location.hasSpeed()) {
                (location.speed * 3.6f).coerceAtLeast(0f)
            } else {
                0f
            }

            _telemetry.value = _telemetry.value.copy(
                hasPermission = true,
                isGpsEnabled = true,
                speedKmh = speedKmh,
                latitude = location.latitude,
                longitude = location.longitude,
                altitudeMeters = if (location.hasAltitude()) location.altitude else 0.0,
                bearingDegrees = if (location.hasBearing()) location.bearing else 0f,
                accuracyMeters = if (location.hasAccuracy()) location.accuracy else 0f,
                lastFixTimestamp = location.time,
                statusMessage = if (speedKmh > 0.5f) "GPS Konumu Aktif (Hız: ${"%.1f".format(speedKmh)} km/s)" else "GPS Konumu Aktif (Duruyor)"
            )
        }

        override fun onProviderEnabled(provider: String) {
            checkProviderStatus()
        }

        override fun onProviderDisabled(provider: String) {
            _telemetry.value = _telemetry.value.copy(
                isGpsEnabled = false,
                statusMessage = "GPS Donanımı Devre Dışı"
            )
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
            // Handled for backward compatibility with Android 9 (API 28)
        }
    }

    fun startListening() {
        val hasFine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val hasCoarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasFine && !hasCoarse) {
            _telemetry.value = _telemetry.value.copy(
                hasPermission = false,
                statusMessage = "Konum İzni Verilmedi (Hız için İzin Gerekli)"
            )
            return
        }

        val manager = locationManager ?: run {
            _telemetry.value = _telemetry.value.copy(
                hasPermission = true,
                isGpsEnabled = false,
                statusMessage = "Cihazda LocationManager Servisi Bulunamadı"
            )
            return
        }

        val gpsEnabled = manager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val networkEnabled = manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        if (!gpsEnabled && !networkEnabled) {
            _telemetry.value = _telemetry.value.copy(
                hasPermission = true,
                isGpsEnabled = false,
                statusMessage = "GPS ve Ağ Konumu Kapalı. Android Ayarlarından Açın."
            )
            return
        }

        if (isListening) return

        try {
            if (gpsEnabled) {
                manager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    500L, // 500ms update rate for automotive speedometer
                    0f,
                    locationListener,
                    Looper.getMainLooper()
                )
            }

            if (networkEnabled) {
                manager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    2000L,
                    0f,
                    locationListener,
                    Looper.getMainLooper()
                )
            }

            // Also check last known location immediately
            val lastGps = if (gpsEnabled) manager.getLastKnownLocation(LocationManager.GPS_PROVIDER) else null
            val lastNet = if (networkEnabled) manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) else null
            val bestLast = lastGps ?: lastNet

            bestLast?.let { loc ->
                locationListener.onLocationChanged(loc)
            }

            isListening = true
            _telemetry.value = _telemetry.value.copy(
                hasPermission = true,
                isGpsEnabled = true,
                statusMessage = "GPS Uydu Bağlantısı Aranıyor..."
            )
        } catch (e: SecurityException) {
            _telemetry.value = _telemetry.value.copy(
                hasPermission = false,
                statusMessage = "Konum Güvenlik Hatası: ${e.message}"
            )
        }
    }

    fun stopListening() {
        if (!isListening) return
        locationManager?.removeUpdates(locationListener)
        isListening = false
    }

    private fun checkProviderStatus() {
        val manager = locationManager ?: return
        val gpsEnabled = manager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        _telemetry.value = _telemetry.value.copy(
            isGpsEnabled = gpsEnabled,
            statusMessage = if (gpsEnabled) "GPS Aktif" else "GPS Kapalı"
        )
    }
}
