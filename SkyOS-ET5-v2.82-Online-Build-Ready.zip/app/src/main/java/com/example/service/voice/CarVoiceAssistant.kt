package com.example.service.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}

sealed class VoiceCommand {
    data class Navigate(val destination: String) : VoiceCommand()
    data class SetClimateTemp(val targetTempC: Float) : VoiceCommand()
    data class SetFanSpeed(val level: Int) : VoiceCommand()
    object ToggleSeatHeating : VoiceCommand()
    object ToggleTrunk : VoiceCommand()
    object ToggleDoors : VoiceCommand()
    object ToggleHeadlights : VoiceCommand()
    object OpenMaps : VoiceCommand()
    object OpenRadio : VoiceCommand()
    data class PlayStation(val stationName: String) : VoiceCommand()
    object OpenSpotify : VoiceCommand()
    object OpenYouTube : VoiceCommand()
    object NextRadioStation : VoiceCommand()
    object ToggleRadio : VoiceCommand()
    object OpenDiagnostics : VoiceCommand()
    object ReadSpeed : VoiceCommand()
    object OpenControls : VoiceCommand()
    object OpenProfiles : VoiceCommand()
    data class ActivateMode(val modeName: String) : VoiceCommand()
    data class Unknown(val rawText: String) : VoiceCommand()
}

class CarVoiceAssistant(
    private val context: Context,
    private val onCommandReceived: (VoiceCommand) -> Unit
) : TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    private val _voiceState = MutableStateFlow(VoiceState.IDLE)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _lastSpokenText = MutableStateFlow("")
    val lastSpokenText: StateFlow<String> = _lastSpokenText.asStateFlow()

    private val _assistantResponse = MutableStateFlow("Sesli komut için mikrofona dokunun...")
    val assistantResponse: StateFlow<String> = _assistantResponse.asStateFlow()

    init {
        textToSpeech = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale("tr", "TR"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech?.setLanguage(Locale.getDefault())
            }
            isTtsInitialized = true
        }
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _voiceState.value = VoiceState.ERROR
            _assistantResponse.value = "Ses tanıma hazır değil; komut butonlarına dokunabilirsiniz."
            return
        }

        stopListening()

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        speechRecognizer = recognizer

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _voiceState.value = VoiceState.LISTENING
                _assistantResponse.value = "Sizi dinliyorum..."
            }

            override fun onBeginningOfSpeech() {
                _voiceState.value = VoiceState.LISTENING
            }

            override fun onRmsChanged(rmsdB: Float) {}

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _voiceState.value = VoiceState.PROCESSING
                _assistantResponse.value = "Komut çözümleniyor..."
            }

            override fun onError(error: Int) {
                _voiceState.value = VoiceState.ERROR
                val errorMsg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "Ses anlaşılamadı. Lütfen tekrar deneyin."
                    SpeechRecognizer.ERROR_NETWORK -> "Ağ bağlantı hatası."
                    SpeechRecognizer.ERROR_AUDIO -> "Mikrofon ses kayıt hatası."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofon izni verilmedi."
                    else -> "Ses tanıma hatası (Kod: $error)"
                }
                _assistantResponse.value = errorMsg
            }

            override fun onResults(results: Bundle?) {
                _voiceState.value = VoiceState.IDLE
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val recognized = matches?.firstOrNull() ?: ""
                _lastSpokenText.value = recognized
                processSpokenText(recognized)
            }

            override fun onPartialResults(partialResults: Bundle?) {}

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "SkyOS Sesli Asistan")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            _voiceState.value = VoiceState.ERROR
            _assistantResponse.value = "Dinleme başlatılamadı: ${e.localizedMessage}"
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
        if (_voiceState.value == VoiceState.LISTENING) {
            _voiceState.value = VoiceState.IDLE
        }
    }

    fun speak(text: String) {
        _assistantResponse.value = text
        if (isTtsInitialized) {
            _voiceState.value = VoiceState.SPEAKING
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "SKYOS_TTS_ID")
        }
    }

    fun executeTextCommand(raw: String) {
        _lastSpokenText.value = raw
        processSpokenText(raw)
    }

    private fun processSpokenText(raw: String) {
        val lower = raw.lowercase(Locale("tr", "TR")).trim()

        // 1. Temperature & Climate controls
        val tempRegex = Regex("(\\d{2})")
        if (lower.contains("klima") || lower.contains("sıcaklık") || lower.contains("derece")) {
            val match = tempRegex.find(lower)
            if (match != null) {
                val tempVal = match.value.toFloatOrNull()
                if (tempVal != null && tempVal in 16f..32f) {
                    speak("Klima $tempVal dereceye ayarlandı.")
                    onCommandReceived(VoiceCommand.SetClimateTemp(tempVal))
                    return
                }
            }
            if (lower.contains("kapat") || lower.contains("durdur")) {
                speak("Klima kapatıldı.")
                onCommandReceived(VoiceCommand.SetClimateTemp(16f))
                return
            }
            if (lower.contains("aç") || lower.contains("soğut") || lower.contains("ısıt")) {
                speak("Klima 22 derece olarak açıldı.")
                onCommandReceived(VoiceCommand.SetClimateTemp(22f))
                return
            }
        }

        // 2. Seat Heating
        if (lower.contains("koltuk") || lower.contains("ısıtma")) {
            speak("Koltuk ısıtma durumu güncellendi.")
            onCommandReceived(VoiceCommand.ToggleSeatHeating)
            return
        }

        // 3. Trunk (Bagaj)
        if (lower.contains("bagaj")) {
            speak("Bagaj kontrolü yapılıyor.")
            onCommandReceived(VoiceCommand.ToggleTrunk)
            return
        }

        // 4. Doors & Lights
        if (lower.contains("kapı") || lower.contains("kapi")) {
            speak("Kapı durumu değiştirildi.")
            onCommandReceived(VoiceCommand.ToggleDoors)
            return
        }
        if (lower.contains("far") || lower.contains("ışık") || lower.contains("farlar")) {
            speak("Araç farları durumu değiştirildi.")
            onCommandReceived(VoiceCommand.ToggleHeadlights)
            return
        }

        // 5. Navigation
        if (lower.contains("eve git") || lower.contains("ev") && lower.contains("rota")) {
            speak("Eve rota oluşturuluyor.")
            onCommandReceived(VoiceCommand.Navigate("Eve Git"))
            return
        }
        if (lower.contains("işe git") || lower.contains("iş") && lower.contains("rota")) {
            speak("İşe rota oluşturuluyor.")
            onCommandReceived(VoiceCommand.Navigate("İşe Git"))
            return
        }
        if (lower.contains("şarj") || lower.contains("istasyon")) {
            speak("En yakın yüksek hızlı DC şarj istasyonları taranıyor.")
            onCommandReceived(VoiceCommand.Navigate("En Yakın Şarj İstasyonu"))
            return
        }
        if (lower.contains("harita") || lower.contains("navigasyon")) {
            speak("Harita ekranı açılıyor.")
            onCommandReceived(VoiceCommand.OpenMaps)
            return
        }

        // 6. Media: Spotify, YouTube, Radio
        if (lower.contains("spotify")) {
            speak("Spotify müzik sistemi açılıyor.")
            onCommandReceived(VoiceCommand.OpenSpotify)
            return
        }
        if (lower.contains("youtube") || lower.contains("video")) {
            speak("YouTube sistemi açılıyor.")
            onCommandReceived(VoiceCommand.OpenYouTube)
            return
        }
        if (lower.contains("kral türk") || lower.contains("kral fm")) {
            speak("Kral Türk FM başlatılıyor.")
            onCommandReceived(VoiceCommand.PlayStation("Kral Türk FM"))
            return
        }
        if (lower.contains("radyo 7") || lower.contains("radyo yedi")) {
            speak("Radyo 7 başlatılıyor.")
            onCommandReceived(VoiceCommand.PlayStation("Radyo 7"))
            return
        }
        if (lower.contains("radyo aç") || lower.contains("müzik çal")) {
            speak("Radyo başlatılıyor.")
            onCommandReceived(VoiceCommand.OpenRadio)
            return
        }
        if (lower.contains("sonraki istasyon") || lower.contains("kanalı değiştir") || lower.contains("sonraki şarkı")) {
            speak("Sonraki parçaya geçiliyor.")
            onCommandReceived(VoiceCommand.NextRadioStation)
            return
        }
        if (lower.contains("durdur") || lower.contains("müziği kapat") || lower.contains("sessiz")) {
            speak("Medya durduruldu.")
            onCommandReceived(VoiceCommand.ToggleRadio)
            return
        }

        // 7. Modes (Kamp, Evcil Hayvan, Uyku)
        if (lower.contains("kamp")) {
            speak("Kamp modu devrede: Klima 22 derecede sabit tutuluyor, ekranlar karartıldı.")
            onCommandReceived(VoiceCommand.ActivateMode("kamp"))
            return
        }
        if (lower.contains("evcil") || lower.contains("köpek") || lower.contains("kedi")) {
            speak("Evcil hayvan koruma modu devrede: Klima sürekli çalışıyor, kabin 21 derecede korunuyor.")
            onCommandReceived(VoiceCommand.ActivateMode("evcil_hayvan"))
            return
        }
        if (lower.contains("uyku")) {
            speak("Uyku modu aktif: Koltuk yatırıldı, ambiyans loş moda alındı.")
            onCommandReceived(VoiceCommand.ActivateMode("uyku"))
            return
        }

        // 8. Diagnostics & Controls
        if (lower.contains("hata kodu") || lower.contains("obd") || lower.contains("teşhis")) {
            speak("OBD diyagnostik ekranı açılıyor.")
            onCommandReceived(VoiceCommand.OpenDiagnostics)
            return
        }
        if (lower.contains("hızım") || lower.contains("hız")) {
            onCommandReceived(VoiceCommand.ReadSpeed)
            return
        }
        if (lower.contains("kontrol") || lower.contains("araç")) {
            speak("3D araç kontrolleri açılıyor.")
            onCommandReceived(VoiceCommand.OpenControls)
            return
        }
        if (lower.contains("profil") || lower.contains("sürücü")) {
            speak("Sürücü profilleri açılıyor.")
            onCommandReceived(VoiceCommand.OpenProfiles)
            return
        }

        speak("'$raw' komutu anlaşıldı ancak desteklenen bir araç işleviyle eşleşmedi.")
        onCommandReceived(VoiceCommand.Unknown(raw))
    }

    fun release() {
        stopListening()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
    }
}
