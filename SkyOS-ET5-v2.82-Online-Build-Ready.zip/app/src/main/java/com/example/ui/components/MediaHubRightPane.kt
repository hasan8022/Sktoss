package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.media.MediaSource
import com.example.media.PlaybackState
import com.example.service.gapps.SkywellGAppsManager
import com.example.ui.SkyOsViewModel
import com.example.ui.theme.LocalEt5Colors
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCard
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyDeepCockpit
import com.example.ui.theme.SkyDivider
import com.example.ui.theme.SkyElectricBlue
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyRed
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary
import kotlinx.coroutines.launch

@Composable
fun MediaHubRightPane(
    viewModel: SkyOsViewModel,
    onCloseToMap: () -> Unit,
    onOpenGAppsHub: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val colors = LocalEt5Colors.current
    var selectedMediaTab by remember { mutableIntStateOf(0) }
    val isDriving by viewModel.isDriving.collectAsState()
    val effectiveSpeed by viewModel.effectiveSpeedKmh.collectAsState()
    val selectedGear by viewModel.selectedGear.collectAsState()
    val blockVideoInMotion by viewModel.blockVideoInMotion.collectAsState()

    val isVideoLocked = blockVideoInMotion && (isDriving || selectedGear != "P" || effectiveSpeed > 0.5f)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.bg)
            .testTag("media_hub_right_pane")
    ) {
        // Top Header Bar with Tabs & Close (Return to Map) button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(colors.surface)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedMediaTab,
                containerColor = Color.Transparent,
                contentColor = colors.blue,
                edgePadding = 0.dp,
                indicator = { tabPositions ->
                    if (selectedMediaTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedMediaTab]),
                            color = colors.blue,
                            height = 3.dp
                        )
                    }
                },
                divider = {}
            ) {
                Tab(
                    selected = selectedMediaTab == 0,
                    onClick = { selectedMediaTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Radio, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("İnternet Radyosu", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                )
                Tab(
                    selected = selectedMediaTab == 1,
                    onClick = { selectedMediaTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Usb, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("USB · FM · BT · Akış", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                )
                Tab(
                    selected = selectedMediaTab == 2,
                    onClick = { selectedMediaTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Spotify", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                )
                Tab(
                    selected = selectedMediaTab == 3,
                    onClick = { selectedMediaTab = 3 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("YouTube Video", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                )
            }

            IconButton(
                onClick = onCloseToMap,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(colors.surface2)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Haritaya Dön",
                    tint = colors.text,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Tab Content
        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedMediaTab) {
                0 -> AutomotiveRadioPane(viewModel)
                1 -> AutomotiveUsbAndSourcesPane(viewModel)
                2 -> AutomotiveSpotifyPane(viewModel, onOpenGAppsHub)
                3 -> AutomotiveYouTubePane(viewModel, isVideoLocked, effectiveSpeed, selectedGear, onOpenGAppsHub)
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// 1. CANLI İNTERNET RADYOSU
// ------------------------------------------------------------------------------------------------
@Composable
private fun AutomotiveRadioPane(viewModel: SkyOsViewModel) {
    val stations by viewModel.radioPlayer.stations.collectAsState()
    val currentStation by viewModel.radioPlayer.currentStation.collectAsState()
    val playbackState by viewModel.radioPlayer.playbackState.collectAsState()
    val errorMsg by viewModel.radioPlayer.errorMessage.collectAsState()
    val volumeLevel by viewModel.mediaCoordinator.volumeLevel.collectAsState()

    var selectedCategory by remember { mutableStateOf("Tümü") }
    val categories = listOf("Tümü", "Favoriler", "Pop", "Haber", "Yabancı")

    val filteredStations = remember(stations, selectedCategory) {
        when (selectedCategory) {
            "Favoriler" -> stations.filter { it.isFavorite }
            "Pop" -> stations.filter { it.category.contains("Pop", ignoreCase = true) }
            "Haber" -> stations.filter { it.category.contains("Haber", ignoreCase = true) }
            "Yabancı" -> stations.filter { it.category.contains("Yabancı", ignoreCase = true) }
            else -> stations
        }
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (playbackState == PlaybackState.PLAYING) SkyGreen else SkyAmber)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (playbackState == PlaybackState.PLAYING) "CANLI YAYIN" else "BEKLEMEDE",
                            color = if (playbackState == PlaybackState.PLAYING) SkyGreen else SkyAmber,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(
                        onClick = { viewModel.radioPlayer.toggleFavorite(currentStation.id) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (currentStation.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favori",
                            tint = if (currentStation.isFavorite) SkyRed else SkyTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .size(108.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(currentStation.badgeColorHex)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = currentStation.logoText,
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = currentStation.name,
                        color = SkyTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${currentStation.subtitle} • ${currentStation.category}",
                        color = SkyTextSecondary,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (playbackState == PlaybackState.PLAYING) {
                        AnimatedSoundEqualizer()
                    } else if (playbackState == PlaybackState.BUFFERING) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(color = SkyCyan, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Bağlanıyor...", color = SkyCyan, fontSize = 11.sp)
                        }
                    } else {
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    errorMsg?.let { err ->
                        Text(text = err, color = SkyRed, fontSize = 10.sp, maxLines = 1)
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IconButton(
                        onClick = { viewModel.radioPlayer.previousStation() },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF131D2E))
                    ) {
                        Icon(Icons.Default.SkipPrevious, contentDescription = "Önceki", tint = SkyTextPrimary, modifier = Modifier.size(22.dp))
                    }

                    IconButton(
                        onClick = { viewModel.radioPlayer.togglePlayPause() },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(SkyCyan)
                    ) {
                        Icon(
                            imageVector = if (playbackState == PlaybackState.PLAYING) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Oynat / Durdur",
                            tint = Color.White,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.radioPlayer.nextStation() },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF131D2E))
                    ) {
                        Icon(Icons.Default.SkipNext, contentDescription = "Sonraki", tint = SkyTextPrimary, modifier = Modifier.size(22.dp))
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF10192A))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = SkyCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Araç Ses: $volumeLevel", color = SkyTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Row {
                        IconButton(
                            onClick = { viewModel.mediaCoordinator.adjustVolume(-1) },
                            modifier = Modifier.size(26.dp)
                        ) {
                            Text("-", color = SkyTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        IconButton(
                            onClick = { viewModel.mediaCoordinator.adjustVolume(1) },
                            modifier = Modifier.size(26.dp)
                        ) {
                            Text("+", color = SkyTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SkyCard),
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { cat ->
                        val isSelected = cat == selectedCategory
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) SkyCyan else Color(0xFF141F32))
                                .clickable { selectedCategory = cat }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = cat,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredStations) { station ->
                        val isCurrent = station.id == currentStation.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isCurrent) SkyCyan.copy(alpha = 0.16f) else Color(0xFF0D1424))
                                .clickable { viewModel.radioPlayer.playStation(station) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(station.badgeColorHex)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = station.logoText,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = station.name,
                                        color = if (isCurrent) SkyCyan else SkyTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = station.category,
                                        color = SkyTextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            if (isCurrent && playbackState == PlaybackState.PLAYING) {
                                MiniEqualizer()
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// 1B. USB MÜZİK (LPA0;), FM RADYO, BLUETOOTH VE 10 MEDYA KAYNAĞI MERKEZİ (LB00;)
// ------------------------------------------------------------------------------------------------
@Composable
private fun AutomotiveUsbAndSourcesPane(viewModel: SkyOsViewModel) {
    val colors = LocalEt5Colors.current
    val scope = rememberCoroutineScope()
    val usbTracks by viewModel.usbMediaManager.tracks.collectAsState()
    val currentUsbTrack by viewModel.usbMediaManager.currentTrack.collectAsState()
    val usbStatus by viewModel.usbMediaManager.statusMessage.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.usbMediaManager.scanUsbStorage(includePrimaryIfNoUsb = false)
    }

    val allSources = remember {
        listOf(
            MediaSource.FM_RADIO,
            MediaSource.BLUETOOTH,
            MediaSource.USB,
            MediaSource.SPOTIFY,
            MediaSource.YOUTUBE_MUSIC,
            MediaSource.APPLE_MUSIC,
            MediaSource.DEEZER,
            MediaSource.SOUNDCLOUD,
            MediaSource.METROLIST
        )
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Left: USB Audio Browser (LPA0;)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = colors.surface),
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("USB Müzik Tarayıcı (MediaStore >15 sn)", color = colors.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(usbStatus, color = colors.text2, fontSize = 11.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = {
                                scope.launch {
                                    viewModel.usbMediaManager.scanUsbStorage(includePrimaryIfNoUsb = true)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = colors.blue),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("USB Tara", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (usbTracks.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(colors.surface2, RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Usb, contentDescription = null, tint = colors.blue, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "USB ses dosyası bulunamadı. Aracın USB portuna bellek takıp 'USB Tara'ya dokunun veya OEM USB uygulamasını başlatın.",
                                color = colors.text2,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = {
                                    val ok = viewModel.usbMediaManager.launchOemUsbMediaApp()
                                    if (!ok) {
                                        viewModel.showActionFeedback("OEM USB uygulaması (com.skyworth.car.localmedia) bu cihazda kurulu değil.")
                                    }
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("OEM USB Medya Uygulamasını Aç", color = colors.text, fontSize = 11.sp)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(usbTracks) { track ->
                            val isSelected = currentUsbTrack?.id == track.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) colors.blue.copy(alpha = 0.2f) else colors.surface2)
                                    .clickable { viewModel.usbMediaManager.playTrack(track) }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(track.title, color = colors.text, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text("${track.artist} • ${track.folderName}", color = colors.text2, fontSize = 10.sp, maxLines = 1)
                                }
                                Text("${track.durationMs / 1000} sn", color = colors.text2, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // Right: SkyOS 2.82 Supported Media Sources (LB00; in classes.dex)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = colors.surface),
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
            ) {
                Text("Desteklenen Araç Medya Kaynakları (LB00;)", color = colors.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Seçilen kaynak sol sürüş kartına ve medya tuşlarına bağlanır.", color = colors.text2, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(allSources) { src ->
                        val installed = viewModel.mediaCoordinator.isSourceInstalled(src)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(colors.surface2)
                                .clickable {
                                    viewModel.mediaCoordinator.selectMediaSource(src)
                                    val launched = viewModel.mediaCoordinator.launchSourceApp(src)
                                    if (!launched && src != MediaSource.BLUETOOTH && src != MediaSource.USB) {
                                        viewModel.showActionFeedback("${src.displayName} seçildi (Yerel paket kurulu değil; Bluetooth/MediaSession bekleniyor).")
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(src.badgeColorHex)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(src.badgeShort, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(src.displayName, color = colors.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = src.packageNames.firstOrNull() ?: "",
                                        color = colors.text2,
                                        fontSize = 9.sp
                                    )
                                }
                            }
                            Text(
                                text = if (installed) "Hazır" else "Seç",
                                color = if (installed) colors.green else colors.blue,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// 2. SPOTIFY SEKMESİ
// ------------------------------------------------------------------------------------------------
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun AutomotiveSpotifyPane(
    viewModel: SkyOsViewModel,
    onOpenGAppsHub: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val isConnected by viewModel.spotifyEngine.isConnected.collectAsState()
    val currentTrack by viewModel.spotifyEngine.currentTrack.collectAsState()
    val isPlaying by viewModel.spotifyEngine.isPlaying.collectAsState()
    val playlists by viewModel.spotifyEngine.playlists.collectAsState()
    val tracks by viewModel.spotifyEngine.currentTracks.collectAsState()

    var spotifyViewMode by remember { mutableIntStateOf(0) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    val isNativeSpotifyInstalled = remember {
        try {
            context.packageManager.getPackageInfo(SkywellGAppsManager.PKG_SPOTIFY, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(10.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (spotifyViewMode == 0) Color(0xFF1DB954) else Color(0xFF131D2E))
                        .clickable { spotifyViewMode = 0 }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Resmi Spotify Web Player",
                        color = if (spotifyViewMode == 0) Color.Black else SkyTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (spotifyViewMode == 1) Color(0xFF1DB954) else Color(0xFF131D2E))
                        .clickable { spotifyViewMode = 1 }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "SkyOS HUD (OAuth gerekli)",
                        color = if (spotifyViewMode == 1) Color.Black else SkyTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (isNativeSpotifyInstalled) {
                    Button(
                        onClick = {
                            val intent = context.packageManager.getLaunchIntentForPackage(SkywellGAppsManager.PKG_SPOTIFY)
                            intent?.let {
                                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(it)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1DB954)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Yerel Spotify Uygulamasını Aç", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (onOpenGAppsHub != null) {
                    Button(
                        onClick = onOpenGAppsHub,
                        colors = ButtonDefaults.buttonColors(containerColor = SkyElectricBlue),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("GApps / Spotify APK Yükle", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (spotifyViewMode == 0) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SkyCard),
                modifier = Modifier.fillMaxSize()
            ) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            val cookieManager = CookieManager.getInstance()
                            cookieManager.setAcceptCookie(true)
                            cookieManager.setAcceptThirdPartyCookies(this, true)
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                loadWithOverviewMode = true
                                useWideViewPort = true
                                userAgentString = "Mozilla/5.0 (Linux; Android 11; Skywell ET5 IVI) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                            }
                            webChromeClient = WebChromeClient()
                            webViewClient = WebViewClient()
                            loadUrl("https://open.spotify.com")
                            webViewRef = this
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SkyCard),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF1DB954)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text("Spotify", color = SkyTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = if (isConnected) "Hesap Bağlı" else "OAuth Yapılandırması Bekleniyor",
                                            color = if (isConnected) Color(0xFF1DB954) else SkyAmber,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Çalma Listelerim", color = SkyTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))

                            if (playlists.isEmpty()) {
                                Text(
                                    "Gerçek hesap çalma listeleri henüz yüklenmedi. Spotify OAuth (tr-halil-et5://spotify-callback) yapılandırılmalı.",
                                    color = SkyTextSecondary, fontSize = 11.sp, lineHeight = 16.sp
                                )
                            }
                        }

                        currentTrack?.let { track ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF111D30)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(track.title, color = SkyTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Text(track.artist, color = SkyTextSecondary, fontSize = 10.sp, maxLines = 1)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = { viewModel.spotifyEngine.previousTrack() }, modifier = Modifier.size(32.dp)) {
                                            Icon(Icons.Default.SkipPrevious, contentDescription = null, tint = SkyTextPrimary, modifier = Modifier.size(18.dp))
                                        }
                                        IconButton(
                                            onClick = { viewModel.spotifyEngine.togglePlayPause() },
                                            modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFF1DB954))
                                        ) {
                                            Icon(
                                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                contentDescription = null,
                                                tint = Color.Black,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        IconButton(onClick = { viewModel.spotifyEngine.nextTrack() }, modifier = Modifier.size(32.dp)) {
                                            Icon(Icons.Default.SkipNext, contentDescription = null, tint = SkyTextPrimary, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SkyCard),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                        Text("Çalma Listesi Şarkıları", color = SkyTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        if (tracks.isEmpty()) {
                            Text(
                                "Gerçek Spotify oturumu bulunmuyor. Sahte çalma listesi gösterilmez.",
                                color = SkyTextSecondary, fontSize = 11.sp, lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// 3. YOUTUBE VE VİDEO (Sürüş Sırasında Video Oynatma Güvenlik Kilidi: Vites != P veya Hız > 0)
// ------------------------------------------------------------------------------------------------
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun AutomotiveYouTubePane(
    viewModel: SkyOsViewModel,
    isVideoLocked: Boolean,
    effectiveSpeed: Float,
    selectedGear: String,
    onOpenGAppsHub: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val currentVideo by viewModel.youtubeManager.currentVideo.collectAsState()
    val searchResults by viewModel.youtubeManager.searchResults.collectAsState()
    var searchInput by remember { mutableStateOf("") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var youtubeViewMode by remember { mutableIntStateOf(0) }
    var pendingYouTubeSearch by remember { mutableStateOf<String?>(null) }

    val isNativeYouTubeInstalled = remember {
        try {
            context.packageManager.getPackageInfo(SkywellGAppsManager.PKG_YOUTUBE, 0)
            true
        } catch (_: Exception) {
            try {
                context.packageManager.getPackageInfo(SkywellGAppsManager.PKG_NEWPIPE, 0)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    // Strict Driving Safety Video Interlock (surus_video)
    if (isVideoLocked) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SkyCard),
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(SkyRed.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = SkyRed, modifier = Modifier.size(34.dp))
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("SÜRÜŞ GÜVENLİĞİ VİDEO KİLİDİ AKTİF", color = SkyRed, fontSize = 17.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Araç hareket halindeyken veya vites P konumunda değilken (Vites: $selectedGear · Hız: ${"%.0f".format(effectiveSpeed)} km/s) video oynatımı güvenlik gereği engellenmiştir.",
                        color = SkyTextPrimary,
                        fontSize = 12.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Yalnızca ses dinleyebilirsiniz. Araç durup P vitesine alındığında görüntü otomatik olarak açılır.",
                        color = SkyTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize().padding(10.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (youtubeViewMode == 0) Color(0xFFFF0000) else Color(0xFF131D2E))
                        .clickable { youtubeViewMode = 0 }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("Resmi YouTube Web", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (youtubeViewMode == 1) Color(0xFFFF0000) else Color(0xFF131D2E))
                        .clickable { youtubeViewMode = 1 }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("SkyOS Arama (API gerekli)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (isNativeYouTubeInstalled) {
                    Button(
                        onClick = {
                            val intent = context.packageManager.getLaunchIntentForPackage(SkywellGAppsManager.PKG_YOUTUBE)
                                ?: context.packageManager.getLaunchIntentForPackage(SkywellGAppsManager.PKG_NEWPIPE)
                            intent?.let {
                                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(it)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF0000)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Yerel YouTube Uygulamasını Aç", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (onOpenGAppsHub != null) {
                    Button(
                        onClick = onOpenGAppsHub,
                        colors = ButtonDefaults.buttonColors(containerColor = SkyElectricBlue),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("GApps / YouTube APK Yükle", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (youtubeViewMode == 0) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SkyCard),
                modifier = Modifier.fillMaxSize()
            ) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            val cookieManager = CookieManager.getInstance()
                            cookieManager.setAcceptCookie(true)
                            cookieManager.setAcceptThirdPartyCookies(this, true)
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                loadWithOverviewMode = true
                                useWideViewPort = true
                            }
                            webChromeClient = WebChromeClient()
                            webViewClient = WebViewClient()
                            loadUrl("https://m.youtube.com")
                            webViewRef = this
                        }
                    },
                    update = { view ->
                        pendingYouTubeSearch?.let { query ->
                            view.loadUrl("https://m.youtube.com/results?search_query=${Uri.encode(query)}")
                            pendingYouTubeSearch = null
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SkyCard),
                modifier = Modifier.fillMaxSize()
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchInput,
                            onValueChange = { searchInput = it },
                            placeholder = { Text("YouTube ara...", color = SkyTextMuted, fontSize = 12.sp) },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                if (searchInput.isNotBlank()) {
                                    pendingYouTubeSearch = searchInput.trim()
                                    youtubeViewMode = 0
                                }
                            },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFFF0000))
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Ara", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    if (searchResults.isEmpty()) {
                        Text(
                            "Gerçek arama sonuçları için YouTube Data API yapılandırması gerekli. Örnek veya uydurma video gösterilmiyor.",
                            color = SkyTextSecondary, fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AnimatedSoundEqualizer() {
    val transition = rememberInfiniteTransition(label = "eq_anim")
    val h1 by transition.animateFloat(
        initialValue = 4f, targetValue = 22f,
        animationSpec = infiniteRepeatable(tween(320, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h1"
    )
    val h2 by transition.animateFloat(
        initialValue = 20f, targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(380, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h2"
    )
    val h3 by transition.animateFloat(
        initialValue = 8f, targetValue = 24f,
        animationSpec = infiniteRepeatable(tween(260, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h3"
    )
    val h4 by transition.animateFloat(
        initialValue = 18f, targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(340, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h4"
    )

    Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        modifier = Modifier.height(28.dp)
    ) {
        Box(modifier = Modifier.width(3.dp).height(h1.dp).background(SkyCyan, RoundedCornerShape(2.dp)))
        Box(modifier = Modifier.width(3.dp).height(h2.dp).background(SkyCyan, RoundedCornerShape(2.dp)))
        Box(modifier = Modifier.width(3.dp).height(h3.dp).background(SkyCyan, RoundedCornerShape(2.dp)))
        Box(modifier = Modifier.width(3.dp).height(h4.dp).background(SkyCyan, RoundedCornerShape(2.dp)))
    }
}

@Composable
private fun MiniEqualizer() {
    val transition = rememberInfiniteTransition(label = "mini_eq")
    val h1 by transition.animateFloat(
        initialValue = 3f, targetValue = 12f,
        animationSpec = infiniteRepeatable(tween(300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "m1"
    )
    val h2 by transition.animateFloat(
        initialValue = 11f, targetValue = 4f,
        animationSpec = infiniteRepeatable(tween(350, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "m2"
    )

    Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        modifier = Modifier.height(14.dp)
    ) {
        Box(modifier = Modifier.width(2.5.dp).height(h1.dp).background(SkyCyan, RoundedCornerShape(1.dp)))
        Box(modifier = Modifier.width(2.5.dp).height(h2.dp).background(SkyCyan, RoundedCornerShape(1.dp)))
    }
}
