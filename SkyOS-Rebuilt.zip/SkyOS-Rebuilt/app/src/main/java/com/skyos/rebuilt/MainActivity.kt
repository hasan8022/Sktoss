package com.skyos.rebuilt

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), LocationListener {

    // SkyOS Koyu Kokpit Renk Paleti
    private val colBg = Color.rgb(10, 14, 22)
    private val colSurface = Color.rgb(18, 24, 36)
    private val colCard = Color.rgb(25, 33, 48)
    private val colCardActive = Color.rgb(22, 62, 70)
    private val colBorder = Color.rgb(42, 54, 76)
    private val colAccent = Color.rgb(67, 208, 190)
    private val colAccentBlue = Color.rgb(62, 142, 247)
    private val colWarn = Color.rgb(245, 166, 35)
    private val colDanger = Color.rgb(229, 72, 77)
    private val colText = Color.rgb(242, 246, 252)
    private val colMuted = Color.rgb(148, 163, 184)

    private val state = VehicleState()
    private lateinit var carBridge: CarJsBridge
    private lateinit var mapBridge: MapJsBridge
    private lateinit var engine: TelemetryAndNavEngine

    // Kalıcı WebView örnekleri (ekran geçişlerinde 3D sahne ve harita sıfırlanmaz)
    private lateinit var carWebView: WebView
    private lateinit var mapWebView: WebView

    private lateinit var rootContainer: LinearLayout
    private lateinit var bodyContainer: FrameLayout
    private var activeTab: String = "cockpit" // cockpit, car, map, climate, media, obd

    // Canlı güncellenen üst/telemetri görünümleri
    private var tvClock: TextView? = null
    private var tvSpeedBig: TextView? = null
    private var tvGearBadge: TextView? = null
    private var tvSocBadge: TextView? = null
    private var tvRangeBadge: TextView? = null
    private var tvPowerBadge: TextView? = null
    private var tvSensorAlert: TextView? = null
    private var tvNavBanner: TextView? = null
    private var tvHvacBarSummary: TextView? = null
    private var tvMediaMiniTitle: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = colBg
        window.navigationBarColor = colBg

        carBridge = CarJsBridge(state) { refreshLiveWidgets() }
        mapBridge = MapJsBridge(state) { refreshLiveWidgets() }
        engine = TelemetryAndNavEngine(this, state, carBridge, mapBridge) { refreshLiveWidgets() }

        initPersistentWebViews()
        requestRuntimePermissionsIfNeeded()
        startGpsUpdates()

        rootContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(colBg)
        }
        setContentView(rootContainer)

        rebuildEntireShell()
        engine.startLoop()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        rebuildEntireShell()
        carBridge.eval("window.CAR && window.CAR.resize()")
        mapBridge.resize()
    }

    override fun onDestroy() {
        engine.stopLoop()
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            lm?.removeUpdates(this)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initPersistentWebViews() {
        carWebView = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                @Suppress("DEPRECATION")
                allowFileAccessFromFileURLs = true
                @Suppress("DEPRECATION")
                allowUniversalAccessFromFileURLs = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            }
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(carBridge, "Et5")
            loadUrl("file:///android_asset/car/index.html")
        }
        carBridge.webView = carWebView

        mapWebView = WebView(this).apply {
            setBackgroundColor(colBg)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                @Suppress("DEPRECATION")
                allowFileAccessFromFileURLs = true
                @Suppress("DEPRECATION")
                allowUniversalAccessFromFileURLs = true
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            }
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(mapBridge, "Et5Map")
            loadUrl("file:///android_asset/map-lite/index.html")
        }
        mapBridge.webView = mapWebView
    }

    private fun detachFromParent(v: View) {
        (v.parent as? ViewGroup)?.removeView(v)
    }

    private fun isSplitScreenActive(): Boolean {
        return when (state.layoutMode) {
            "SPLIT" -> true
            "TAB" -> false
            else -> resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE ||
                resources.displayMetrics.widthPixels >= dp(780)
        }
    }

    private fun rebuildEntireShell() {
        detachFromParent(carWebView)
        detachFromParent(mapWebView)
        rootContainer.removeAllViews()

        // 1. Üst Durum Çubuğu (Status & Quick Telemetry Header)
        rootContainer.addView(
            buildTopStatusBar(),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        )

        // 2. Ana Gövde Alanı
        bodyContainer = FrameLayout(this).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        rootContainer.addView(
            bodyContainer,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        // 3. Alt Kalıcı Klima (HVAC) Şeridi
        rootContainer.addView(
            buildPersistentHvacStrip(),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        )

        // 4. Alt Dock Navigasyon Barı
        rootContainer.addView(
            buildBottomDockBar(),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        )

        renderBodyContent()
        refreshLiveWidgets()
    }

    private fun buildTopStatusBar(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(colSurface)
            setPadding(dp(14), dp(4), dp(14), dp(4))

            // Sol: SkyOS Logo & Model
            val brandBox = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            brandBox.addView(label("SKYOS", 17f, colAccent, bold = true))
            brandBox.addView(label("  ET5 LR", 11f, colMuted, bold = true))
            addView(brandBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.1f))

            // Orta: Vites, Hız, Batarya, Menzil Rozetleri
            val centerHud = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            tvGearBadge = pillBadge(state.gear, colAccent, Color.BLACK)
            tvSocBadge = pillBadge("⚡ %${state.batterySoc}", colCard, colText)
            tvRangeBadge = pillBadge("${state.rangeKm} km", colCard, colAccent)
            centerHud.addView(tvGearBadge, marginParams(right = 6))
            centerHud.addView(tvSocBadge, marginParams(right = 6))
            centerHud.addView(tvRangeBadge, marginParams(right = 6))
            addView(centerHud, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.8f))

            // Sağ: Simülasyon Butonu, Görünüm Modu Değiştirici ve Saat
            val rightBox = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
            }

            val simBtn = smallActionButton(
                if (state.isSimulationActive) "SİM: AÇIK" else "SİM: KAPALI",
                active = state.isSimulationActive
            ) {
                state.isSimulationActive = !state.isSimulationActive
                if (state.isSimulationActive && !state.mapNavActive) {
                    mapBridge.setNavMode(true, state.mapHeadUp3D)
                }
                rebuildEntireShell()
            }
            rightBox.addView(simBtn, marginParams(right = 6))

            val modeLabel = when (state.layoutMode) {
                "SPLIT" -> "BÖLÜNMÜŞ"
                "TAB" -> "DİKEY/SEKME"
                else -> "OTO EKRAN"
            }
            val layoutBtn = smallActionButton(modeLabel, active = isSplitScreenActive()) {
                state.layoutMode = when (state.layoutMode) {
                    "AUTO" -> "SPLIT"
                    "SPLIT" -> "TAB"
                    else -> "AUTO"
                }
                rebuildEntireShell()
            }
            rightBox.addView(layoutBtn, marginParams(right = 8))

            tvClock = label(currentTimeStr(), 13f, colText, bold = true)
            rightBox.addView(tvClock)

            addView(rightBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f))
        }
    }

    private fun renderBodyContent() {
        detachFromParent(carWebView)
        detachFromParent(mapWebView)
        bodyContainer.removeAllViews()

        if (isSplitScreenActive() && activeTab == "cockpit") {
            // Araç Multimedya / Tablet Yatay Bölünmüş Kokpit Görünümü
            val splitRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }

            // Sol Panel (%48): Sürüş Telemetrisi + 3D Etkileşimli Skywell ET5 + Hızlı Gövde Kontrolleri
            val leftCol = buildCockpitLeft3DPanel()
            splitRow.addView(
                leftCol,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.48f).apply {
                    rightMargin = dp(8)
                }
            )

            // Sağ Panel (%52): Canlı 3D Navigasyon Haritası + Rota & Mini Medya Kartı
            val rightCol = buildCockpitRightMapPanel()
            splitRow.addView(
                rightCol,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.52f)
            )

            bodyContainer.addView(
                splitRow,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        } else {
            // Dikey (Portrait) Telefon Modu veya Tam Ekran Sekme Görünümü
            when (activeTab) {
                "cockpit" -> bodyContainer.addView(buildPortraitCockpitView())
                "car" -> bodyContainer.addView(buildFullCarControlView())
                "map" -> bodyContainer.addView(buildFullNavigationView())
                "climate" -> bodyContainer.addView(buildFullClimateView())
                "media" -> bodyContainer.addView(buildFullMediaView())
                "obd" -> bodyContainer.addView(buildFullObdAndSettingsView())
                else -> bodyContainer.addView(buildPortraitCockpitView())
            }
        }
    }

    private fun buildCockpitLeft3DPanel(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox(colSurface, colBorder, 16)
            setPadding(dp(12), dp(10), dp(12), dp(10))

            // Üst Telemetri: Hız + Vites Seçici + Sürüş Modu
            val telemetryRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val speedBlock = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
            }
            tvSpeedBig = label("${state.speedKmh}", 34f, colText, bold = true)
            speedBlock.addView(tvSpeedBig)
            tvPowerBadge = label("km/s • ${String.format(Locale.US, "%.1f", state.powerKw)} kW", 11f, colAccent)
            speedBlock.addView(tvPowerBadge)
            telemetryRow.addView(speedBlock, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            // Vites Seçici (P R N D S)
            val gearBox = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                background = roundedBox(colBg, colBorder, 10)
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            listOf("P", "R", "N", "D", "S").forEach { g ->
                val active = state.gear == g
                val btn = TextView(this@MainActivity).apply {
                    text = g
                    textSize = 13f
                    setTypeface(null, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    setPadding(dp(9), dp(5), dp(9), dp(5))
                    setTextColor(if (active) Color.BLACK else colMuted)
                    background = if (active) roundedBox(colAccent, colAccent, 8) else null
                    setOnClickListener {
                        switchGear(g)
                        rebuildEntireShell()
                    }
                }
                gearBox.addView(btn)
            }
            telemetryRow.addView(gearBox)
            addView(telemetryRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

            // 3D Skywell ET5 Sahnesi
            val stageFrame = FrameLayout(this@MainActivity).apply {
                background = roundedBox(colBg, colBorder, 12)
            }
            detachFromParent(carWebView)
            stageFrame.addView(
                carWebView,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )

            // 3D Sahne Üstü Kamera & Park Sensörü Uyarı Etiketi
            tvSensorAlert = label("", 11f, colWarn, bold = true).apply {
                setPadding(dp(8), dp(4), dp(8), dp(4))
                background = roundedBox(Color.argb(190, 12, 16, 25), colBorder, 8)
                visibility = if (state.parkSensorsActive) View.VISIBLE else View.GONE
            }
            stageFrame.addView(
                tvSensorAlert,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    gravity = Gravity.TOP or Gravity.START
                    topMargin = dp(8)
                    leftMargin = dp(8)
                }
            )

            addView(
                stageFrame,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply {
                    topMargin = dp(8)
                    bottomMargin = dp(8)
                }
            )

            // Kamera Açısı Hızlı Seçim Şeridi
            val camScroll = HorizontalScrollView(this@MainActivity).apply {
                isHorizontalScrollBarEnabled = false
            }
            val camRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            state.cameraPresets.forEach { (title, viewKey) ->
                camRow.addView(
                    smallActionButton(title, active = state.cameraView == viewKey) {
                        carBridge.setCameraView(viewKey)
                        if (viewKey == "park") {
                            state.parkSensorsActive = true
                            carBridge.syncParkSensors()
                        }
                        rebuildEntireShell()
                    },
                    marginParams(right = 6)
                )
            }
            camScroll.addView(camRow)
            addView(camScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            })

            // Hızlı Araç Gövde Kontrolleri (Kapılar, Bagaj, Kaput, Şarj, Camlar, Dörtlü, Sensör)
            val quickScroll = HorizontalScrollView(this@MainActivity).apply {
                isHorizontalScrollBarEnabled = false
            }
            val quickRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            val anyDoorOpen = state.doors.any { it }
            quickRow.addView(smallActionButton(if (anyDoorOpen) "Kapıları Kapat" else "4 Kapı Aç", anyDoorOpen) {
                carBridge.setAllDoors(!anyDoorOpen)
                rebuildEntireShell()
            }, marginParams(right = 6))

            quickRow.addView(smallActionButton("Bagaj", state.trunkOpen) {
                carBridge.setTrunk(!state.trunkOpen)
                rebuildEntireShell()
            }, marginParams(right = 6))

            quickRow.addView(smallActionButton("Kaput", state.hoodOpen) {
                carBridge.setHood(!state.hoodOpen)
                rebuildEntireShell()
            }, marginParams(right = 6))

            quickRow.addView(smallActionButton("Şarj Kapağı", state.chargePortOpen) {
                carBridge.setChargePort(!state.chargePortOpen)
                rebuildEntireShell()
            }, marginParams(right = 6))

            val anyWinOpen = state.windows.any { it }
            quickRow.addView(smallActionButton("4 Cam", anyWinOpen) {
                carBridge.setAllWindows(!anyWinOpen)
                rebuildEntireShell()
            }, marginParams(right = 6))

            quickRow.addView(smallActionButton("Dörtlü Flaşör", state.hazardLights) {
                carBridge.setSignals(state.leftSignal, state.rightSignal, !state.hazardLights)
                rebuildEntireShell()
            }, marginParams(right = 6))

            quickRow.addView(smallActionButton("Park Sensörü", state.parkSensorsActive) {
                state.parkSensorsActive = !state.parkSensorsActive
                carBridge.syncParkSensors()
                rebuildEntireShell()
            }, marginParams(right = 6))

            quickScroll.addView(quickRow)
            addView(quickScroll)
        }
    }

    private fun buildCockpitRightMapPanel(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL

            // Üst: Harita & Navigasyon Çerçevesi
            val mapCard = FrameLayout(this@MainActivity).apply {
                background = roundedBox(colSurface, colBorder, 16)
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            detachFromParent(mapWebView)
            mapCard.addView(
                mapWebView,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )

            // Harita Üstü Yönlendirme (Turn-by-Turn) Kartı
            val activeRoute = state.routes[state.activeRouteIndex]
            val navOverlay = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox(Color.argb(225, 16, 22, 34), colBorder, 12)
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            tvNavBanner = label("↱ ${activeRoute.nextTurnText}", 13f, colText, bold = true)
            navOverlay.addView(tvNavBanner)
            navOverlay.addView(
                label("${activeRoute.title} • ${activeRoute.distanceKm} km (${activeRoute.durationMin} dk)", 11f, colAccent)
            )
            mapCard.addView(
                navOverlay,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    gravity = Gravity.TOP
                    setMargins(dp(10), dp(10), dp(10), 0)
                }
            )

            // Harita Altı Kontrol Butonları (3D Takip, Koyu/Açık Harita, Rota Değiştir)
            val mapCtrlRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                background = roundedBox(Color.argb(220, 16, 22, 34), colBorder, 10)
                setPadding(dp(8), dp(6), dp(8), dp(6))
            }
            mapCtrlRow.addView(smallActionButton(if (state.mapNavActive) "3D Nav: Açık" else "3D Nav Başlat", state.mapNavActive) {
                mapBridge.setNavMode(!state.mapNavActive, state.mapHeadUp3D)
                rebuildEntireShell()
            }, marginParams(right = 6))

            mapCtrlRow.addView(smallActionButton("Merkezle", state.mapFollow) {
                mapBridge.setFollow(true, 17)
                rebuildEntireShell()
            }, marginParams(right = 6))

            mapCtrlRow.addView(smallActionButton(if (state.mapDarkTheme) "Gece Haritası" else "Gündüz Haritası", state.mapDarkTheme) {
                mapBridge.applyTileTheme(!state.mapDarkTheme)
                rebuildEntireShell()
            }, marginParams(right = 6))

            mapCtrlRow.addView(smallActionButton("Rota Değiştir", false) {
                val nextIdx = (state.activeRouteIndex + 1) % state.routes.size
                mapBridge.loadRoutePreset(nextIdx, fitBounds = true)
                rebuildEntireShell()
            })

            mapCard.addView(
                mapCtrlRow,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    gravity = Gravity.BOTTOM or Gravity.START
                    setMargins(dp(10), 0, dp(10), dp(10))
                }
            )

            addView(
                mapCard,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply {
                    bottomMargin = dp(8)
                }
            )

            // Alt: Kompakt Medya Oynatıcı & Sürüş Modu Kartı
            val bottomStrip = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = roundedBox(colSurface, colBorder, 14)
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            val currentTrack = state.tracks[state.mediaTrackIndex]
            val trackInfo = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
            }
            tvMediaMiniTitle = label("🎵 ${currentTrack.title}", 13f, colText, bold = true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            trackInfo.addView(tvMediaMiniTitle)
            trackInfo.addView(label("${currentTrack.artist} • ${currentTrack.source}", 11f, colMuted))
            bottomStrip.addView(trackInfo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            bottomStrip.addView(smallActionButton("⏮", false) {
                state.mediaTrackIndex = (state.mediaTrackIndex - 1 + state.tracks.size) % state.tracks.size
                state.mediaProgressSec = 0
                rebuildEntireShell()
            }, marginParams(right = 6))

            bottomStrip.addView(smallActionButton(if (state.mediaPlaying) "⏸" else "▶", state.mediaPlaying) {
                state.mediaPlaying = !state.mediaPlaying
                rebuildEntireShell()
            }, marginParams(right = 6))

            bottomStrip.addView(smallActionButton("⏭", false) {
                state.mediaTrackIndex = (state.mediaTrackIndex + 1) % state.tracks.size
                state.mediaProgressSec = 0
                rebuildEntireShell()
            })

            addView(bottomStrip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun buildPortraitCockpitView(): ScrollView {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        // 1. 3D Araç Kartı (Yükseklik 270dp)
        val carPanel = buildCockpitLeft3DPanel()
        col.addView(
            carPanel,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360)).apply {
                bottomMargin = dp(10)
            }
        )

        // 2. Harita & Navigasyon Kartı (Yükseklik 320dp)
        val mapPanel = buildCockpitRightMapPanel()
        col.addView(
            mapPanel,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(340)).apply {
                bottomMargin = dp(10)
            }
        )

        scroll.addView(col)
        return scroll
    }

    private fun buildFullCarControlView(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = if (isSplitScreenActive()) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL

            // 3D Sahne Alanı
            val stageCard = FrameLayout(this@MainActivity).apply {
                background = roundedBox(colSurface, colBorder, 16)
                setPadding(dp(6), dp(6), dp(6), dp(6))
            }
            detachFromParent(carWebView)
            stageCard.addView(
                carWebView,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )

            val stageParams = if (isSplitScreenActive()) {
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.55f).apply { rightMargin = dp(10) }
            } else {
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260)).apply { bottomMargin = dp(10) }
            }
            addView(stageCard, stageParams)

            // Detaylı Kontrol Listesi
            val ctrlScroll = ScrollView(this@MainActivity)
            val ctrlCol = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox(colSurface, colBorder, 16)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }

            ctrlCol.addView(label("3D SKYWELL ET5 GÖVDE & IŞIK KONTROLLERİ", 14f, colAccent, bold = true))

            // Kapılar (Sol Ön, Sağ Ön, Sol Arka, Sağ Arka)
            ctrlCol.addView(sectionHeader("Kapılar ve Gövde Kapakları"))
            val doorRow1 = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            val doorNames = listOf("Sol Ön Kapı", "Sağ Ön Kapı", "Sol Arka Kapı", "Sağ Arka Kapı")
            for (i in 0..1) {
                doorRow1.addView(
                    smallActionButton(doorNames[i], state.doors[i]) {
                        carBridge.setDoor(i, !state.doors[i])
                        rebuildEntireShell()
                    },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
                )
            }
            ctrlCol.addView(doorRow1, marginParams(bottom = 6))

            val doorRow2 = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 2..3) {
                doorRow2.addView(
                    smallActionButton(doorNames[i], state.doors[i]) {
                        carBridge.setDoor(i, !state.doors[i])
                        rebuildEntireShell()
                    },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
                )
            }
            ctrlCol.addView(doorRow2, marginParams(bottom = 8))

            val bodyCapsRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            bodyCapsRow.addView(smallActionButton("Ön Kaput", state.hoodOpen) {
                carBridge.setHood(!state.hoodOpen)
                rebuildEntireShell()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

            bodyCapsRow.addView(smallActionButton("Elektrikli Bagaj", state.trunkOpen) {
                carBridge.setTrunk(!state.trunkOpen)
                rebuildEntireShell()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

            bodyCapsRow.addView(smallActionButton("Şarj Kapağı", state.chargePortOpen) {
                carBridge.setChargePort(!state.chargePortOpen)
                rebuildEntireShell()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ctrlCol.addView(bodyCapsRow, marginParams(bottom = 8))

            // Camlar & Sunroof
            ctrlCol.addView(sectionHeader("Camlar ve Panoramik Sunroof"))
            val winRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            val winLabels = listOf("Cam S.Ön", "Cam Sğ.Ön", "Cam S.Arka", "Cam Sğ.Arka")
            for (i in 0..3) {
                winRow.addView(
                    smallActionButton(winLabels[i], state.windows[i]) {
                        carBridge.setWindow(i, !state.windows[i])
                        rebuildEntireShell()
                    },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) }
                )
            }
            ctrlCol.addView(winRow, marginParams(bottom = 6))

            val roofRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            val allWins = state.windows.all { it }
            roofRow.addView(smallActionButton(if (allWins) "Tüm Camları Kapat" else "Havalandırma (4 Cam)", allWins) {
                carBridge.setAllWindows(!allWins)
                rebuildEntireShell()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

            roofRow.addView(smallActionButton("Panoramik Sunroof", state.sunroofOpen) {
                carBridge.setSunroof(!state.sunroofOpen)
                rebuildEntireShell()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ctrlCol.addView(roofRow, marginParams(bottom = 8))

            // Sinyaller, Fren & Park Sensörleri
            ctrlCol.addView(sectionHeader("Aydınlatma, Sinyal ve 360° Radar"))
            val lightRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            lightRow.addView(smallActionButton("⬅ Sol Sinyal", state.leftSignal) {
                carBridge.setSignals(!state.leftSignal, false, state.hazardLights)
                rebuildEntireShell()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

            lightRow.addView(smallActionButton("⚠ Dörtlü", state.hazardLights) {
                carBridge.setSignals(state.leftSignal, state.rightSignal, !state.hazardLights)
                rebuildEntireShell()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

            lightRow.addView(smallActionButton("Sağ Sinyal ➡", state.rightSignal) {
                carBridge.setSignals(false, !state.rightSignal, state.hazardLights)
                rebuildEntireShell()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ctrlCol.addView(lightRow, marginParams(bottom = 6))

            val brakeRadarRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            brakeRadarRow.addView(smallActionButton("Fren Lambası (SKYWELL)", state.brakeLights) {
                carBridge.setBrake(!state.brakeLights)
                rebuildEntireShell()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

            brakeRadarRow.addView(smallActionButton("360° Park Sensörü", state.parkSensorsActive) {
                state.parkSensorsActive = !state.parkSensorsActive
                if (state.parkSensorsActive) carBridge.setCameraView("park")
                carBridge.syncParkSensors()
                rebuildEntireShell()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ctrlCol.addView(brakeRadarRow, marginParams(bottom = 8))

            // Araç Gövde Rengi Seçimi
            ctrlCol.addView(sectionHeader("Gövde Boya Rengi"))
            val colorScroll = HorizontalScrollView(this@MainActivity).apply { isHorizontalScrollBarEnabled = false }
            val colorRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            state.paintPalette.forEach { (name, hex) ->
                colorRow.addView(
                    smallActionButton(name, state.paintColorHex.equals(hex, ignoreCase = true)) {
                        state.paintColorName = name
                        carBridge.setColor(hex)
                        rebuildEntireShell()
                    },
                    marginParams(right = 6)
                )
            }
            colorScroll.addView(colorRow)
            ctrlCol.addView(colorScroll, marginParams(bottom = 8))

            // Kamera Açıları ve Performans Modeli Seçimi
            ctrlCol.addView(sectionHeader("3D Kamera Açıları & GLB Model Kalitesi"))
            val camScroll = HorizontalScrollView(this@MainActivity).apply { isHorizontalScrollBarEnabled = false }
            val camRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            state.cameraPresets.forEach { (labelName, key) ->
                camRow.addView(
                    smallActionButton(labelName, state.cameraView == key) {
                        carBridge.setCameraView(key)
                        rebuildEntireShell()
                    },
                    marginParams(right = 6)
                )
            }
            camScroll.addView(camRow)
            ctrlCol.addView(camScroll, marginParams(bottom = 8))

            val modelRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            modelRow.addView(smallActionButton("Yüksek Detay (et5.glb)", !state.useLiteModel) {
                if (state.useLiteModel) {
                    state.useLiteModel = false
                    carWebView.loadUrl("file:///android_asset/car/index.html")
                    rebuildEntireShell()
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

            modelRow.addView(smallActionButton("Hafif Model (et5-hafif.glb)", state.useLiteModel) {
                if (!state.useLiteModel) {
                    state.useLiteModel = true
                    carWebView.loadUrl("file:///android_asset/car/index-eski.html")
                    rebuildEntireShell()
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ctrlCol.addView(modelRow)

            ctrlScroll.addView(ctrlCol)
            val ctrlParams = if (isSplitScreenActive()) {
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.45f)
            } else {
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            addView(ctrlScroll, ctrlParams)
        }
    }

    private fun buildFullNavigationView(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val mapPanel = buildCockpitRightMapPanel()
            addView(mapPanel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

            // Alt Rota Seçim Çubuğu
            val routeBar = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = roundedBox(colSurface, colBorder, 12)
                setPadding(dp(10), dp(8), dp(10), dp(8))
            }
            state.routes.forEachIndexed { idx, r ->
                routeBar.addView(
                    smallActionButton(r.title.substringBefore("→").trim() + " Rotası", state.activeRouteIndex == idx) {
                        mapBridge.loadRoutePreset(idx, fitBounds = true)
                        rebuildEntireShell()
                    },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
                )
            }
            addView(routeBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            })
        }
    }

    private fun buildFullClimateView(): ScrollView {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox(colSurface, colBorder, 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        col.addView(label("ÇİFT BÖLGELİ AKILLI İKLİMLENDİRME (HVAC)", 16f, colAccent, bold = true))
        col.addView(label("Kabin Dışı Sıcaklık: ${state.exteriorTempC}°C • PM2.5 Kabin Filtresi Aktif", 12f, colMuted).apply {
            setPadding(0, dp(4), 0, dp(14))
        })

        // Sol ve Sağ Sıcaklık Ayar Kartları
        val zonesRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val leftZone = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundedBox(colCard, colBorder, 14)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        leftZone.addView(label("SÜRÜCÜ BÖLGESİ", 11f, colMuted, bold = true))
        leftZone.addView(label(String.format(Locale.US, "%.1f°C", state.tempLeftC), 32f, colText, bold = true).apply {
            setPadding(0, dp(6), 0, dp(8))
        })
        val leftBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        leftBtns.addView(smallActionButton(" - 0.5° ", false) {
            state.tempLeftC = (state.tempLeftC - 0.5).coerceAtLeast(16.0)
            rebuildEntireShell()
        }, marginParams(right = 8))
        leftBtns.addView(smallActionButton(" + 0.5° ", true) {
            state.tempLeftC = (state.tempLeftC + 0.5).coerceAtMost(30.0)
            rebuildEntireShell()
        })
        leftZone.addView(leftBtns)
        leftZone.addView(smallActionButton("Koltuk Isıtma: Kademe ${state.seatHeatLeft}", state.seatHeatLeft > 0) {
            state.seatHeatLeft = (state.seatHeatLeft + 1) % 4
            rebuildEntireShell()
        }.apply { layoutParams = marginParams(top = 10) })

        val rightZone = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundedBox(colCard, colBorder, 14)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        rightZone.addView(label("YOLCU BÖLGESİ", 11f, colMuted, bold = true))
        rightZone.addView(label(String.format(Locale.US, "%.1f°C", state.tempRightC), 32f, colText, bold = true).apply {
            setPadding(0, dp(6), 0, dp(8))
        })
        val rightBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rightBtns.addView(smallActionButton(" - 0.5° ", false) {
            state.tempRightC = (state.tempRightC - 0.5).coerceAtLeast(16.0)
            rebuildEntireShell()
        }, marginParams(right = 8))
        rightBtns.addView(smallActionButton(" + 0.5° ", true) {
            state.tempRightC = (state.tempRightC + 0.5).coerceAtMost(30.0)
            rebuildEntireShell()
        })
        rightZone.addView(rightBtns)
        rightZone.addView(smallActionButton("Koltuk Isıtma: Kademe ${state.seatHeatRight}", state.seatHeatRight > 0) {
            state.seatHeatRight = (state.seatHeatRight + 1) % 4
            rebuildEntireShell()
        }.apply { layoutParams = marginParams(top = 10) })

        zonesRow.addView(leftZone, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) })
        zonesRow.addView(rightZone, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(zonesRow, marginParams(bottom = 14))

        // Fan Hızı (1 - 7)
        col.addView(sectionHeader("Fan Hızı Kademesi: ${state.fanLevel} / 7"))
        val fanRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (lvl in 1..7) {
            fanRow.addView(
                smallActionButton("$lvl", state.fanLevel == lvl) {
                    state.fanLevel = lvl
                    rebuildEntireShell()
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) }
            )
        }
        col.addView(fanRow, marginParams(bottom = 14))

        // İklimlendirme Mod Tuşları
        col.addView(sectionHeader("Klima ve Buğu Çözücü Modları"))
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modeRow.addView(smallActionButton("A/C Soğutma", state.acEnabled) {
            state.acEnabled = !state.acEnabled
            rebuildEntireShell()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

        modeRow.addView(smallActionButton("AUTO İklim", state.autoClimate) {
            state.autoClimate = !state.autoClimate
            rebuildEntireShell()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

        modeRow.addView(smallActionButton("İç Sirkülasyon", state.recirculate) {
            state.recirculate = !state.recirculate
            rebuildEntireShell()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(modeRow, marginParams(bottom = 8))

        val defrostRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        defrostRow.addView(smallActionButton("Ön Cam Buğu Çözücü", state.frontDefrost) {
            state.frontDefrost = !state.frontDefrost
            rebuildEntireShell()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

        defrostRow.addView(smallActionButton("Arka Cam Rezistansı", state.rearDefrost) {
            state.rearDefrost = !state.rearDefrost
            rebuildEntireShell()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(defrostRow)

        scroll.addView(col)
        return scroll
    }

    private fun buildFullMediaView(): ScrollView {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox(colSurface, colBorder, 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        val current = state.tracks[state.mediaTrackIndex]
        col.addView(label("SKYOS SES VE MEDYA MERKEZİ", 16f, colAccent, bold = true))
        col.addView(label(current.title, 22f, colText, bold = true).apply { setPadding(0, dp(10), 0, dp(2)) })
        col.addView(label("${current.artist} • ${current.source}", 13f, colMuted).apply { setPadding(0, 0, 0, dp(12)) })

        val ctrlRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ctrlRow.addView(smallActionButton("⏮ Önceki", false) {
            state.mediaTrackIndex = (state.mediaTrackIndex - 1 + state.tracks.size) % state.tracks.size
            state.mediaProgressSec = 0
            rebuildEntireShell()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) })

        ctrlRow.addView(smallActionButton(if (state.mediaPlaying) "⏸ Duraklat" else "▶ Oynat", state.mediaPlaying) {
            state.mediaPlaying = !state.mediaPlaying
            rebuildEntireShell()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) })

        ctrlRow.addView(smallActionButton("Sonraki ⏭", false) {
            state.mediaTrackIndex = (state.mediaTrackIndex + 1) % state.tracks.size
            state.mediaProgressSec = 0
            rebuildEntireShell()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(ctrlRow, marginParams(bottom = 14))

        col.addView(sectionHeader("Kayıtlı İstasyonlar ve Çalma Listesi"))
        state.tracks.forEachIndexed { idx, tr ->
            col.addView(
                smallActionButton("${idx + 1}. ${tr.title} (${tr.source})", state.mediaTrackIndex == idx) {
                    state.mediaTrackIndex = idx
                    state.mediaPlaying = true
                    state.mediaProgressSec = 0
                    rebuildEntireShell()
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(6)
                }
            )
        }

        col.addView(sectionHeader("Telefon & Bluetooth Ses Kısayolları"))
        val phoneRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        phoneRow.addView(smallActionButton("📞 Telefon / Rehber Aç", false) {
            openDialer()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) })

        phoneRow.addView(smallActionButton("🔵 Bluetooth Ayarları", false) {
            openBluetoothSettings()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(phoneRow)

        scroll.addView(col)
        return scroll
    }

    private fun buildFullObdAndSettingsView(): ScrollView {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox(colSurface, colBorder, 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        col.addView(label("OBD-II / CAN-BUS TELEMETRİ VE SİSTEM AYARLARI", 16f, colAccent, bold = true))
        col.addView(label("Protokol: ${state.obdProtocol}", 12f, colMuted).apply { setPadding(0, dp(4), 0, dp(8)) })
        col.addView(label("Durum: ${state.obdStatusLog}", 12f, colText).apply { setPadding(0, 0, 0, dp(12)) })

        // Canlı Telemetri Değerleri Kartı
        val metricsGrid = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = roundedBox(colCard, colBorder, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        metricsGrid.addView(
            label("HV Batarya\n${String.format(Locale.US, "%.1f V", state.voltageV)} (%${state.batterySoc})", 12f, colAccent, bold = true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        metricsGrid.addView(
            label("Motor Devri\n${state.motorRpm} RPM", 12f, colText, bold = true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        metricsGrid.addView(
            label("Lastik Basıncı\n${state.tirePressuresBar[0]} / ${state.tirePressuresBar[2]} bar", 12f, colText, bold = true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        col.addView(metricsGrid, marginParams(bottom = 12))

        // Sürüş Modu Seçimi
        col.addView(sectionHeader("Sürüş Modu (Drive Mode)"))
        val driveRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("ECO", "COMFORT", "SPORT", "TEK PEDAL").forEach { m ->
            driveRow.addView(
                smallActionButton(m, state.driveMode == m) {
                    state.driveMode = m
                    rebuildEntireShell()
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            )
        }
        col.addView(driveRow, marginParams(bottom = 12))

        // Eşleşmiş Bluetooth / ELM327 Cihazları
        col.addView(sectionHeader("Eşleşmiş Bluetooth / OBD2 Adaptörleri"))
        val paired = engine.getPairedObdDevices()
        if (paired.isEmpty()) {
            col.addView(label("Eşleşmiş Bluetooth OBD2 cihazı bulunamadı veya izin verilmedi. Aşağıdan Bluetooth ayarlarını açabilir ya da Canlı Simülasyon modunu kullanabilirsiniz.", 12f, colMuted).apply {
                setPadding(0, 0, 0, dp(8))
            })
        } else {
            paired.forEach { (name, addr) ->
                col.addView(
                    smallActionButton("Bağlan: $name ($addr)", state.obdDeviceName.contains(addr)) {
                        engine.connectToObdDevice(addr, name)
                    },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = dp(6)
                    }
                )
            }
        }

        val sysRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sysRow.addView(smallActionButton("Bluetooth Ayarları", false) {
            openBluetoothSettings()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })

        sysRow.addView(smallActionButton("Uygulama İzinleri", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(sysRow)

        scroll.addView(col)
        return scroll
    }

    private fun buildPersistentHvacStrip(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(colSurface)
            setPadding(dp(12), dp(4), dp(12), dp(4))

            // Sol Sıcaklık
            addView(smallActionButton("◀", false) {
                state.tempLeftC = (state.tempLeftC - 0.5).coerceAtLeast(16.0)
                refreshLiveWidgets()
            }, marginParams(right = 4))

            tvHvacBarSummary = label(formatHvacSummary(), 12f, colText, bold = true).apply {
                gravity = Gravity.CENTER
            }
            addView(tvHvacBarSummary, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            addView(smallActionButton("▶", false) {
                state.tempLeftC = (state.tempLeftC + 0.5).coerceAtMost(30.0)
                refreshLiveWidgets()
            }, marginParams(left = 4, right = 8))

            addView(smallActionButton("A/C", state.acEnabled) {
                state.acEnabled = !state.acEnabled
                rebuildEntireShell()
            }, marginParams(right = 6))

            addView(smallActionButton("Fan ${state.fanLevel}", state.hvacPower) {
                state.fanLevel = (state.fanLevel % 7) + 1
                rebuildEntireShell()
            })
        }
    }

    private fun buildBottomDockBar(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(colBg)
            setPadding(dp(8), dp(4), dp(8), dp(4))

            val tabs = listOf(
                "Kokpit" to "cockpit",
                "3D Araç" to "car",
                "Harita" to "map",
                "Klima" to "climate",
                "Medya" to "media",
                "OBD / Ayar" to "obd"
            )

            tabs.forEach { (title, id) ->
                val isSelected = activeTab == id
                val btn = TextView(this@MainActivity).apply {
                    text = title
                    textSize = 12f
                    setTypeface(null, if (isSelected) Typeface.BOLD else Typeface.NORMAL)
                    gravity = Gravity.CENTER
                    setTextColor(if (isSelected) Color.BLACK else colText)
                    background = roundedBox(
                        if (isSelected) colAccent else colSurface,
                        if (isSelected) colAccent else colBorder,
                        10
                    )
                    setOnClickListener {
                        activeTab = id
                        renderBodyContent()
                        rebuildEntireShell()
                    }
                }
                addView(
                    btn,
                    LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                        leftMargin = dp(3)
                        rightMargin = dp(3)
                    }
                )
            }
        }
    }

    private fun switchGear(newGear: String) {
        state.gear = newGear
        when (newGear) {
            "R" -> {
                state.parkSensorsActive = true
                carBridge.setCameraView("park")
                carBridge.syncParkSensors()
            }
            "P" -> {
                state.speedKmh = 0
                state.powerKw = 0.0
                carBridge.setCameraView("parked")
            }
            "D", "S" -> {
                carBridge.setCameraView("hero")
            }
        }
    }

    private fun refreshLiveWidgets() {
        tvClock?.text = currentTimeStr()
        tvSpeedBig?.text = "${state.speedKmh}"
        tvGearBadge?.text = state.gear
        tvSocBadge?.text = "⚡ %${state.batterySoc}"
        tvRangeBadge?.text = "${state.rangeKm} km"
        tvPowerBadge?.text = "km/s • ${String.format(Locale.US, "%.1f", state.powerKw)} kW • ${state.driveMode}"
        tvHvacBarSummary?.text = formatHvacSummary()

        val activeRoute = state.routes[state.activeRouteIndex]
        val remKm = (activeRoute.distanceKm * (1.0 - state.routeProgressFrac)).coerceAtLeast(0.1)
        tvNavBanner?.text = String.format(
            Locale.US,
            "↱ %s (Kalan: %.1f km)",
            activeRoute.nextTurnText,
            remKm
        )

        if (state.parkSensorsActive) {
            val fMin = state.frontSensors.minOrNull() ?: 1.2f
            val rMin = state.rearSensors.minOrNull() ?: 0.8f
            tvSensorAlert?.visibility = View.VISIBLE
            tvSensorAlert?.text = String.format(Locale.US, "RADAR • Ön: %.2f m | Arka: %.2f m", fMin, rMin)
        } else {
            tvSensorAlert?.visibility = View.GONE
        }
    }

    private fun formatHvacSummary(): String {
        return String.format(
            Locale.US,
            "❄ Sol %.1f°C  |  Sağ %.1f°C  •  %s",
            state.tempLeftC,
            state.tempRightC,
            if (state.autoClimate) "AUTO" else "MANUEL"
        )
    }

    private fun currentTimeStr(): String {
        return SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    }

    private fun requestRuntimePermissionsIfNeeded() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
            perms.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1001)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startGpsUpdates() {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                val lm = getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                lm?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 2f, this)
                lm?.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 5f, this)
            }
        } catch (_: Exception) {
        }
    }

    override fun onLocationChanged(location: Location) {
        if (!state.isSimulationActive) {
            state.gpsStatusText = "Canlı GPS Aktif"
            if (location.hasSpeed()) {
                state.speedKmh = (location.speed * 3.6f).toInt()
            }
            val bearing = if (location.hasBearing()) location.bearing.toDouble() else state.currentBearing
            mapBridge.updateFix(location.latitude, location.longitude, bearing, null)
            refreshLiveWidgets()
        }
    }

    private fun openBluetoothSettings() {
        try {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        } catch (_: Exception) {
            Toast.makeText(this, "Bluetooth ayarları açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openDialer() {
        try {
            startActivity(Intent(Intent.ACTION_DIAL))
        } catch (_: Exception) {
            Toast.makeText(this, "Telefon uygulaması bulunamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    // Yardımcı UI Oluşturucuları
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundedBox(fillColor: Int, strokeColor: Int, radiusDp: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(fillColor)
            setStroke(dp(1), strokeColor)
        }
    }

    private fun label(textStr: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = textStr
            textSize = sizeSp
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }
    }

    private fun sectionHeader(title: String): TextView {
        return label(title, 12f, colMuted, bold = true).apply {
            setPadding(0, dp(8), 0, dp(6))
        }
    }

    private fun pillBadge(textStr: String, bgCol: Int, fgCol: Int): TextView {
        return TextView(this).apply {
            text = textStr
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(fgCol)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = roundedBox(bgCol, colBorder, 8)
        }
    }

    private fun smallActionButton(textStr: String, active: Boolean, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = textStr
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(if (active) colAccent else colText)
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = roundedBox(
                if (active) colCardActive else colCard,
                if (active) colAccent else colBorder,
                9
            )
            setOnClickListener { onClick() }
        }
    }

    private fun marginParams(left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(left), dp(top), dp(right), dp(bottom))
        }
    }
}
