package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.ViewGroup
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.LocalParking
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.HardwareDiagnosticInfo
import com.example.ui.SkyOsViewModel
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCard
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyElectricBlue
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyNavy
import com.example.ui.theme.SkyRed
import com.example.ui.theme.SkySurface
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GoogleMapsScreen(
    viewModel: SkyOsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hardwareInfo by viewModel.hardwareInfo.collectAsState()
    val gpsTelemetry by viewModel.gpsTelemetry.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var networkError by remember { mutableStateOf<String?>(null) }

    // Initial Base URL (uses current GPS lat/lng if available)
    val initialUrl = remember(gpsTelemetry.latitude, gpsTelemetry.longitude) {
        if (gpsTelemetry.latitude != 0.0 && gpsTelemetry.longitude != 0.0) {
            "https://www.google.com/maps/@${gpsTelemetry.latitude},${gpsTelemetry.longitude},15z"
        } else {
            "https://www.google.com/maps"
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SkyNavy)
            .testTag("google_maps_screen")
    ) {
        // Status & App Switcher Header
        Surface(
            color = SkySurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Google Haritalar",
                            color = SkyTextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(
                                    if (hardwareInfo.isGmsAvailable) SkyGreen.copy(alpha = 0.2f) else SkyAmber.copy(alpha = 0.2f),
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (hardwareInfo.isGmsAvailable) "Google Play Hizmetleri: Mevcut" else "AOSP / Web Harita Modu (GApps Gerekmez)",
                                color = if (hardwareInfo.isGmsAvailable) SkyGreen else SkyAmber,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    if (gpsTelemetry.latitude != 0.0) {
                        Text(
                            text = "Konum: ${"%.4f".format(gpsTelemetry.latitude)}, ${"%.4f".format(gpsTelemetry.longitude)} (Doğruluk: ±${gpsTelemetry.accuracyMeters.toInt()}m)",
                            color = SkyTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                // If native Google Maps app is installed, provide direct intent launch
                if (hardwareInfo.isGoogleMapsAppInstalled) {
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:${gpsTelemetry.latitude},${gpsTelemetry.longitude}?q=charging+station")).apply {
                                setPackage("com.google.android.apps.maps")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            try {
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SkyElectricBlue),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Maps Uygulamasında Aç", fontSize = 12.sp)
                    }
                }
            }
        }

        // Search Bar & Destination Quick Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Hedef veya şarj istasyonu ara...", color = SkyTextMuted, fontSize = 13.sp) },
                singleLine = true,
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = SkyCyan, modifier = Modifier.size(20.dp))
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SkyCyan,
                    unfocusedBorderColor = SkyCard,
                    focusedTextColor = SkyTextPrimary,
                    unfocusedTextColor = SkyTextPrimary,
                    focusedContainerColor = SkyCard,
                    unfocusedContainerColor = SkyCard
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = {
                    if (searchQuery.isNotBlank()) {
                        val url = "https://www.google.com/maps/search/${Uri.encode(searchQuery)}"
                        webViewRef?.loadUrl(url)
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SkyCyan)
            ) {
                Text("Ara", color = Color(0xFF041E26), fontWeight = FontWeight.Bold)
            }
        }

        // Quick Category Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DestinationChip("DC Hızlı Şarj (CCS2)") {
                searchQuery = "Skywell ET5 DC Hızlı Şarj İstasyonu"
                webViewRef?.loadUrl("https://www.google.com/maps/search/DC+hizli+sarj+istasyonu")
            }
            DestinationChip("Togg Trugo / ZES / Eşarj") {
                searchQuery = "Elektrikli Araç Şarj İstasyonu"
                webViewRef?.loadUrl("https://www.google.com/maps/search/elektrikli+sarj+istasyonu")
            }
            DestinationChip("Otopark") {
                searchQuery = "Otopark"
                webViewRef?.loadUrl("https://www.google.com/maps/search/otopark")
            }
            DestinationChip("Oto Yıkama") {
                searchQuery = "Oto Yıkama"
                webViewRef?.loadUrl("https://www.google.com/maps/search/oto+yikama")
            }
            DestinationChip("Restoran") {
                searchQuery = "Restoran"
                webViewRef?.loadUrl("https://www.google.com/maps/search/restoran")
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Main Map Canvas: Secure Official Google Maps Web Embed with Real Geolocation
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (!hardwareInfo.isInternetConnected && networkError != null) {
                // Network error banner (strictly complying with user instruction #13)
                Card(
                    colors = CardDefaults.cardColors(containerColor = SkyCard),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.WifiOff,
                            contentDescription = null,
                            tint = SkyRed,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Harita Bağlantı Hatası",
                            color = SkyTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "İnternet bağlantısı bulunamadı. Lütfen aracın Wi-Fi veya SIM kart bağlantısını kontrol edin.\n($networkError)",
                            color = SkyTextSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                networkError = null
                                webViewRef?.reload()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SkyCyan)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tekrar Dene", color = Color(0xFF041E26))
                        }
                    }
                }
            } else {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                setGeolocationEnabled(true)
                                databaseEnabled = true
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                mediaPlaybackRequiresUserGesture = false
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onGeolocationPermissionsShowPrompt(
                                    origin: String?,
                                    callback: GeolocationPermissions.Callback?
                                ) {
                                    // Grant HTML5 geolocation so Google Maps centers on vehicle
                                    callback?.invoke(origin, true, false)
                                }
                            }

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    isLoading = true
                                    networkError = null
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    isLoading = false
                                }

                                override fun onReceivedError(
                                    view: WebView?,
                                    request: WebResourceRequest?,
                                    error: WebResourceError?
                                ) {
                                    super.onReceivedError(view, request, error)
                                    if (request?.isForMainFrame == true) {
                                        isLoading = false
                                        networkError = error?.description?.toString() ?: "Ağ hatası"
                                    }
                                }
                            }

                            loadUrl(initialUrl)
                            webViewRef = this
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .background(SkyCard.copy(alpha = 0.85f), RoundedCornerShape(12.dp))
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                color = SkyCyan,
                                modifier = Modifier.size(24.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Harita yükleniyor...",
                                color = SkyTextPrimary,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DestinationChip(title: String, onClick: () -> Unit) {
    FilterChip(
        selected = false,
        onClick = onClick,
        label = { Text(title, fontSize = 11.sp, color = SkyTextPrimary) },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = SkyCard,
            labelColor = SkyTextPrimary
        ),
        shape = RoundedCornerShape(8.dp)
    )
}
