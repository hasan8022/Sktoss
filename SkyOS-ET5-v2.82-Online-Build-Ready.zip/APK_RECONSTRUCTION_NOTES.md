# SkyOS 2.82 APK-first reconstruction notes

Date: 2026-11-01
Target configuration: Skywell ET5, model year 2023 (user-provided)

## Evidence observed in the original APK

The original APK is retained byte-for-byte at `recovery_reference/SkyOS-2.82-original.apk`. Its SHA-256 is:

`83e97b2b9e6fcc1d826e9385d1fdc8520995156204e8268c860c701cc9fae6f4`

The APK ZIP contains 297 entries. The full ZIP payload is extracted under `recovery_reference/full_apk_dump/`. `AndroidManifest.xml`, `resources.arsc`, and `classes.dex` are retained as compiled artifacts; they are not source Kotlin/XML.

DEX string/class evidence includes the `tr.halil.et5` namespace and symbols/names such as `Et5App`, `Et5Ayar`, `Et5Arac`, `Et5Klima`, `Et5Kapi`, `Et5Isiklar`, `Et5Koltuk`, `Et5Obd`, `Et5Radyo`, `Et5Spotify`, `Et5Lisans`, `Et5Installer`, `Et5Map`, `Et5Profile`, `Et5Guncelleme`, `BootReceiver`, `PanelGuardService`, `RadioService`, and `Et5InCallService`.

String evidence also includes:

- OEM/system package namespace references: `com.skyworth.car.*`
- HVAC provider reference: `com.coolwell.ai.skyhvac` and `content://com.coolwell.ai.skyhvac.database/airconditioner`
- Capability label strings: `CONTROL_CAR_CLIMATE`, `CONTROL_CAR_DOORS`, `CONTROL_CAR_EXTERIOR_LIGHTS`, `CONTROL_CAR_MIRRORS`, `CONTROL_CAR_SEATS`, `CONTROL_CAR_WINDOWS`
- Spotify App Remote class references
- MapLibre native library/reference
- Radio Browser endpoint strings and `tr.halil.et5.radio.RadioService`
- OBD/vLinker MS strings
- License-related strings including `tr.halil.et5.license`, `License.State.Valid`, `/kontrol/lisans`, `et5_lisans`, `trial_vin`, and `trial_used`

These are evidence that code paths, SDKs, service identifiers or UI labels existed in the compiled APK. Strings alone do not prove that a feature is enabled, callable by a third-party app, authorized on a different head unit, or compatible with every ET5 firmware.

## Original assets

All 24 original APK assets have byte-identical copies under `app/src/main/assets/recovered_original/`. The usable runtime copies currently in `app/src/main/assets/` include:

- `arac.bin` (30,928 bytes), starts with `ET5H`
- `arac.ver` (16 bytes)
- `car/et5.glb`, `car/et5-hafif.glb`, `car/car3d.js`, `car/index.html`, Three.js modules
- `i18n/de.json`, `en.json`, `es.json`, `ru.json`
- `map-lite/` Leaflet resources

`ET5H` is treated only as a recognized four-byte container signature. The binary schema, cryptographic meaning of `arac.ver`, VIN binding, license validity and vehicle protocol are not decoded or verified.

## Changes in this reconstruction pass

1. `VehicleBinaryManager` no longer labels an `ET5H` magic-header match as a verified vehicle/license. It reports file size, SHA-256, version string and signature recognition only.
2. Setup wizard no longer displays the bundled files as an active/verified license.
3. Setup defaults now target `Skywell ET5 2023`; plate, driver, license and home/work fields default to blank.
4. Map home/work defaults are blank rather than a fabricated address.
5. The OBD technical tab no longer displays unverified BMS cell layout, battery voltage, motor power/torque or pinout as vehicle facts. It explicitly marks them as unverified.

## Remaining reverse-engineering work

- Decode `classes.dex` using a compatible DEX decompiler and map classes/methods/call sites, not just strings.
- Decode `resources.arsc` and binary XML to recover resource names, layouts, navigation and strings.
- Determine the exact file format of `arac.bin` and semantics of `arac.ver` using the original application behavior and additional evidence.
- Identify OEM AIDL/HAL/provider contracts and signature permissions for the exact Coocaa/Skyworth head unit firmware.
- Compare the user-provided promotional video with recovered screen flows once uploaded.

## Build status

The Android project has not been compiled in this environment. No Android SDK, system Gradle, Gradle wrapper launcher or wrapper JAR was found. Do not treat this workspace as a built or device-tested APK. Open it in Android Studio, allow Gradle 9.3.1 / AGP 9.1.1 dependency resolution, then resolve any compiler or SDK issues and run tests on a safe test device before vehicle installation.
