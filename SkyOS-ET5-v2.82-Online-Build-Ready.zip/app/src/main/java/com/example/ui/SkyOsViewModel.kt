package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.view.KeyEvent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.LicenseManager
import com.example.data.LicenseState
import com.example.data.SetupConfiguration
import com.example.data.SetupManager
import com.example.data.db.AppDatabase
import com.example.data.db.DriverProfile
import com.example.data.db.DriverProfileRepository
import com.example.data.obd.OBDManager
import com.example.data.obd.ObdLogEntry
import com.example.hardware.GpsTelemetry
import com.example.hardware.RealGpsProvider
import com.example.hardware.SystemDiagnosticsManager
import com.example.media.CarMediaCoordinator
import com.example.media.MediaSource
import com.example.media.PlaybackState
import com.example.media.RadioMediaPlayer
import com.example.media.SpotifyManager
import com.example.media.SpotifyWebEngine
import com.example.media.UsbMediaManager
import com.example.media.YouTubePlayerManager
import com.example.model.DtcCode
import com.example.model.HardwareDiagnosticInfo
import com.example.model.OBDConnectionStatus
import com.example.model.VehicleTelemetry
import com.example.service.gapps.SkywellGAppsManager
import com.example.service.vehicle.SkywellCarServiceBridge
import com.example.service.vehicle.SkywellVehicleState
import com.example.service.vehicle.VehicleConnectionMode
import com.example.service.voice.CarVoiceAssistant
import com.example.service.voice.VoiceCommand
import com.example.service.voice.VoiceState
import com.example.ui.components.ActiveDockTab
import com.example.util.SkywellI18nManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AutomotiveScreen {
    DASHBOARD,
    NAVIGATION,
    MEDIA,
    VEHICLE_CONTROLS,
    OBD_DIAGNOSTICS,
    DRIVER_PROFILES,
    SYSTEM_DIAGNOSTICS
}

enum class RightPaneMode {
    MAPS,
    MEDIA_HUB,
    VEHICLE_CONTROLS,
    BATTERY_ENERGY,
    PHONE_DIALER,
    OBD_DIAGNOSTICS,
    DRIVER_PROFILES,
    SYSTEM_DIAGNOSTICS
}

class SkyOsViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext

    // 1. Hardware, Vehicle, License & Media Managers
    val gpsProvider = RealGpsProvider(context)
    val systemDiagnostics = SystemDiagnosticsManager(context)
    val obdManager = OBDManager(viewModelScope)
    val vehicleBridge = SkywellCarServiceBridge(context, viewModelScope)
    val licenseManager = LicenseManager(context)
    val mediaCoordinator = CarMediaCoordinator(context)
    val radioPlayer = RadioMediaPlayer(context, mediaCoordinator)
    val usbMediaManager = UsbMediaManager(context, mediaCoordinator)
    val youtubeManager = YouTubePlayerManager(mediaCoordinator)
    val spotifyEngine = SpotifyWebEngine(mediaCoordinator)
    val spotifyManager = SpotifyManager(context)
    val gappsManager = SkywellGAppsManager(context)

    val vehicleState: StateFlow<SkywellVehicleState> = vehicleBridge.vehicleState
    val licenseState: StateFlow<LicenseState> = licenseManager.licenseState

    private val _showGAppsHub = MutableStateFlow(false)
    val showGAppsHub: StateFlow<Boolean> = _showGAppsHub.asStateFlow()

    fun openGAppsHub() {
        gappsManager.refreshPackageStatus()
        _showGAppsHub.value = true
    }

    fun closeGAppsHub() {
        _showGAppsHub.value = false
    }

    // 0. Setup Wizard, Theme & Visual Preferences
    private val _isSetupCompleted = MutableStateFlow(SetupManager.isSetupCompleted(context))
    val isSetupCompleted: StateFlow<Boolean> = _isSetupCompleted.asStateFlow()

    private val _setupConfig = MutableStateFlow(SetupManager.getConfiguration(context))
    val setupConfig: StateFlow<SetupConfiguration> = _setupConfig.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(_setupConfig.value.isDarkTheme)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _carColorHex = MutableStateFlow(_setupConfig.value.carColorHex)
    val carColorHex: StateFlow<Int> = _carColorHex.asStateFlow()

    private val _use3DCarView = MutableStateFlow(_setupConfig.value.use3DCarView)
    val use3DCarView: StateFlow<Boolean> = _use3DCarView.asStateFlow()

    private val _blockVideoInMotion = MutableStateFlow(_setupConfig.value.blockVideoInMotion)
    val blockVideoInMotion: StateFlow<Boolean> = _blockVideoInMotion.asStateFlow()

    fun toggleDarkTheme() {
        val next = !_isDarkTheme.value
        _isDarkTheme.value = next
        SetupManager.setDarkTheme(context, next)
    }

    fun setDarkTheme(isDark: Boolean) {
        _isDarkTheme.value = isDark
        SetupManager.setDarkTheme(context, isDark)
    }

    fun setCarColor(colorHex: Int) {
        _carColorHex.value = colorHex
        SetupManager.setCarColorHex(context, colorHex)
    }

    fun toggle3DCarView() {
        val next = !_use3DCarView.value
        _use3DCarView.value = next
        SetupManager.setUse3DCarView(context, next)
    }

    fun setBlockVideoInMotion(block: Boolean) {
        _blockVideoInMotion.value = block
        SetupManager.setBlockVideoInMotion(context, block)
    }

    // Elapsed Session / Trip Timer ("00:00" / "01:15")
    private val sessionStartMs = System.currentTimeMillis()
    private val _tripDurationText = MutableStateFlow("00:00")
    val tripDurationText: StateFlow<String> = _tripDurationText.asStateFlow()

    // Action Toast / Feedback Banner
    private val _actionToastMessage = MutableStateFlow<String?>(null)
    val actionToastMessage: StateFlow<String?> = _actionToastMessage.asStateFlow()

    fun showActionFeedback(msg: String) {
        _actionToastMessage.value = msg
        viewModelScope.launch {
            delay(3500L)
            if (_actionToastMessage.value == msg) {
                _actionToastMessage.value = null
            }
        }
    }

    // Rear Camera / 360 EVS Overlay
    private val _showRearCameraOverlay = MutableStateFlow(false)
    val showRearCameraOverlay: StateFlow<Boolean> = _showRearCameraOverlay.asStateFlow()

    fun toggleRearCameraOverlay() {
        _showRearCameraOverlay.value = !_showRearCameraOverlay.value
    }

    fun closeRearCameraOverlay() {
        _showRearCameraOverlay.value = false
    }

    fun launchOem360Camera(): Boolean {
        val pkgs = listOf("com.skyworth.car.evs", "com.coocaa.car.avin", "com.skyworth.car.camera")
        for (pkg in pkgs) {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return try {
                    context.startActivity(intent)
                    true
                } catch (_: Exception) {
                    false
                }
            }
        }
        showActionFeedback("OEM 360° kamera paketi (com.skyworth.car.evs) bu cihazda bulunamadı.")
        return false
    }

    fun returnToStockLauncher() {
        val stockPkgs = listOf("com.skyworth.car.launcher", "com.android.launcher3")
        for (pkg in stockPkgs) {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    context.startActivity(intent)
                    return
                } catch (_: Exception) {}
            }
        }
        showActionFeedback("Orijinal araç başlatıcısı (com.skyworth.car.launcher) bu cihazda kurulu değil.")
    }

    // Cockpit Telemetry States (strictly derived from real hardware/vehicle sources)
    val selectedGear: StateFlow<String> = vehicleState.map { it.gear }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "P")

    // HVAC States (synced with SkyHVAC / CarPropertyManager)
    private val _driverTempC = MutableStateFlow(_setupConfig.value.cabinTempCelsius)
    val driverTempC: StateFlow<Float> = combine(_driverTempC, vehicleState) { local, vs ->
        if (vs.connectionMode != VehicleConnectionMode.DISCONNECTED) vs.hvacTargetTempC else local
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 22.0f)

    private val _passengerTempC = MutableStateFlow(22.0f)
    val passengerTempC: StateFlow<Float> = _passengerTempC.asStateFlow()

    val fanLevel: StateFlow<Int> = vehicleState.map { it.hvacFanSpeed }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 2)

    val driverSeatHeatingLevel: StateFlow<Int> = vehicleState.map { it.driverSeatHeatLevel }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val passengerSeatHeatingLevel: StateFlow<Int> = vehicleState.map { it.passengerSeatHeatLevel }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val frontDefrostOn: StateFlow<Boolean> = vehicleState.map { it.frontDefrostOn }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val rearDefrostOn: StateFlow<Boolean> = vehicleState.map { it.rearDefrostOn }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val _activeDockTab = MutableStateFlow(ActiveDockTab.MAPS)
    val activeDockTab: StateFlow<ActiveDockTab> = _activeDockTab.asStateFlow()

    private val _rightPaneMode = MutableStateFlow(RightPaneMode.MAPS)
    val rightPaneMode: StateFlow<RightPaneMode> = _rightPaneMode.asStateFlow()

    // 2. Database
    private val database = AppDatabase.getInstance(context)
    private val profileRepository = DriverProfileRepository(database.driverProfileDao())

    val driverProfiles: StateFlow<List<DriverProfile>> = profileRepository.allProfiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeProfile: StateFlow<DriverProfile?> = profileRepository.defaultProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // 3. Navigation State
    private val _currentScreen = MutableStateFlow(AutomotiveScreen.DASHBOARD)
    val currentScreen: StateFlow<AutomotiveScreen> = _currentScreen.asStateFlow()

    // 4. Hardware Environment Info
    private val _hardwareInfo = MutableStateFlow(systemDiagnostics.scanHardwareEnvironment())
    val hardwareInfo: StateFlow<HardwareDiagnosticInfo> = _hardwareInfo.asStateFlow()

    // 5. Unified Real Telemetry (NO fake fallback numbers)
    val gpsTelemetry: StateFlow<GpsTelemetry> = gpsProvider.telemetry
    val obdStatus: StateFlow<OBDConnectionStatus> = obdManager.connectionStatus
    val obdStatusMessage: StateFlow<String> = obdManager.statusMessage
    val obdTelemetry: StateFlow<VehicleTelemetry> = obdManager.telemetry
    val obdLogs: StateFlow<List<ObdLogEntry>> = obdManager.terminalLogs

    val isObdConnected: StateFlow<Boolean> = combine(obdStatus, vehicleState) { status, vs ->
        status == OBDConnectionStatus.CONNECTED || vs.connectionMode != VehicleConnectionMode.DISCONNECTED
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val batterySocPercent: StateFlow<Int?> = combine(vehicleState, obdTelemetry) { vs, obd ->
        vs.batterySocPercent ?: obd.batterySocPercent
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val batteryRangeKm: StateFlow<Int?> = vehicleState.map { it.rangeKm }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val insideTempC: StateFlow<Int?> = vehicleState.map { it.insideTempC?.toInt() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val outsideTempC: StateFlow<Int?> = vehicleState.map { it.outsideTempC?.toInt() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val radarDistanceCm: StateFlow<Int?> = vehicleState.map { it.minRadarDistanceCm }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Effective Speed: CarPropertyManager speed -> OBD Speed -> Real GPS Speed
    val effectiveSpeedKmh: StateFlow<Float> = combine(vehicleState, obdTelemetry, gpsTelemetry) { vs, obd, gps ->
        when {
            vs.speedKmh != null -> vs.speedKmh
            obd.obdSpeedKmh != null -> obd.obdSpeedKmh.toFloat()
            else -> gps.speedKmh
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0f)

    // Driving Safety Lockout: Active when gear != P or speed > 1.0 km/h
    val isDriving: StateFlow<Boolean> = combine(effectiveSpeedKmh, selectedGear) { speed, gear ->
        gear != "P" || speed > 1.0f
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // 6. Voice Assistant
    private val _voiceAssistantState = MutableStateFlow(VoiceState.IDLE)
    val voiceAssistantState: StateFlow<VoiceState> = _voiceAssistantState.asStateFlow()

    private val _voiceMessage = MutableStateFlow("Sesli komut vermek için mikrofona dokunun")
    val voiceMessage: StateFlow<String> = _voiceMessage.asStateFlow()

    private val _showVoiceAssistantModal = MutableStateFlow(false)
    val showVoiceAssistantModal: StateFlow<Boolean> = _showVoiceAssistantModal.asStateFlow()

    fun openVoiceAssistant() {
        _showVoiceAssistantModal.value = true
        voiceAssistant.startListening()
    }

    fun closeVoiceAssistant() {
        _showVoiceAssistantModal.value = false
        voiceAssistant.stopListening()
    }

    val voiceAssistant = CarVoiceAssistant(context) { command ->
        handleVoiceCommand(command)
    }

    // Interactive Vehicle Visualizer States (synced with real SkywellVehicleState)
    private val _carRotationDegrees = MutableStateFlow(0f)
    val carRotationDegrees: StateFlow<Float> = _carRotationDegrees.asStateFlow()

    val isHeadlightOn: StateFlow<Boolean> = vehicleState.map { it.lowBeamOn || it.highBeamOn }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val isDriverDoorOpen: StateFlow<Boolean> = vehicleState.map { it.doorsOpen.getOrElse(0) { false } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val isTrunkOpen: StateFlow<Boolean> = vehicleState.map { it.trunkOpen }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    init {
        SkywellI18nManager.initialize(context, _setupConfig.value.languageCode)
        gpsProvider.startListening()
        vehicleBridge.start()

        // Start session timer
        viewModelScope.launch {
            while (isActive) {
                val elapsedSec = ((System.currentTimeMillis() - sessionStartMs) / 1000L).coerceAtLeast(0L)
                val hours = elapsedSec / 3600L
                val mins = (elapsedSec % 3600L) / 60L
                val secs = elapsedSec % 60L
                _tripDurationText.value = if (hours > 0) {
                    "%02d:%02d".format(hours, mins)
                } else {
                    "%02d:%02d".format(mins, secs)
                }
                delay(1000L)
            }
        }

        // Automatically show rear camera overlay when vehicle enters R gear
        viewModelScope.launch {
            selectedGear.collect { gear ->
                if (gear == "R") {
                    _showRearCameraOverlay.value = true
                }
            }
        }

        // Forward bridge feedback to toast
        viewModelScope.launch {
            vehicleBridge.lastCommandFeedback.collect { fb ->
                if (!fb.isNullOrBlank()) {
                    showActionFeedback(fb)
                }
            }
        }

        // Sync voice assistant state
        viewModelScope.launch {
            voiceAssistant.voiceState.collect { state ->
                _voiceAssistantState.value = state
            }
        }
        viewModelScope.launch {
            voiceAssistant.assistantResponse.collect { msg ->
                _voiceMessage.value = msg
            }
        }
    }

    fun navigateTo(screen: AutomotiveScreen) {
        _currentScreen.value = screen
    }

    fun refreshHardwareAudit() {
        _hardwareInfo.value = systemDiagnostics.scanHardwareEnvironment()
        gappsManager.refreshPackageStatus()
    }

    fun rotateCar(deltaDegrees: Float) {
        _carRotationDegrees.value = (_carRotationDegrees.value + deltaDegrees) % 360f
    }

    fun resetCarRotation() {
        _carRotationDegrees.value = 0f
    }

    // Real Vehicle Actuators via SkywellCarServiceBridge (LMg0; / LDE; / LPC;)
    fun toggleHeadlights() {
        viewModelScope.launch {
            val target = if (isHeadlightOn.value) "0" else "1"
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_EXTERIOR_LIGHTS,
                areaId = 0,
                typeCode = "i",
                valueStr = target
            )
        }
    }

    fun toggleDriverDoor() {
        if (isDriving.value) {
            showActionFeedback("Güvenlik: sadece P vitesinde")
            return
        }
        viewModelScope.launch {
            val locked = vehicleState.value.doorsLocked
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_DOOR_LOCK,
                areaId = 0,
                typeCode = "i",
                valueStr = if (locked) "0" else "1",
                requireParkGear = true
            )
        }
    }

    fun toggleTrunk() {
        if (isDriving.value) {
            showActionFeedback("Güvenlik: sadece P vitesinde")
            return
        }
        viewModelScope.launch {
            val open = isTrunkOpen.value
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_TRUNK_OPEN,
                areaId = 0,
                typeCode = "i",
                valueStr = if (open) "0" else "1",
                requireParkGear = true
            )
        }
    }

    fun stopCharging() {
        viewModelScope.launch {
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_CHARGE_START_STOP,
                areaId = 0,
                typeCode = "i",
                valueStr = "0"
            )
        }
    }

    fun setGear(gear: String) {
        showActionFeedback("Vites durumu ($gear) fiziksel vites seçiciden okunur; ekrandan değiştirilmez.")
    }

    fun adjustDriverTemp(delta: Float) {
        val next = (driverTempC.value + delta).coerceIn(18.0f, 32.0f)
        _driverTempC.value = next
        viewModelScope.launch {
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_HVAC_TEMP_SET,
                areaId = 1,
                typeCode = "f",
                valueStr = "%.1f".format(java.util.Locale.US, next)
            )
        }
    }

    fun cycleFanLevel() {
        val next = (fanLevel.value % 7) + 1
        viewModelScope.launch {
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_HVAC_FAN_SPEED,
                areaId = 0,
                typeCode = "i",
                valueStr = next.toString()
            )
        }
    }

    fun cycleDriverSeatHeating() {
        val next = (driverSeatHeatingLevel.value + 1) % 4
        viewModelScope.launch {
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_SEAT_DRIVER_HEAT_VENT,
                areaId = 0,
                typeCode = "i",
                valueStr = next.toString()
            )
        }
    }

    fun cyclePassengerSeatHeating() {
        val next = (passengerSeatHeatingLevel.value + 1) % 4
        viewModelScope.launch {
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_SEAT_PASSENGER_HEAT_VENT,
                areaId = 0,
                typeCode = "i",
                valueStr = next.toString()
            )
        }
    }

    fun toggleFrontDefrost() {
        val next = !frontDefrostOn.value
        viewModelScope.launch {
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_HVAC_DEFROST,
                areaId = 1,
                typeCode = "b",
                valueStr = next.toString()
            )
        }
    }

    fun toggleRearDefrost() {
        val next = !rearDefrostOn.value
        viewModelScope.launch {
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_HVAC_DEFROST,
                areaId = 2,
                typeCode = "b",
                valueStr = next.toString()
            )
        }
    }

    fun toggleEsc() {
        val next = !vehicleState.value.escEnabled
        viewModelScope.launch {
            vehicleBridge.sendVehiclePropertyCommand(
                propId = SkywellCarServiceBridge.PROP_ESC_STATE,
                areaId = 0,
                typeCode = "b",
                valueStr = next.toString()
            )
        }
    }

    // Unified Media Playback Controls
    fun toggleActiveMediaPlayPause() {
        when (mediaCoordinator.nowPlaying.value.source) {
            MediaSource.RADIO -> radioPlayer.togglePlayPause()
            MediaSource.USB -> usbMediaManager.togglePlayPause()
            MediaSource.SPOTIFY -> spotifyEngine.togglePlayPause()
            MediaSource.YOUTUBE -> Unit
            else -> mediaCoordinator.dispatchSystemMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        }
    }

    fun previousActiveMedia() {
        when (mediaCoordinator.nowPlaying.value.source) {
            MediaSource.RADIO -> radioPlayer.previousStation()
            MediaSource.USB -> usbMediaManager.previousTrack()
            MediaSource.SPOTIFY -> spotifyEngine.previousTrack()
            MediaSource.YOUTUBE -> Unit
            else -> mediaCoordinator.dispatchSystemMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }
    }

    fun nextActiveMedia() {
        when (mediaCoordinator.nowPlaying.value.source) {
            MediaSource.RADIO -> radioPlayer.nextStation()
            MediaSource.USB -> usbMediaManager.nextTrack()
            MediaSource.SPOTIFY -> spotifyEngine.nextTrack()
            MediaSource.YOUTUBE -> Unit
            else -> mediaCoordinator.dispatchSystemMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
        }
    }

    // OBD Functions
    fun connectObdBluetooth(address: String) {
        obdManager.connectBluetooth(address)
    }

    fun connectObdWifi(ip: String, port: Int) {
        obdManager.connectWifi(ip, port)
    }

    fun disconnectObd() {
        obdManager.disconnect()
    }

    fun queryDtcCodes(onComplete: (List<DtcCode>) -> Unit) {
        viewModelScope.launch {
            val codes = obdManager.queryDiagnosticTroubleCodes()
            onComplete(codes)
        }
    }

    fun clearDtcCodes(onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = obdManager.clearDiagnosticTroubleCodes()
            onResult(success)
        }
    }

    // Driver Profile Functions
    fun addNewProfile(name: String, temp: Float, seat: Int, radio: String, dest: String) {
        viewModelScope.launch {
            profileRepository.insertProfile(
                DriverProfile(
                    name = name,
                    avatarIndex = (0..3).random(),
                    cabinTempCelsius = temp,
                    seatPreset = seat,
                    favoriteRadioName = radio,
                    favoriteDestination = dest,
                    isDefault = false
                )
            )
        }
    }

    fun setActiveProfile(profile: DriverProfile) {
        viewModelScope.launch {
            profileRepository.setActiveProfile(profile.id)
            _driverTempC.value = profile.cabinTempCelsius
            val station = RadioMediaPlayer.PRESET_STATIONS.find {
                it.name.equals(profile.favoriteRadioName, ignoreCase = true)
            }
            station?.let { radioPlayer.playStation(it) }
        }
    }

    fun deleteProfile(profile: DriverProfile) {
        viewModelScope.launch {
            profileRepository.deleteProfile(profile)
        }
    }

    // Setup Wizard Completion
    fun completeSetup(config: SetupConfiguration) {
        SetupManager.saveConfiguration(
            context = context,
            vehicleModel = config.vehicleModel,
            licensePlate = config.licensePlate,
            licenseCode = config.licenseCode,
            driverName = config.driverName,
            homeAddress = config.homeAddress,
            workAddress = config.workAddress,
            cabinTempCelsius = config.cabinTempCelsius,
            preferredRadioName = config.preferredRadioName,
            obdMacAddress = config.obdMacAddress,
            webhookUrl = config.webhookUrl,
            languageCode = config.languageCode,
            isDarkTheme = config.isDarkTheme,
            carColorHex = config.carColorHex,
            use3DCarView = config.use3DCarView,
            blockVideoInMotion = config.blockVideoInMotion
        )
        _setupConfig.value = config
        _isDarkTheme.value = config.isDarkTheme
        _carColorHex.value = config.carColorHex
        _use3DCarView.value = config.use3DCarView
        _blockVideoInMotion.value = config.blockVideoInMotion
        _driverTempC.value = config.cabinTempCelsius
        SkywellI18nManager.setLanguage(context, config.languageCode)

        // Insert/update driver profile into database if provided
        if (config.driverName.isNotBlank()) {
            viewModelScope.launch {
                val station = RadioMediaPlayer.PRESET_STATIONS.find {
                    it.name.equals(config.preferredRadioName, ignoreCase = true)
                }
                profileRepository.insertProfile(
                    DriverProfile(
                        name = config.driverName,
                        avatarIndex = 0,
                        cabinTempCelsius = config.cabinTempCelsius,
                        seatPreset = 1,
                        favoriteRadioName = config.preferredRadioName,
                        favoriteRadioUrl = station?.streamUrl
                            ?: "https://kral-radyo.medyainternet.com/kral/kralfm/playlist.m3u8",
                        favoriteDestination = config.homeAddress,
                        isDefault = true
                    )
                )
            }
        }

        if (config.obdMacAddress.isNotBlank()) {
            obdManager.connectBluetooth(config.obdMacAddress)
        }

        _isSetupCompleted.value = true
    }

    fun restartSetupWizard() {
        SetupManager.resetSetup(context)
        _isSetupCompleted.value = false
    }

    fun selectDockTab(tab: ActiveDockTab) {
        _activeDockTab.value = tab
        when (tab) {
            ActiveDockTab.MAPS -> _rightPaneMode.value = RightPaneMode.MAPS
            ActiveDockTab.MEDIA -> _rightPaneMode.value = RightPaneMode.MEDIA_HUB
            ActiveDockTab.BATTERY -> _rightPaneMode.value = RightPaneMode.BATTERY_ENERGY
            ActiveDockTab.PHONE -> _rightPaneMode.value = RightPaneMode.PHONE_DIALER
            ActiveDockTab.CAMERA -> toggleRearCameraOverlay()
            ActiveDockTab.APPS -> _rightPaneMode.value = RightPaneMode.SYSTEM_DIAGNOSTICS
            ActiveDockTab.VOICE -> openVoiceAssistant()
        }
    }

    fun openMediaHub() {
        _activeDockTab.value = ActiveDockTab.MEDIA
        _rightPaneMode.value = RightPaneMode.MEDIA_HUB
    }

    fun openMap() {
        _activeDockTab.value = ActiveDockTab.MAPS
        _rightPaneMode.value = RightPaneMode.MAPS
    }

    fun openVehicleControls() {
        _rightPaneMode.value = RightPaneMode.VEHICLE_CONTROLS
    }

    fun openDriverProfiles() {
        _rightPaneMode.value = RightPaneMode.DRIVER_PROFILES
    }

    fun openObdDiagnostics() {
        _rightPaneMode.value = RightPaneMode.OBD_DIAGNOSTICS
    }

    private fun handleVoiceCommand(command: VoiceCommand) {
        when (command) {
            is VoiceCommand.OpenMaps -> openMap()
            is VoiceCommand.Navigate -> openMap()
            is VoiceCommand.SetClimateTemp -> {
                adjustDriverTemp(command.targetTempC - driverTempC.value)
            }
            is VoiceCommand.SetFanSpeed -> {
                cycleFanLevel()
            }
            is VoiceCommand.ToggleSeatHeating -> {
                cycleDriverSeatHeating()
            }
            is VoiceCommand.ToggleTrunk -> {
                toggleTrunk()
            }
            is VoiceCommand.ToggleDoors -> {
                toggleDriverDoor()
            }
            is VoiceCommand.ToggleHeadlights -> {
                toggleHeadlights()
            }
            is VoiceCommand.OpenRadio -> {
                openMediaHub()
                if (radioPlayer.playbackState.value != PlaybackState.PLAYING) {
                    radioPlayer.togglePlayPause()
                }
            }
            is VoiceCommand.PlayStation -> {
                openMediaHub()
                val station = RadioMediaPlayer.PRESET_STATIONS.find {
                    it.name.contains(command.stationName, ignoreCase = true)
                } ?: RadioMediaPlayer.PRESET_STATIONS.first()
                radioPlayer.playStation(station)
            }
            is VoiceCommand.OpenSpotify -> openMediaHub()
            is VoiceCommand.OpenYouTube -> openMediaHub()
            is VoiceCommand.NextRadioStation -> nextActiveMedia()
            is VoiceCommand.ToggleRadio -> toggleActiveMediaPlayPause()
            is VoiceCommand.OpenDiagnostics -> openObdDiagnostics()
            is VoiceCommand.ReadSpeed -> {
                val speed = effectiveSpeedKmh.value
                voiceAssistant.speak("Mevcut hızınız saatte ${"%.0f".format(speed)} kilometre.")
            }
            is VoiceCommand.OpenControls -> openVehicleControls()
            is VoiceCommand.OpenProfiles -> openDriverProfiles()
            is VoiceCommand.ActivateMode -> {
                openVehicleControls()
            }
            is VoiceCommand.Unknown -> Unit
        }
    }

    override fun onCleared() {
        super.onCleared()
        gpsProvider.stopListening()
        vehicleBridge.stop()
        obdManager.disconnect()
        radioPlayer.releasePlayer()
        usbMediaManager.releasePlayer()
        voiceAssistant.release()
    }
}
