package com.example.media

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Only real user-selected YouTube video IDs may enter this manager. */
data class YouTubeVideo(
    val videoId: String,
    val title: String,
    val channelTitle: String,
    val thumbnailUrl: String,
    val durationText: String = ""
)

/**
 * Official embedded-player HTML helper with strict Driving Safety Interlock (`surus_video`).
 */
class YouTubePlayerManager(private val coordinator: CarMediaCoordinator? = null) {
    private val _currentVideo = MutableStateFlow<YouTubeVideo?>(null)
    val currentVideo: StateFlow<YouTubeVideo?> = _currentVideo.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _searchResults = MutableStateFlow<List<YouTubeVideo>>(emptyList())
    val searchResults: StateFlow<List<YouTubeVideo>> = _searchResults.asStateFlow()

    val integrationStatus: String = "Gerçek arama sonuçları için YouTube Data API yapılandırması gerekli."

    fun selectVideo(video: YouTubeVideo) {
        if (video.videoId.isBlank()) return
        _currentVideo.value = video
        _isPlaying.value = true
        coordinator?.updateNowPlaying(
            title = video.title,
            subtitle = video.channelTitle,
            badgeText = "YouTube",
            badgeColorHex = 0xFFFF0000,
            source = MediaSource.YOUTUBE,
            isPlaying = true,
            albumArtUrl = video.thumbnailUrl
        )
    }

    fun searchVideos(query: String) {
        _searchResults.value = emptyList()
    }

    fun buildEmbeddedHtml(videoId: String, isDrivingRestricted: Boolean): String {
        if (isDrivingRestricted) return """
            <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
            <body style="margin:0;background:#080D18;color:#E8EEF8;font-family:sans-serif;display:grid;place-items:center;height:100vh;text-align:center">
            <main><h2>SÜRÜŞ GÜVENLİĞİ KİLİDİ</h2><p>Araç hareket halindeyken video görüntüsü devre dışıdır.</p></main></body></html>
        """.trimIndent()
        require(videoId.matches(Regex("[A-Za-z0-9_-]{11}"))) { "Geçersiz YouTube video kimliği" }
        return """
            <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
            <body style="margin:0;background:#000;overflow:hidden">
            <iframe title="YouTube video player" style="width:100vw;height:100vh;border:0"
              src="https://www.youtube-nocookie.com/embed/$videoId?playsinline=1&controls=1&rel=0"
              allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture;web-share"
              allowfullscreen></iframe></body></html>
        """.trimIndent()
    }
}
