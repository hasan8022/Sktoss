package com.example.data.obd

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import com.example.model.DtcCode
import com.example.model.DtcSeverity
import com.example.model.OBDConnectionStatus
import com.example.model.VehicleTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

typealias OBDConnectionStatus = com.example.model.OBDConnectionStatus

data class ObdLogEntry(
    val timestamp: String,
    val direction: LogDirection,
    val message: String
)

enum class LogDirection {
    TX, // Transmitted to adapter
    RX, // Received from adapter
    SYS // System status
}

class OBDManager(private val coroutineScope: CoroutineScope) {

    companion object {
        // Standard Bluetooth Serial Port Profile (SPP) UUID
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val DEFAULT_WIFI_IP = "192.168.0.10"
        private const val DEFAULT_WIFI_PORT = 35000
    }

    private val _connectionStatus = MutableStateFlow(OBDConnectionStatus.DISCONNECTED)
    val connectionStatus: StateFlow<OBDConnectionStatus> = _connectionStatus.asStateFlow()

    private val _statusMessage = MutableStateFlow("OBD-II Adaptörü Bağlı Değil")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _telemetry = MutableStateFlow(VehicleTelemetry())
    val telemetry: StateFlow<VehicleTelemetry> = _telemetry.asStateFlow()

    private val _terminalLogs = MutableStateFlow<List<ObdLogEntry>>(emptyList())
    val terminalLogs: StateFlow<List<ObdLogEntry>> = _terminalLogs.asStateFlow()

    private var activeJob: Job? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private var tcpSocket: Socket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null

    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    fun connectBluetooth(deviceAddress: String) {
        disconnect()
        _connectionStatus.value = OBDConnectionStatus.CONNECTING
        _statusMessage.value = "Bluetooth OBD-II ($deviceAddress) Bağlanıyor..."
        log(LogDirection.SYS, "Bluetooth bağlantısı başlatılıyor: $deviceAddress")

        activeJob = coroutineScope.launch(Dispatchers.IO) {
            try {
                val adapter = BluetoothAdapter.getDefaultAdapter()
                if (adapter == null || !adapter.isEnabled) {
                    throw IllegalStateException("Bluetooth kapalı veya cihazda Bluetooth donanımı yok.")
                }

                val device: BluetoothDevice = adapter.getRemoteDevice(deviceAddress)
                adapter.cancelDiscovery()

                val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket.connect()
                bluetoothSocket = socket
                inputStream = socket.inputStream
                outputStream = socket.outputStream

                log(LogDirection.SYS, "RFCOMM Socket bağlantısı başarılı. Protokol başlatılıyor...")
                initializeElm327AndStartPolling()
            } catch (e: Exception) {
                log(LogDirection.SYS, "Bağlantı Hatası: ${e.message}")
                _connectionStatus.value = OBDConnectionStatus.ERROR
                _statusMessage.value = "Bağlantı Başarısız: ${e.localizedMessage}"
                cleanup()
            }
        }
    }

    fun connectWifi(ip: String = DEFAULT_WIFI_IP, port: Int = DEFAULT_WIFI_PORT) {
        disconnect()
        _connectionStatus.value = OBDConnectionStatus.CONNECTING
        _statusMessage.value = "Wi-Fi OBD-II ($ip:$port) Bağlanıyor..."
        log(LogDirection.SYS, "Wi-Fi TCP Soketi başlatılıyor: $ip:$port")

        activeJob = coroutineScope.launch(Dispatchers.IO) {
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(ip, port), 5000)
                tcpSocket = socket
                inputStream = socket.getInputStream()
                outputStream = socket.getOutputStream()

                log(LogDirection.SYS, "Wi-Fi TCP bağlantısı kuruldu. ELM327 başlatılıyor...")
                initializeElm327AndStartPolling()
            } catch (e: Exception) {
                log(LogDirection.SYS, "Wi-Fi Bağlantı Hatası: ${e.message}")
                _connectionStatus.value = OBDConnectionStatus.ERROR
                _statusMessage.value = "Wi-Fi Bağlantı Hatası: ${e.localizedMessage}"
                cleanup()
            }
        }
    }

    fun disconnect() {
        activeJob?.cancel()
        activeJob = null
        cleanup()
        _connectionStatus.value = OBDConnectionStatus.DISCONNECTED
        _statusMessage.value = "Bağlantı Kesildi"
        _telemetry.value = _telemetry.value.copy(
            obdStatus = OBDConnectionStatus.DISCONNECTED,
            obdStatusMessage = "Bağlantı Kesildi",
            obdSpeedKmh = null,
            engineRpm = null,
            coolantTempCelsius = null,
            controlModuleVoltage = null
        )
        log(LogDirection.SYS, "OBD-II Bağlantısı kapatıldı.")
    }

    private suspend fun initializeElm327AndStartPolling() = withContext(Dispatchers.IO) {
        // Reset ELM327
        val atzResponse = sendCommand("AT Z")
        delay(1000)

        // Echo Off
        sendCommand("AT E0")
        // Linefeeds Off
        sendCommand("AT L0")
        // Spaces Off for easier parsing
        sendCommand("AT S0")
        // Auto Protocol
        sendCommand("AT SP 0")

        // Supported PIDs
        val pidResp = sendCommand("0100")
        if (cleanHexResponse(pidResp, "4100") == null) {
            throw IllegalStateException("Adaptör yanıt verdi ancak araç ECU'sundan geçerli 0100 PID yanıtı alınamadı: $pidResp")
        }

        _connectionStatus.value = OBDConnectionStatus.CONNECTED
        _statusMessage.value = "Adaptör ve genel OBD ECU yanıtı doğrulandı; desteklenen PID'ler sorgulanıyor"
        log(LogDirection.SYS, "ELM327 ve ECU yanıtı doğrulandı. Araç/BMS özel verisi doğrulanmış değildir.")

        // Start polling loop
        while (isActive) {
            try {
                // Query Vehicle Speed (010D)
                val speedRaw = sendCommand("010D")
                val parsedSpeed = parseSpeedResponse(speedRaw)

                // Query RPM (010C)
                val rpmRaw = sendCommand("010C")
                val parsedRpm = parseRpmResponse(rpmRaw)

                // Query Coolant / Battery Temp (0105)
                val tempRaw = sendCommand("0105")
                val parsedTemp = parseTempResponse(tempRaw)

                // Query Control Module Voltage (0142)
                val voltRaw = sendCommand("0142")
                val parsedVolt = parseVoltageResponse(voltRaw)

                _telemetry.value = _telemetry.value.copy(
                    obdStatus = OBDConnectionStatus.CONNECTED,
                    obdStatusMessage = "Canlı Veri Akışı Aktif",
                    obdSpeedKmh = parsedSpeed,
                    engineRpm = parsedRpm,
                    coolantTempCelsius = parsedTemp,
                    controlModuleVoltage = parsedVolt,
                    supportedPidsMask = pidResp.trim()
                )

                delay(300) // 300ms loop
            } catch (e: Exception) {
                if (!isActive) break
                log(LogDirection.SYS, "Veri okuma hatası: ${e.message}")
                delay(1000)
            }
        }
    }

    suspend fun queryDiagnosticTroubleCodes(): List<DtcCode> = withContext(Dispatchers.IO) {
        if (_connectionStatus.value != OBDConnectionStatus.CONNECTED) {
            return@withContext emptyList()
        }
        val response = sendCommand("03")
        val codes = parseDtcResponse(response)
        _telemetry.value = _telemetry.value.copy(activeDtcCodes = codes)
        codes
    }

    suspend fun clearDiagnosticTroubleCodes(): Boolean = withContext(Dispatchers.IO) {
        if (_connectionStatus.value != OBDConnectionStatus.CONNECTED) {
            return@withContext false
        }
        log(LogDirection.SYS, "Mode 04: Arıza kodları silme komutu gönderiliyor...")
        val response = sendCommand("04")
        val success = cleanHexResponse(response, "44") != null
        if (success) {
            log(LogDirection.SYS, "ECU Mode 04 olumlu yanıt verdi. Üreticiye özel tüm arıza kayıtlarının silindiği garanti edilmez.")
            _telemetry.value = _telemetry.value.copy(activeDtcCodes = emptyList())
        } else {
            log(LogDirection.SYS, "Mode 04 Başarısız: $response")
        }
        success
    }

    private fun sendCommand(cmd: String): String {
        val out = outputStream ?: throw IllegalStateException("Çıkış akışı kapalı")
        val input = inputStream ?: throw IllegalStateException("Giriş akışı kapalı")

        log(LogDirection.TX, cmd)
        out.write("$cmd\r".toByteArray())
        out.flush()

        val sb = StringBuilder()
        var b: Int
        val buffer = ByteArray(128)

        // Read until prompt '>' or timeout
        val startTime = System.currentTimeMillis()
        while (System.currentTimeMillis() - startTime < 3500) {
            if (input.available() > 0) {
                b = input.read(buffer)
                if (b > 0) {
                    val part = String(buffer, 0, b)
                    sb.append(part)
                    if (part.contains(">")) {
                        break
                    }
                }
            } else {
                Thread.sleep(20)
            }
        }

        val result = sb.toString().replace(">", "").trim()
        log(LogDirection.RX, result)
        return result
    }

    private fun parseSpeedResponse(raw: String): Int? {
        val clean = cleanHexResponse(raw, "410D") ?: return null
        return try {
            clean.take(2).toInt(16)
        } catch (_: Exception) { null }
    }

    private fun parseRpmResponse(raw: String): Int? {
        val clean = cleanHexResponse(raw, "410C") ?: return null
        return try {
            if (clean.length >= 4) {
                val a = clean.substring(0, 2).toInt(16)
                val b = clean.substring(2, 4).toInt(16)
                ((a * 256) + b) / 4
            } else null
        } catch (_: Exception) { null }
    }

    private fun parseTempResponse(raw: String): Int? {
        val clean = cleanHexResponse(raw, "4105") ?: return null
        return try {
            clean.take(2).toInt(16) - 40
        } catch (_: Exception) { null }
    }

    private fun parseVoltageResponse(raw: String): Float? {
        val clean = cleanHexResponse(raw, "4142") ?: return null
        return try {
            if (clean.length >= 4) {
                val a = clean.substring(0, 2).toInt(16)
                val b = clean.substring(2, 4).toInt(16)
                ((a * 256) + b) / 1000.0f
            } else null
        } catch (_: Exception) { null }
    }

    private fun parseDtcResponse(raw: String): List<DtcCode> {
        val clean = cleanHexResponse(raw, "43") ?: return emptyList()
        val dtcList = mutableListOf<DtcCode>()
        var index = 0
        while (index + 4 <= clean.length) {
            val chunk = clean.substring(index, index + 4)
            index += 4
            if (chunk == "0000") continue

            val b1 = chunk.substring(0, 2).toIntOrNull(16) ?: continue
            val b2 = chunk.substring(2, 4)

            val prefix = when ((b1 and 0xC0) shr 6) {
                0 -> "P" // Powertrain
                1 -> "C" // Chassis
                2 -> "B" // Body
                3 -> "U" // Network
                else -> "P"
            }

            val secondChar = (b1 and 0x30) shr 4
            val thirdChar = Integer.toHexString(b1 and 0x0F).uppercase()
            val code = "$prefix$secondChar$thirdChar$b2"

            val desc = getDtcDescription(code)
            dtcList.add(
                DtcCode(
                    code = code,
                    description = desc,
                    category = when (prefix) {
                        "P" -> "Güç Aktarım (Powertrain / Motor)"
                        "B" -> "Gövde (Body / BCM)"
                        "C" -> "Şasi (Chassis / ABS / ESP)"
                        "U" -> "Ağ Haberleşmesi (CAN Bus)"
                        else -> "Bilinmeyen Sistem"
                    },
                    severity = if (prefix == "P" || prefix == "U") DtcSeverity.CRITICAL else DtcSeverity.WARNING
                )
            )
        }
        return dtcList
    }

    private fun getDtcDescription(code: String): String {
        return when (code) {
            "P0A1F" -> "Pil Enerjisi Kontrol Modülü / BMS Dahili Hata"
            "P0A80" -> "Hibrit / EV Pil Paketi Değiştirme / Hücre Dengesizliği"
            "P0A7F" -> "EV Pil Paketi Bozulması / Kapasite Düşüklüğü"
            "P0A0D" -> "Yüksek Voltaj Sistemi Kilitleme Devresi Açık"
            "P0562" -> "Sistem Gerilimi Düşük (< 10.5V)"
            "P0563" -> "Sistem Gerilimi Yüksek (> 15.5V)"
            "U0100" -> "ECM / VCU (Araç Kontrol Ünitesi) ile İletişim Kaybı"
            "U0111" -> "Pil Enerjisi Kontrol Modülü (BMS) ile İletişim Kaybı"
            "U0140" -> "Gövde Kontrol Modülü (BCM) ile İletişim Kaybı"
            "U0001" -> "Yüksek Hızlı CAN İletişim Veri Yolu Hatası"
            else -> "Standart OBD-II / EV Diyagnostik Hata Kodu ($code)"
        }
    }

    private fun cleanHexResponse(raw: String, expectedHeader: String): String? {
        val sanitized = raw.replace("\r", "").replace("\n", "").replace(" ", "").replace(">", "").uppercase()
        val pos = sanitized.indexOf(expectedHeader)
        if (pos == -1) return null
        return sanitized.substring(pos + expectedHeader.length)
    }

    private fun cleanup() {
        try { inputStream?.close() } catch (_: Exception) {}
        try { outputStream?.close() } catch (_: Exception) {}
        try { bluetoothSocket?.close() } catch (_: Exception) {}
        try { tcpSocket?.close() } catch (_: Exception) {}
        inputStream = null
        outputStream = null
        bluetoothSocket = null
        tcpSocket = null
    }

    private fun log(direction: LogDirection, msg: String) {
        val entry = ObdLogEntry(
            timestamp = timeFormat.format(Date()),
            direction = direction,
            message = msg
        )
        val current = _terminalLogs.value.toMutableList()
        current.add(entry)
        if (current.size > 100) {
            current.removeAt(0)
        }
        _terminalLogs.value = current
    }
}
