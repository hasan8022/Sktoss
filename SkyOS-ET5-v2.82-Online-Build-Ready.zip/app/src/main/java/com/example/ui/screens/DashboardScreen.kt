package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OBDConnectionStatus
import com.example.media.PlaybackState
import com.example.ui.AutomotiveScreen
import com.example.ui.SkyOsViewModel
import com.example.ui.components.SkywellVehicleVisualizer
import com.example.ui.theme.SkyAmber
import com.example.ui.theme.SkyCard
import com.example.ui.theme.SkyCardHover
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.SkyDivider
import com.example.ui.theme.SkyElectricBlue
import com.example.ui.theme.SkyGreen
import com.example.ui.theme.SkyNavy
import com.example.ui.theme.SkyRed
import com.example.ui.theme.SkySurface
import com.example.ui.theme.SkyTextMuted
import com.example.ui.theme.SkyTextPrimary
import com.example.ui.theme.SkyTextSecondary

@Composable
fun DashboardScreen(
    viewModel: SkyOsViewModel,
    modifier: Modifier = Modifier
) {
    val effectiveSpeed by viewModel.effectiveSpeedKmh.collectAsState()
    val gpsTelemetry by viewModel.gpsTelemetry.collectAsState()
    val obdTelemetry by viewModel.obdTelemetry.collectAsState()
    val obdStatus by viewModel.obdStatus.collectAsState()
    val isDriving by viewModel.isDriving.collectAsState()

    val carRotation by viewModel.carRotationDegrees.collectAsState()
    val isHeadlightOn by viewModel.isHeadlightOn.collectAsState()
    val isDoorOpen by viewModel.isDriverDoorOpen.collectAsState()
    val isTrunkOpen by viewModel.isTrunkOpen.collectAsState()

    val currentStation by viewModel.radioPlayer.currentStation.collectAsState()
    val playbackState by viewModel.radioPlayer.playbackState.collectAsState()
    val activeProfile by viewModel.activeProfile.collectAsState()

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(SkyNavy)
            .testTag("dashboard_screen")
    ) {
        val isLandscape = maxWidth > maxHeight

        if (isLandscape) {
            // Automotive Horizontal Widescreen Layout (3-Column Cockpit)
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Column 1: Interactive 360 Skywell ET5 Model
                Box(
                    modifier = Modifier
                        .weight(1.0f)
                        .fillMaxHeight()
                ) {
                    SkywellVehicleVisualizer(
                        rotationAngle = carRotation,
                        isHeadlightOn = isHeadlightOn,
                        isDoorOpen = isDoorOpen,
                        isTrunkOpen = isTrunkOpen,
                        onRotate = { viewModel.rotateCar(it) },
                        onResetRotation = { viewModel.resetCarRotation() },
                        onToggleHeadlights = { viewModel.toggleHeadlights() },
                        onToggleDoor = { viewModel.toggleDriverDoor() },
                        onToggleTrunk = { viewModel.toggleTrunk() },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Column 2: Digital Speedometer & Real Telemetry Core
                Box(
                    modifier = Modifier
                        .weight(1.1f)
                        .fillMaxHeight()
                ) {
                    SpeedometerCenterCard(
                        speedKmh = effectiveSpeed,
                        isDriving = isDriving,
                        isObdSpeed = obdTelemetry.obdSpeedKmh != null,
                        gpsAltitude = gpsTelemetry.altitudeMeters,
                        gpsBearing = gpsTelemetry.bearingDegrees,
                        gpsAccuracy = gpsTelemetry.accuracyMeters,
                        gpsStatusMessage = gpsTelemetry.statusMessage,
                        obdStatus = obdStatus,
                        obdTelemetry = obdTelemetry,
                        onConnectObdClick = { viewModel.navigateTo(AutomotiveScreen.OBD_DIAGNOSTICS) }
                    )
                }

                // Column 3: Quick Navigation & Media Widget Pane
                Column(
                    modifier = Modifier
                        .weight(0.9f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Quick Navigation Widget
                    QuickNavigationWidget(
                        onOpenMaps = { viewModel.navigateTo(AutomotiveScreen.NAVIGATION) }
                    )

                    // Quick Radio / Media Widget
                    QuickMediaWidget(
                        stationName = currentStation.name,
                        genre = currentStation.genre,
                        isPlaying = playbackState == PlaybackState.PLAYING,
                        isBuffering = playbackState == PlaybackState.BUFFERING,
                        onTogglePlay = { viewModel.radioPlayer.togglePlayPause() },
                        onNext = { viewModel.radioPlayer.nextStation() },
                        onOpenMedia = { viewModel.navigateTo(AutomotiveScreen.MEDIA) }
                    )

                    // Driver Profile & Climate Quick Widget
                    QuickProfileWidget(
                        profileName = activeProfile?.name ?: "Sürücü 1",
                        cabinTemp = activeProfile?.cabinTempCelsius ?: 22f,
                        seatPreset = activeProfile?.seatPreset ?: 1,
                        onOpenProfiles = { viewModel.navigateTo(AutomotiveScreen.DRIVER_PROFILES) }
                    )
                }
            }
        } else {
            // Portrait Tablet / Phone Fallback Layout
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Top: Speedometer
                SpeedometerCenterCard(
                    speedKmh = effectiveSpeed,
                    isDriving = isDriving,
                    isObdSpeed = obdTelemetry.obdSpeedKmh != null,
                    gpsAltitude = gpsTelemetry.altitudeMeters,
                    gpsBearing = gpsTelemetry.bearingDegrees,
                    gpsAccuracy = gpsTelemetry.accuracyMeters,
                    gpsStatusMessage = gpsTelemetry.statusMessage,
                    obdStatus = obdStatus,
                    obdTelemetry = obdTelemetry,
                    onConnectObdClick = { viewModel.navigateTo(AutomotiveScreen.OBD_DIAGNOSTICS) },
                    modifier = Modifier.fillMaxWidth().height(280.dp)
                )

                // Middle: Visualizer
                SkywellVehicleVisualizer(
                    rotationAngle = carRotation,
                    isHeadlightOn = isHeadlightOn,
                    isDoorOpen = isDoorOpen,
                    isTrunkOpen = isTrunkOpen,
                    onRotate = { viewModel.rotateCar(it) },
                    onResetRotation = { viewModel.resetCarRotation() },
                    onToggleHeadlights = { viewModel.toggleHeadlights() },
                    onToggleDoor = { viewModel.toggleDriverDoor() },
                    onToggleTrunk = { viewModel.toggleTrunk() },
                    modifier = Modifier.fillMaxWidth().height(300.dp)
                )

                // Bottom: Widgets
                QuickNavigationWidget(onOpenMaps = { viewModel.navigateTo(AutomotiveScreen.NAVIGATION) })
                QuickMediaWidget(
                    stationName = currentStation.name,
                    genre = currentStation.genre,
                    isPlaying = playbackState == PlaybackState.PLAYING,
                    isBuffering = playbackState == PlaybackState.BUFFERING,
                    onTogglePlay = { viewModel.radioPlayer.togglePlayPause() },
                    onNext = { viewModel.radioPlayer.nextStation() },
                    onOpenMedia = { viewModel.navigateTo(AutomotiveScreen.MEDIA) }
                )
            }
        }
    }
}

@Composable
private fun SpeedometerCenterCard(
    speedKmh: Float,
    isDriving: Boolean,
    isObdSpeed: Boolean,
    gpsAltitude: Double,
    gpsBearing: Float,
    gpsAccuracy: Float,
    gpsStatusMessage: String,
    obdStatus: OBDConnectionStatus,
    obdTelemetry: com.example.model.VehicleTelemetry,
    onConnectObdClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SkyCard),
        modifier = modifier.fillMaxSize().testTag("speedometer_center_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Speed Source & Motion Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isObdSpeed) Icons.Default.Power else Icons.Default.GpsFixed,
                        contentDescription = null,
                        tint = if (isObdSpeed) SkyGreen else SkyCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isObdSpeed) "Hız Kaynağı: OBD-II CAN" else "Hız Kaynağı: Gerçek GPS Sensörü",
                        color = SkyTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Box(
                    modifier = Modifier
                        .background(
                            if (isDriving) SkyGreen.copy(alpha = 0.15f) else SkyTextMuted.copy(alpha = 0.15f),
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (isDriving) "HAREKET HALİNDE" else "PARK HALİNDE",
                        color = if (isDriving) SkyGreen else SkyTextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Big Speed Gauge
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                Text(
                    text = "%.0f".format(speedKmh),
                    color = SkyTextPrimary,
                    fontSize = 72.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-2).sp
                )
                Text(
                    text = "KM / SAAT",
                    color = SkyCyan,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }

            // Real Hardware Telemetry Sub-panel (OBD or GPS)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SkyNavy, RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                if (obdStatus == OBDConnectionStatus.CONNECTED) {
                    // OBD Real Live Values
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        TelemetryBadge("DEVİR (RPM)", obdTelemetry.engineRpm?.toString() ?: "--")
                        TelemetryBadge("BMS SICAKLIK", obdTelemetry.coolantTempCelsius?.let { "$it°C" } ?: "--")
                        TelemetryBadge("ECU VOLTAJ", obdTelemetry.controlModuleVoltage?.let { "${"%.1f".format(it)}V" } ?: "--")
                    }
                } else {
                    // Transparent Notice: No Fake Data!
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "OBD-II Verisi: Bağlı Değil",
                                color = SkyAmber,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "RPM ve akü verileri için adaptör bağlayın (Sahte veri gösterilmez)",
                                color = SkyTextMuted,
                                fontSize = 10.sp
                            )
                        }
                        OutlinedButton(
                            onClick = onConnectObdClick,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Text("Bağlan", fontSize = 11.sp)
                        }
                    }
                }
            }

            // GPS Coordinates & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = gpsStatusMessage,
                    color = SkyTextMuted,
                    fontSize = 11.sp
                )
                if (gpsAltitude > 0) {
                    Text(
                        text = "Rakım: ${gpsAltitude.toInt()}m | Yön: ${gpsBearing.toInt()}°",
                        color = SkyTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryBadge(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = SkyTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Medium)
        Text(text = value, color = SkyCyan, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun QuickNavigationWidget(onOpenMaps: () -> Unit) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SkyCard),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenMaps() }
            .testTag("quick_nav_widget")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(SkyElectricBlue.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Navigation,
                        contentDescription = "Harita",
                        tint = SkyElectricBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Google Haritalar",
                        color = SkyTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Gerçek Konum & Rota Arama",
                        color = SkyTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Button(
                onClick = onOpenMaps,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SkyElectricBlue)
            ) {
                Text("Aç", fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun QuickMediaWidget(
    stationName: String,
    genre: String,
    isPlaying: Boolean,
    isBuffering: Boolean,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onOpenMedia: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SkyCard),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("quick_media_widget")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .weight(1f)
                    .clickable { onOpenMedia() }
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(SkyCyan.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Radio,
                        contentDescription = "Radyo",
                        tint = SkyCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = stationName,
                        color = SkyTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isBuffering) "Yükleniyor..." else genre,
                        color = SkyTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onTogglePlay,
                    modifier = Modifier
                        .size(36.dp)
                        .background(SkyCyan, CircleShape)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Oynat",
                        tint = Color(0xFF041E26),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onNext,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Sonraki",
                        tint = SkyTextPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickProfileWidget(
    profileName: String,
    cabinTemp: Float,
    seatPreset: Int,
    onOpenProfiles: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SkyCard),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenProfiles() }
            .testTag("quick_profile_widget")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Aktif Profil: $profileName",
                    color = SkyTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Kabin Hedefi: ${"%.1f".format(cabinTemp)}°C | Koltuk Hafızası: $seatPreset",
                    color = SkyTextSecondary,
                    fontSize = 11.sp
                )
            }

            OutlinedButton(
                onClick = onOpenProfiles,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Değiştir", fontSize = 11.sp)
            }
        }
    }
}
