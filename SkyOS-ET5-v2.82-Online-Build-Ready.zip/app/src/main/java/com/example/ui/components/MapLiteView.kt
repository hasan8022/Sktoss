package com.example.ui.components

import android.annotation.SuppressLint
import android.graphics.Color
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.example.ui.theme.LocalEt5Colors

class Et5MapJavascriptBridge(
    private val onUserMoved: () -> Unit,
    private val onReady: () -> Unit
) {
    @JavascriptInterface
    fun onUserMove() {
        onUserMoved()
    }

    @JavascriptInterface
    fun ready() {
        onReady()
    }

    @JavascriptInterface
    fun prefetch(json: String) {
        // Tile prefetch callback
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MapLiteView(
    latitude: Double,
    longitude: Double,
    bearing: Float = 0f,
    speedKmh: Float = 0f,
    isNavigationActive: Boolean = false,
    destinationLat: Double? = null,
    destinationLng: Double? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val colors = LocalEt5Colors.current
    val isDarkMode = colors.isDark
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isReady by remember { mutableStateOf(false) }
    var isFollowingLocation by remember { mutableStateOf(true) }
    var is3DTiltActive by remember { mutableStateOf(true) }

    val assetLoader = remember {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
    }

    // Sync Dark / Light map tiles with LocalEt5Colors.current.isDark
    LaunchedEffect(isReady, isDarkMode) {
        if (!isReady || webViewRef == null) return@LaunchedEffect
        val tileUrl = if (isDarkMode) {
            "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        } else {
            "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
        }
        val attribution = "© OpenStreetMap contributors, © CARTO"
        webViewRef?.evaluateJavascript(
            "if (window.LITE && window.LITE.setTiles) { window.LITE.setTiles('$tileUrl', '$attribution', $isDarkMode); }",
            null
        )
    }

    // Update GPS live coordinate and compass bearing
    LaunchedEffect(isReady, latitude, longitude, bearing) {
        if (!isReady || webViewRef == null) return@LaunchedEffect
        if (latitude != 0.0 && longitude != 0.0) {
            val colorHex = "#3e8ef7"
            val jsCode = """
                if (window.LITE && window.LITE.setFix) {
                    window.LITE.setFix($latitude, $longitude, $bearing, '$colorHex', null);
                }
            """.trimIndent()
            webViewRef?.evaluateJavascript(jsCode, null)
        }
    }

    // Navigation and 3D tilt update
    LaunchedEffect(isReady, isNavigationActive, is3DTiltActive) {
        if (!isReady || webViewRef == null) return@LaunchedEffect
        val jsNav = """
            if (window.LITE && window.LITE.setNav) {
                window.LITE.setNav($isNavigationActive, $is3DTiltActive);
            }
        """.trimIndent()
        webViewRef?.evaluateJavascript(jsNav, null)
    }

    // Destination Pin & Route Polyline
    LaunchedEffect(isReady, destinationLat, destinationLng, latitude, longitude) {
        if (!isReady || webViewRef == null) return@LaunchedEffect
        if (destinationLat != null && destinationLng != null) {
            val startLat = if (latitude != 0.0) latitude else 41.01
            val startLng = if (longitude != 0.0) longitude else 28.97
            val midLat = (startLat + destinationLat) / 2.0 + 0.002
            val midLng = (startLng + destinationLng) / 2.0 - 0.002
            val jsRoute = """
                if (window.LITE) {
                    if (window.LITE.setDest) window.LITE.setDest($destinationLat, $destinationLng);
                    if (window.LITE.setRoutes) window.LITE.setRoutes([[[$startLat, $startLng], [$midLat, $midLng], [$destinationLat, $destinationLng]]], 0, true);
                }
            """.trimIndent()
            webViewRef?.evaluateJavascript(jsRoute, null)
        } else {
            val jsClear = """
                if (window.LITE) {
                    if (window.LITE.setDest) window.LITE.setDest(null, null);
                    if (window.LITE.setRoutes) window.LITE.setRoutes([], 0, false);
                }
            """.trimIndent()
            webViewRef?.evaluateJavascript(jsClear, null)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.mapBg)
            .testTag("map_lite_view")
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(Color.parseColor(if (isDarkMode) "#15181C" else "#E9EBEE"))
                    setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)

                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        allowFileAccess = true
                        allowContentAccess = true
                        loadWithOverviewMode = true
                        useWideViewPort = true
                        cacheMode = WebSettings.LOAD_DEFAULT
                    }

                    addJavascriptInterface(
                        Et5MapJavascriptBridge(
                            onUserMoved = {
                                isFollowingLocation = false
                            },
                            onReady = {
                                isReady = true
                            }
                        ),
                        "Et5Map"
                    )

                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView,
                            request: WebResourceRequest
                        ): WebResourceResponse? {
                            return assetLoader.shouldInterceptRequest(request.url)
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            isReady = true
                        }
                    }

                    loadUrl("https://appassets.androidplatform.net/assets/map-lite/index.html")
                    webViewRef = this
                }
            },
            update = {
                webViewRef = it
            }
        )

        AnimatedVisibility(
            visible = !isReady,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .background(colors.surface.copy(alpha = 0.9f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                CircularProgressIndicator(color = colors.blue, strokeWidth = 3.dp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "SkyOS Harita Yükleniyor…",
                    color = colors.text,
                    fontSize = 12.sp
                )
            }
        }

        // Floating Map Controls: Recenter & 3D Tilt toggle
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = if (isFollowingLocation) colors.blue else colors.surface.copy(alpha = 0.92f),
                tonalElevation = 4.dp,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable {
                        isFollowingLocation = true
                        webViewRef?.evaluateJavascript(
                            "if (window.LITE && window.LITE.setFollow) { window.LITE.setFollow(true, 16); }",
                            null
                        )
                    }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.MyLocation,
                        contentDescription = "Konumuma Git",
                        tint = if (isFollowingLocation) androidx.compose.ui.graphics.Color.White else colors.blue,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Surface(
                shape = CircleShape,
                color = if (is3DTiltActive) colors.blue.copy(alpha = 0.22f) else colors.surface.copy(alpha = 0.92f),
                tonalElevation = 4.dp,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable {
                        is3DTiltActive = !is3DTiltActive
                    }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Navigation,
                        contentDescription = "3D Perspektif Açısı",
                        tint = if (is3DTiltActive) colors.blue else colors.text2,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
